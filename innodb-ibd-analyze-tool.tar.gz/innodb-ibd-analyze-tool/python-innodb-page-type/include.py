# encoding=utf-8
INNODB_PAGE_SIZE = 16 * 1024
#INNODB_PAGE_SIZE = 8 * 1024

# Start of the data on the page
FIL_PAGE_DATA = 38

FIL_PAGE_OFFSET = 4  # page offset inside space
FIL_PAGE_TYPE = 24  # File page type
FIL_PAGE_SPACE_ID = 34  # space id offset
FIL_PAGE_SPACE_ID_LEN = 4

# index header: start
INDEX_HEADER_OFFSET = FIL_PAGE_DATA     # index header 起始地址
PAGE_N_HEAP = INDEX_HEADER_OFFSET + 4   # page 记录总数(用户记录 + 系统记录 + 已删记录), 长 2 字节
PAGE_N_HEAP_LEN = 2

# page 有效用户记录数, 位于 Index Header 的第16个字节, 长 2 字节
PAGE_N_RECS = INDEX_HEADER_OFFSET + 16
PAGE_N_RECS_LEN = 2

# level of the node in an index tree; the leaf level is the level 0, 长 2 字节
PAGE_LEVEL = INDEX_HEADER_OFFSET + 26
PAGE_LEVEL_LEN = 2
PAGE_INDEX_ID = PAGE_LEVEL + PAGE_LEVEL_LEN
PAGE_INDEX_ID_LEN = 8
INDEX_HEADER_LEN = 36   # 索引页独有的 Index Header

PAGE_LSN_OFFSET = 16
PAGE_LSN_LEN = 4
FIL_PAGE_END_LSN_OLD_CHKSUM = 8

# index header: end

SEGMENT_INFO_LEN = 20   # root page 才会记录的信息, 但是每个 page 都预留

# user record:start
# 通过 system record 中保存的 next record offset 能够直接定位到 user record 的记录内容
# 向前回溯 2字节就是 next record 的 offset
# 最后一条 user record 的 next record 是负的, 加上 负的 next_record 定位到 supremum
# supremum 记录的 next record 为 0x00 0x00
NEXT_RECORD_LEN = 2
RECORD_TYPE_OFFSET = 4
RECORD_TYPE_LEN = 2
ROW_PRIMARY_KEY_LEN = 4
RECORD_HEADER_LEN = 5   # 5 bytes: record header
NULL_FLAG_LEN = 1       # 1 byte: NULL-flag
DELETE_FLAG_LEN = 1     # 1 bytes 的第三位
# user record:end

# system record:start
SYSTEM_RECORD = INDEX_HEADER_OFFSET + INDEX_HEADER_LEN + SEGMENT_INFO_LEN
FST_USER_NEXT_RECORD = SYSTEM_RECORD + 3
FST_USER_NEXT_RECORD_LEN = 2
# REC_N_NEW_EXTRA_BYTES 5 bytes
INFIMUM_RECORD = SYSTEM_RECORD + RECORD_HEADER_LEN
SYSTEM_RECORD_LEN = 26  # compact 格式的新版本 innodb, infimum & supremum 记录固定占用 26个 Bytes
# system record:end

RECORD_NO_WIDTH = 10
RECORD_TYPE_WIDTH = 13
RECORD_NEXT_WIDTH = 15
RECORD_PTR_PAGE_WIDTH = 12
RECORD_PK_WIDTH = 10
TABLE_WIDTH = RECORD_NO_WIDTH + RECORD_TYPE_WIDTH + \
    RECORD_NEXT_WIDTH + RECORD_PTR_PAGE_WIDTH + RECORD_PK_WIDTH + 5

# Types of an undo log segment */
TRX_UNDO_INSERT = 1
TRX_UNDO_UPDATE = 2

# On a page of any file segment, data may be put starting from this offset
FSEG_PAGE_DATA = FIL_PAGE_DATA

# The offset of the undo log page header on pages of the undo log
TRX_UNDO_PAGE_HDR = FSEG_PAGE_DATA

innodb_page_type = {
    '0000': u'Freshly Allocated Page',
    '0002': u'Undo Log Page',
    '0003': u'File Segment inode',
    '0004': u'Insert Buffer Free List',
    '0005': u'Insert Buffer Bitmap',
    '0006': u'System Page',
    '0007': u'Transaction system Page',
    '0008': u'File Space Header',
    '0009': u'扩展描述页',
    '000a': u'Uncompressed BLOB Page',
    '000b': u'1st compressed BLOB Page',
    '000c': u'Subsequent compressed BLOB Page',
    '45bf': u'B-tree Node'
}

innodb_page_direction = {
    '0000': 'Unknown(0x0000)',
    '0001': 'Page Left',
    '0002': 'Page Right',
    '0003': 'Page Same Rec',
    '0004': 'Page Same Page',
    '0005': 'Page No Direction',
    'ffff': 'Unkown2(0xffff)'
}

innodb_record_type = {
    '000': 'ORDINARY',
    '001': 'NODE_PTR',
    '002': 'INFIMUM',
    '003': 'SUPREMUM'
}


