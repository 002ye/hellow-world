#! /usr/bin/env python 
#encoding=utf-8
from sys import argv
# encoding=utf-8
import os

class myargv(object):
    def __init__(self, argv):
        self.argv = argv
        self.parms = {}
        self.tablespace = ''

    def parse_cmdline(self):
        argv = self.argv[1:]
        if len(argv) == 1:
            print 'Usage: python py_innodb_page_info.py [OPTIONS] tablespace_file'
            print 'For more options, use python py_innodb_page_info.py -h'
            return 0
        while argv:
            if argv[0][0] == '-':
                if argv[0][1] == 'h':
                    self.parms[argv[0]] = ''
                    argv = argv[1:]
                    break
                if argv[0][1:] == 'page_no':
                    self.parms[argv[0]] = argv[1]
                    argv = argv[2:]
                    print self.parms['-page_no']
                elif argv[0][1:] == 'page_size':
                    self.parms[argv[0]] = argv[1]
                    argv = argv[2:]
                    print self.parms['-page_size']
                elif argv[0][1:] == 'page_count':
                    self.parms[argv[0]] = argv[1]
                    argv = argv[2:]
                    print self.parms['-page_count']
                elif argv[0][1:] == 'file':
                    self.tablespace = argv[1]
                    argv = argv[2:]
                    print self.tablespace
                else:
                    self.parms[argv[0]] = argv[1]
                    argv = argv[2:]

        if self.parms.has_key('-h'):
            print 'Get InnoDB Page Info'
            print 'Usage: python read.py [OPTIONS]\n'
            print 'The following options may be given as the first argument:'
            print '-h          help '
            print '-output     put the result to file'
            print '-file       reaf file path'
            print '-page_no    read start page_no'
            print '-page_size  physical page size'
            print '-page_count read page count'
            return 0
        return 1

def read_page(myargv):
    """
    Read page from ibd from offset to offset + length
    """
    if myargv.tablespace == '':
        print 'no input file'
        os._exit(1)

    if myargv.parms['-output'] == '':
        print 'no output file'
        os._exit(1)

    page_no = int(myargv.parms['-page_no'])
    page_size = int(myargv.parms['-page_size'])
    page_count = int(myargv.parms['-page_count'])

    f = file(myargv.tablespace, 'rb')
    file_size = os.path.getsize(f.name)

    offset = page_no * page_size
    if offset >= file_size:
        print 'read offset ' + offset + ' exceeds the file size ' + file_size
        f.close()
        os._exit(1)

    f.seek(offset)

    read_size = page_count * page_size
    if offset + read_size > file_size:
        print 'read length ' + offset + read_size + ' exceeds the file size ' . file_size
        f.close
        os._exit(1)

    o = file(myargv.parms['-output'], 'wb')

    for i in range(page_count):
        o.write(f.read(page_size))
    o.close()
    f.close()

if __name__ == '__main__':
    myargv = myargv(argv)
    if myargv.parse_cmdline() == 0:
        pass
    else:
        read_page(myargv)