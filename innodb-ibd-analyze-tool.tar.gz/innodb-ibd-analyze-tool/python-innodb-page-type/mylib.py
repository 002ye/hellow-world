# encoding=utf-8
import os
import include
from include import *

TABLESPACE_NAME = 'D:\\mysql_data\\test\\t.ibd'
VARIABLE_FIELD_COUNT = 1
NULL_FIELD_COUNT = 0


class myargv(object):
    def __init__(self, argv):
        self.argv = argv
        self.parms = {}
        self.tablespace = ''

    def parse_cmdline(self):
        argv = self.argv
        if len(argv) == 1:
            print 'Usage: python py_innodb_page_info.py [OPTIONS] tablespace_file'
            print 'For more options, use python py_innodb_page_info.py -h'
            return 0
        while argv:
            if argv[0][0] == '-':
                if argv[0][1] == 'h':
                    self.parms[argv[0]] = ''
                    argv = argv[1:]
                    break
                if argv[0][1] == 'v':
                    self.parms[argv[0]] = ''
                    argv = argv[1:]
                elif argv[0][1] == 't':
                    self.parms[argv[0]] = ''
                    argv = argv[1:]
                else:
                    self.parms[argv[0]] = argv[1]
                    argv = argv[2:]
            else:
                self.tablespace = argv[0]
                argv = argv[1:]
        if self.parms.has_key('-h'):
            print 'Get InnoDB Page Info'
            print 'Usage: python py_innodb_page_info.py [OPTIONS] tablespace_file\n'
            print 'The following options may be given as the first argument:'
            print '-h        help '
            print '-o output put the result to file'
            print '-t number thread to anayle the tablespace file'
            print '-v        verbose mode'
            return 0
        return 1


def mach_read_from_n(page, start_offset, length):
    """
    Read n bytes from page
    """
    ret = page[start_offset:start_offset+length]
    # print "%d" % int(ret.encode('hex'), 16)
    return ret.encode('hex')


def mach_read_from_n_dec(page, start_offset, length):
    """
    Read n bytes from page and convert data type to int
    """
    ret = page[start_offset:start_offset + length]
    # print "%d" % int(ret.encode('hex'), 16)
    return int(ret.encode('hex'), 16)


def hex2dec(string_num):
    """
    Hex to int
    """
    return int(string_num, 16)


def get_record_type(page, start_offset):
    """
    Get record type
    """
    start_offset -= RECORD_TYPE_OFFSET
    tmp = mach_read_from_n_dec(page, start_offset, RECORD_TYPE_LEN)
    # print "type:%s" % "{:03x}".format(tmp & 0x0003)
    return "{:03x}".format(tmp & 0x0003)


def get_next_record(page, start_offset):
    """
    Get next record offset
    """
    start_offset -= NEXT_RECORD_LEN
    offset = hex2dec(mach_read_from_n(page, start_offset, NEXT_RECORD_LEN))
    return ((offset - 1) ^ 0xFFFF) * -1 if offset & 0x8000 else offset
    # print offset
    # if offset & 0x8000:
    # return ((offset - 1) ^ 0xFFFF) * -1
    # return offset


def get_delete_flag(page, start_offset):
    """
    Get record delete flag
    """
    start_offset -= RECORD_HEADER_LEN
    del_flag = mach_read_from_n_dec(page, start_offset, DELETE_FLAG_LEN)
    del_flag &= 0x20
    return True if del_flag else False


def get_pk(page, start_offset):
    """
    Get record primary key
    """
    pk = hex2dec(mach_read_from_n(page, start_offset, ROW_PRIMARY_KEY_LEN))
    return (pk & 0x7FFFFFFF) if pk & 0x80000000 else ((pk - 1) ^ 0x7FFFFFFF) * -1


def get_ptr_page_offset(page, start_offset):
    """
    Get page no is pointed with ptr record
    """
    ptr_page_offset = start_offset + ROW_PRIMARY_KEY_LEN
    ret = mach_read_from_n(page, ptr_page_offset, FIL_PAGE_OFFSET)
    return ret


def print_index_page(page, page_offset, page_type):
    """
    Print B+ tree node info
    """
    page_level = mach_read_from_n(page, PAGE_LEVEL, PAGE_LEVEL_LEN)
    page_n_heap = hex2dec(mach_read_from_n(page, PAGE_N_HEAP, PAGE_N_HEAP_LEN))
    page_n_recs = hex2dec(mach_read_from_n(page, PAGE_N_RECS, PAGE_N_RECS_LEN))
    page_space_id = hex2dec(mach_read_from_n(page, FIL_PAGE_SPACE_ID, FIL_PAGE_SPACE_ID_LEN))
    page_index_id = hex2dec(mach_read_from_n(page, PAGE_INDEX_ID, PAGE_INDEX_ID_LEN))
    page_lsn_low = hex2dec(mach_read_from_n(page, PAGE_LSN_OFFSET + 4, 4))
    checksum_lsn = hex2dec(mach_read_from_n(page, INNODB_PAGE_SIZE - FIL_PAGE_END_LSN_OLD_CHKSUM + 4, 4))
    # row format["COMPACT | REDUNDANT"]
    # 最高位为1时表示 row format 为 compact, 否则为 redundant
    compact_flag = page_n_heap & 0x8000
    page_n_heap &= 0x7FFF   # 将最高位删除
    # print format
    rec_w = RECORD_NO_WIDTH
    rec_type_w = RECORD_TYPE_WIDTH
    rec_next_w = RECORD_NEXT_WIDTH
    rec_ptr_w = RECORD_PTR_PAGE_WIDTH
    rec_pk_w = RECORD_PK_WIDTH
    header_format = '%-*s %-*s %-*s %-*s %-*s'
    rec_format = '%-*d %-*s %-*s %-*s %-*s'
    #print "page offset %s, page type <%s>, page level <%s>" % (
    #    page_offset, innodb_page_type[page_type], page_level)
    print '=' * TABLE_WIDTH
    print "row format [%s] page heap [%d] page recs [%d] delete rec [%d]" % (
        "COMPACT" if compact_flag else "REDUNDANT",
        page_n_heap, page_n_recs, page_n_heap - page_n_recs - 2)
    print "space id [%d] index id [%d]" % (page_space_id, page_index_id)
    print "page lsn [%d] checksum lsn [%d]" % (page_lsn_low, checksum_lsn)
    print '-' * TABLE_WIDTH
    print header_format % (rec_w, 'record', rec_type_w, 'type',
                           rec_next_w, 'next offset', rec_ptr_w, 'pointer',
                           rec_pk_w, 'pk value')
    print '-' * TABLE_WIDTH
    record_offset = INFIMUM_RECORD
    next_record = 0
    for n in range(page_n_heap):
        record_offset = record_offset + next_record
        record_type = innodb_record_type[get_record_type(page, record_offset)]
        next_record = get_next_record(page, record_offset)
        is_delete = get_delete_flag(page, record_offset)
        pk_value = '-'
        ptr_page = '-'
        if is_delete:
            continue
        if record_type == 'NODE_PTR':
            ptr_page = get_ptr_page_offset(page, record_offset)
        if record_type in ['NODE_PTR', 'ORDINARY']:
            pk_value = str(get_pk(page, record_offset))
        print rec_format % (rec_w, n, rec_type_w, record_type,
                            rec_next_w, next_record, rec_ptr_w, ptr_page,
                            rec_pk_w, pk_value)
        if next_record == 0:
            break
    print '=' * TABLE_WIDTH
    print ''


def get_innodb_page_type(myargv):
    """
    Get innodb page type from ibd
    """
    f = file(myargv.tablespace, 'rb')
    # ibd 是由 16K 的 page 组成, 因此, 文件大小是 16384(16K) 的整数倍
    # fsize 表示 ibd 文件中有多少个 page
    block_size = INNODB_PAGE_SIZE
    print block_size
    fsize = os.path.getsize(f.name)/block_size
    # fsize = 3
    ret = {}
    # 通过循环 + offset 读取每个 page 的信息
    for i in range(fsize):
        page = f.read(block_size)  # 每次向后读取 16K
        # FIL_PAGE_OFFSET 表示 page_no 的 offset, page_no 的长度为 4 Bytes
        page_offset = mach_read_from_n(page, FIL_PAGE_OFFSET, 4)
        # 同理, 根据 FIL_PAGE_TYPE 能够获取 page_type
        page_type = mach_read_from_n(page, FIL_PAGE_TYPE, 2)
        space_id = hex2dec(mach_read_from_n(page, FIL_PAGE_SPACE_ID, FIL_PAGE_SPACE_ID_LEN))
        if '-v' in myargv.parms:
            if page_type == '45bf':
                page_level = mach_read_from_n(page, PAGE_LEVEL, 2)
                print "space %d page offset %d, page type <%s>, page level <%s>" % (
                    space_id, hex2dec(page_offset), innodb_page_type[page_type], page_level)
            else:
                print "space %d page offset %d, page type <%s>" % (
                    space_id, hex2dec(page_offset), page_type)
        if '-t' in myargv.parms:
            # 45bf : 17855 : FIL_PAGE_INDEX, 索引页(B+树节点)
            if page_type == '45bf':
                print_index_page(page, page_offset, page_type)
            else:
                print "page offset %s, page type <%s>" % (
                    page_offset, innodb_page_type[page_type])
        if not ret.has_key(page_type):
            ret[page_type] = 1
        else:
            ret[page_type] = ret[page_type] + 1
    print "Total number of page: %d" % fsize
    for type in ret:
        print "%s: %s" % (innodb_page_type[type], ret[type])
