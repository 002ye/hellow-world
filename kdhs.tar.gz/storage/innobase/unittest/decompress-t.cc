/* Copyright (c) 2014, , Baidu Inc. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software Foundation,
  51 Franklin Street, Suite 500, Boston, MA 02110-1335 USA */
//#include "zip_async_compress-t.h"
#include <btr0btr.h>
#include <srv0start.h>
#include "my_sys.h"
#include "buf0buf.h"
#include "mtr0mtr.h"
#include "lock0lock.h"
#include "mysqld.h"
#include <tap.h>
#include <stdio.h>
#include "page0zip.h"
#include "zlib.h"
#include "lz4.h"

/*the compress interfaces*/
static
int
deflate_lz4(
z_streamp strm,
int flush)
{
    fprintf(stderr, "zip block: len: %u, avail_in: %u, total_in: %u, avail_out: %u, total_out: %u \n",
                strm->len, strm->avail_in, strm->total_in, strm->avail_out, strm->total_out);
    uint len;
    if (strm->avail_in > 0) {
        memcpy(strm->buf_tmp + strm->len, strm->next_in, strm->avail_in);
        strm->len += strm->avail_in;
        strm->next_in += strm->avail_in;
        strm->total_in += strm->avail_in;
        strm->avail_in = 0;
        fprintf(stderr,"\nzip block copy: total_in: %u\n", strm->total_in);
        ut_print_buf(stderr, strm->buf_tmp, strm->total_in);
    }

    if(Z_FULL_FLUSH == flush) {
        memmove(strm->buf_tmp + sizeof(uint), strm->buf_tmp, strm->len);
        *(uint*)strm->buf_tmp = strm->len;
        strm->len += sizeof(uint);
    }

    if (Z_FINISH == flush) {
        /* use safe interface */
        len = LZ4_compress_limitedOutput((const char*) strm->buf_tmp, 
                (char*)(strm->next_out + sizeof(uint)), strm->len, strm->avail_out);
        if(len == 0 || (len + sizeof(uint) > strm->avail_out)) {
            return Z_STREAM_ERROR;
        }
        /* total len */
        *(uint*)(strm->next_out) = len;
        strm->avail_out -= (len + sizeof(uint));
        strm->total_out += (len + sizeof(uint));
        strm->next_out += (len + sizeof(uint));
        strm->len = 0;
        fprintf(stderr,"zip block after compress: len: %u, avail_out: %u, total_in: %u, total_out: %u, next_out: %u \n",
                len, strm->avail_out, strm->total_in, strm->total_out, *(uint*)(strm->next_out));
        ut_print_buf(stderr, strm->buf_tmp, strm->total_in);

        return Z_STREAM_END;
    }
    return Z_OK;
}

/** the decompress interfaces */
int 
inflate_lz4(
z_stream* strm,
int flush)
{
    uint len = 0;
    uint in_len;
    if(Z_BLOCK == flush) {
        int de_len = 0;
        fprintf(stderr,"Decompress into 1st IF!!!!\n");
        in_len = *(uint*)strm->next_in;
        strm->next_in += sizeof(uint);
        strm->total_in += sizeof(uint);
        strm->avail_in -= sizeof(uint);

        // 打印解压内容, 与压缩结果进行对比
        fprintf(stderr, "\n inlfate input buffer: %u\n", strm->avail_in);
        ut_print_buf(stderr, strm->next_in, strm->avail_in);

        de_len = LZ4_decompress_safe((const char*) strm->next_in, 
                                        (char *)strm->buf_tmp, in_len, strm->avail_out);
        if (de_len < 0) {
            fprintf(stderr, "decompress failed: in_len %u, avail_out %u, delen %d\n", 
                    in_len, strm->avail_out, de_len);
            return Z_STREAM_ERROR;
        }
        strm->total_in += in_len;
        strm->next_in += in_len;
        strm->avail_in -= in_len;
        strm->len = (uint)de_len; /* total out, negative has returned */

        len = *(uint*)strm->buf_tmp;
        strm->total_out += sizeof(uint);
        memcpy(strm->next_out, strm->buf_tmp + strm->total_out, len);
        strm->next_out += len;
        strm->avail_out -= len;
        strm->total_out += len;
        ok(de_len >= 0,"finish Z_BLOCK IF!!!!");
        return Z_OK;
    }

    if (strm->avail_out > 0) { 
        memcpy(strm->next_out, strm->buf_tmp + strm->total_out, strm->avail_out);
        strm->next_out += strm->avail_out;
        strm->total_out += strm->avail_out;
        strm->avail_out -= strm->avail_out;
        fprintf(stderr,"Decompress into 2nd IF!!!!\n");
    }

    if (flush == Z_SYNC_FLUSH || flush == Z_FINISH) {
        if (strm->total_out >= strm->len)  {
            fprintf(stderr,"Decompress into 3rd IF!!!!\n");
            return Z_STREAM_END;
        }
    }
    return Z_OK;
}

static int
init_strm(z_stream* strm) {
    strm->next_in = NULL;
    strm->avail_in = 0;
    strm->total_in = 0;
    strm->next_out = NULL;
    strm->avail_out = 0;
    strm->total_out = 0;
    strm->msg = NULL;
    strm->state = NULL;
    strm->zalloc = NULL;
    strm->zfree = NULL;
    strm->opaque = NULL;
    strm->data_type = 0;
    strm->adler = 0;
    strm->reserved = 0;
    strm->buf_tmp = NULL;
    strm->len = 0;
    return Z_OK;

}

static int
inflateinit2_lz4_test(z_stream* strm) {
    strm->total_in = 0;
    strm->total_out = 0;
    strm->msg = NULL;
    strm->state = NULL;
    strm->zalloc = NULL;
    strm->zfree = NULL;
    strm->opaque = NULL;
    strm->data_type = 0;
    strm->adler = 0;
    strm->reserved = 0;
    strm->len = 0; 
    return Z_OK;
}

void test_decompress(char *name) {
    FILE *fp = NULL;
    fp = fopen(name, "rb");
    Bytef buf[8192];
    Bytef buf_tmp[16384];
    Bytef res[16384];
    z_stream strm;
    fseek(fp, 24576, SEEK_SET);
    for (int i = 0; i < 6; ++i) {
        init_strm(&strm);
        fread(buf, 8192, 1, fp);
        strm.next_in = buf + PAGE_DATA;
        strm.avail_in = static_cast<uInt>(8192 - (PAGE_DATA + 1));
        strm.next_out = res + PAGE_ZIP_START;
        strm.avail_out = UNIV_PAGE_SIZE - PAGE_ZIP_START;
        strm.buf_tmp = static_cast<unsigned char*>(buf_tmp);
        if(inflate_lz4(&strm, Z_BLOCK) == 0) {
            printf("success\n");
        } else {
            printf("failed\n");
        }
        printf("buf: %.*x\n", 10, buf + 4000);
        memset(buf, 0, 8192);
    }
    fclose(fp);
}

void test_compress_decompress(char *name) {
    FILE *fp = NULL;
    fp = fopen(name, "rb");
    Bytef buf[16384];
    Bytef buf_tmp[16384];
    Bytef compress_res[8192];
    Bytef decopmress_res[16384];

    z_stream c_strm;
    z_stream d_strm;

    // fseek(fp, 16384 * 3, SEEK_SET);
    fseek(fp, 16388, SEEK_SET);
    for (int i = 0; i < 1; ++i) {
        init_strm(&c_strm);
        fread(buf, 16384, 1, fp);
        uint offset = 0;

        // printf("buf: %.*x\n", 10, compress_buf + 4000);

        // c_strm.next_in = buf + PAGE_DATA;
        // c_strm.avail_in = static_cast<uInt>(16384 - PAGE_DATA);
        c_strm.next_out = compress_res;
        c_strm.avail_out = 8037;
        c_strm.buf_tmp = static_cast<unsigned char*>(buf_tmp);

        // 128
        c_strm.next_in = buf;
        c_strm.avail_in = static_cast<uInt>(128);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_FULL_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 93
        offset += 128;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(93);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 8
        offset += 93;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(8);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 4855
        offset += 8;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(4855);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 87
        offset += 4855;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(87);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 8
        offset += 87;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(8);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 5235
        offset += 8;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(5235);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 48
        offset += 5235;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(48);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 8
        offset += 48;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(8);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 734
        offset += 8;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(734);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 95
        offset += 734;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(95);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 8
        offset += 95;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(8);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);

        // 4954
        offset += 8;
        c_strm.next_in = buf + offset;
        c_strm.avail_in = static_cast<uInt>(4954);

        ut_print_buf(stderr, c_strm.next_in, c_strm.avail_in);
        deflate_lz4(&c_strm, Z_NO_FLUSH);
        printf("total_in: %ld, avail_in: %u\n", c_strm.total_in, c_strm.avail_in);
        
        uint data_in_size = c_strm.total_in;

        c_strm.avail_in = 0;

        if (deflate_lz4(&c_strm, Z_FINISH) == Z_STREAM_END)  {
            // ut_a(buf + c_strm.total_out == c_strm.next_out);
            printf("compress success\n");
        } else {
            printf("compress failed\n");
        }
        fprintf(stderr, "deflate over: avail_in: %u, avail_out: %u, total_out: %u\n",
                c_strm.avail_in, c_strm.avail_out, c_strm.total_out);

        uint res_size = c_strm.total_out;

        ut_print_buf(stderr, compress_res, res_size);

        memset(buf_tmp, 0, 16384);
        memset(decopmress_res, 0, 16384);
        inflateinit2_lz4_test(&d_strm);
        d_strm.next_in = compress_res;
        d_strm.avail_in = static_cast<uInt>(res_size);
        d_strm.next_out = decopmress_res;
        d_strm.avail_out = 16384;
        d_strm.buf_tmp = static_cast<unsigned char*>(buf_tmp);

        inflate_lz4(&d_strm, Z_BLOCK);
        printf("inflate Z_BLOCK:  avail_in: %u, avail_out: %u, total_out: %u\n",
                d_strm.avail_in, d_strm.avail_out, d_strm.total_out);

        inflate_lz4(&d_strm, Z_FINISH);
        printf("inflate Z_FINISH:  avail_in: %u, avail_out: %u, total_out: %u\n",
                d_strm.avail_in, d_strm.avail_out, d_strm.total_out);
        
        printf("buf dump:\n");
        ut_print_buf(stderr, buf, data_in_size);

        printf("debuf dump:\n");
        ut_print_buf(stderr, decopmress_res, d_strm.total_out);
        // memmove(d_strm.buf_tmp, d_strm.buf_tmp + sizeof(uint), *(uint*)d_strm.buf_tmp);

        if (memcmp(decopmress_res, buf, data_in_size) == 0) {
            printf("decompress success\n");
        } else {
            printf("decompress failed\n");
        }
        printf("\n");

        memset(buf, 0, 8192);
    }
    fclose(fp);
}

int main(int argc, char **argv)
{
    MY_INIT("zip_async_compress-t");
    if (strcmp(argv[1], "1") == 0) {
        test_decompress(argv[2]);
    } else {
        test_compress_decompress(argv[2]);
    }
    return 0;
}
