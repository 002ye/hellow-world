/* Copyright (c) 2014, , Baidu Inc. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software Foundation,
  51 Franklin Street, Suite 500, Boston, MA 02110-1335 USA */
//#include "zip_async_compress-t.h"
#include <btr0btr.h>
#include <srv0start.h>
#include "my_sys.h"
#include "buf0buf.h"
#include "mtr0mtr.h"
#include "lock0lock.h"
#include "mysqld.h"
#include <tap.h>
#include <stdio.h>
#include "page0zip.h"
#include "row0ins.h"
#include "pars0pars.h"
#include "trx0rseg.h"
#include "ibuf0ibuf.h"
#include "zlib.h"
#include "lz4.h"
#include "btr0defragment.h"
#include "ut0timer.h"

#define THREADS 16
extern os_ib_mutex_t async_compress_mutex;
extern async_compress_slot_t* async_compress_thread_slots;
// cluster leaf page, second leaf page, second middle page

#define VARCHAR_FIELD_LEN 1024 
#define SPACE_ID 1
#define CLUST_LEAF_PAGE 3
#define SEC_MID_PAGE 4
#define SEC_LEAF_PAGE 5
#define SENTINEL_PAGE 1023
#define HDR_PAGE 0
#define BITMAP_PAGE 1
#define INODE_PAGE 2
#define TEST_TABLE_ID 1
#define TEST_CLUST_IND_ID 1
#define TEST_SEC_IND_ID 2
#define CH_NEW_LEN 35
#define CH_LEN 35
#define SMALL_OUT_LEN 35
#define BIG_OUT_LEN 1024
#define DECOMPRESS_OUT_LEN 1024


Bytef ch[35];
Bytef buf[1024];
Bytef small_out[35];
Bytef big_out[1024];
Bytef decompress_out[1024];
Bytef ch_new[35];
z_stream strm;

static buf_block_t *test_block1 = NULL;
static buf_block_t *test_block2 = NULL;
static buf_block_t *test_block3 = NULL;
static dict_table_t *table = NULL;
static fsp_header_t *fsp_header = NULL;
static dict_index_t *index_c = NULL;
static dict_index_t *index_s = NULL;

extern ulint btr_get_reclaim_page_no(btr_reclaim_item_t *item, fsp_header_t *header);
extern void btr_gen_defragment_item_for_db(const char* name);
extern bool btr_table_need_to_be_reclaimed(const char* table_name, dict_table_t* table);
extern dict_index_t* btr_open_table_index(btr_index_map &index_map, const char* table_name);
extern bool btr_find_reclaim_item_with_name(const char* table_name);
extern fsp_header_t* btr_get_fsp_header(ulint space, ulint zip_size, mtr_t *mtr);
extern void btr_reclaim_shutdown();
extern void btr_defragment_shutdown();
extern btr_defragment_item_t* btr_defragment_get_item();
extern btr_reclaim_item_t* btr_reclaim_get_item();
extern void btr_reclaim_remove_item(btr_reclaim_item_t* item);
extern void btr_reclaim_add_defragment_item(bool* check_interval, ulonglong* last_reclaim_time);
extern double cal_cpuidle(cpu_stat_t* one, cpu_stat_t* two);
extern void get_cpu_stat(cpu_stat_t* cpu_stat);
extern bool btr_gen_defragment_item_for_table(const char* table_name);
extern uint btr_load_n_pages(
        ulint space, ulint zip_size, buf_block_t** blocks,
        uint load_n_pages, ulint* cur_page_no, mtr_t* mtr);
extern fseg_header_t* btr_get_fseg_header(dict_index_t* index, ulint level, mtr_t* mtr);
extern ulint btr_get_first_free_page_no(ulint space, dict_index_t* index, ulint zip_size, ulint level);
extern bool btr_index_can_be_reclaimed(
        btr_reclaim_item_t* r_item, ulint space, ulint zip_size,
        buf_block_t** blocks, uint n_pages, mtr_t* mtr);
extern ulint btr_reclaim_n_pages(
        btr_reclaim_item_t* r_item, ulint space, ulint zip_size,
        buf_block_t** blocks, uint n_pages, mtr_t* mtr);
extern bool btr_check_freed(ulint space, ulint zip_size,ulint last, ulint first,
                            buf_block_t **blocks, ulint *block_num, mtr_t* mtr);
extern ulint btr_try_to_truncate_ibd(btr_reclaim_item_t* r_item, ulint space,
                                    ulint page_no, ulint zip_size, buf_block_t** blocks);

// copy from server which defined as static 
void
init_file_page(
/*===================*/
    buf_block_t*        block)    /*!< in: pointer to a page */
{
    page_t* page = buf_block_get_frame(block);
    page_zip_des_t* page_zip = buf_block_get_page_zip(block);

#ifndef UNIV_HOTBACKUP
    block->check_index_page_at_flush = FALSE;
#endif /* !UNIV_HOTBACKUP */

    if (page_zip) {
        memset(page, 0, UNIV_PAGE_SIZE);
        memset(page_zip->data, 0, page_zip_get_size(page_zip));
        mach_write_to_4(page + FIL_PAGE_OFFSET,
                buf_block_get_page_no(block));
        mach_write_to_4(page
                + FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID,
                buf_block_get_space(block));
        memcpy(page_zip->data + FIL_PAGE_OFFSET,
               page + FIL_PAGE_OFFSET, 4);
        memcpy(page_zip->data + FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID,
               page + FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, 4);
        return;
    }

    memset(page, 0, UNIV_PAGE_SIZE);
    mach_write_to_4(page + FIL_PAGE_OFFSET, buf_block_get_page_no(block));
    mach_write_to_4(page + FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID,
            buf_block_get_space(block));
}
/**
 * Test btr_try_to_truncate_ibd
 * 1 test truncate ibd
*/
void test_btr_try_to_truncate_ibd() {
    ulint last_page_no = 0;
    btr_reclaim_item_t *r_item = new btr_reclaim_item_t(index_c);
    last_page_no = btr_try_to_truncate_ibd(r_item, SPACE_ID, 1024 - 64, 8192, nullptr);
    ok(last_page_no == 1024 - 64, "test_btr_try_to_truncate_ibd: "
            "1 test truncate ibd: succeed");
}

/**
 * Test btr_check_freed
 * 1 check 64 pages are freed
*/
void test_btr_check_freed() {
    bool ret = false;
    ulint block_num = 0;
    mtr_t mtr;
    mtr_start(&mtr);
    ret = btr_check_freed(SPACE_ID, 8192, 1024 - 1, 1024 - 64, nullptr, &block_num ,&mtr);
    mtr_commit(&mtr);
    ok(ret, "test_btr_check_freed: 1 check 64 pages are freed: succeed");
}

/**
 * Test btr_reclaim_n_pages
 * 1 load 64 pages
 * 2 reclaim n pages
*/
void test_btr_reclaim_n_pages() {
    uint n_pages = 0;
    uint load_n_pages = 64;
    buf_block_t *blocks[64];
    ulint cur_page_no = 1023;
    mtr_t mtr;

    // ulint last_page_no = 0;

    for (uint i = 0; i < load_n_pages; i++) {
        blocks[i] = NULL;
    }
    /* Load 64 pages */
    mtr_start(&mtr);
    n_pages = btr_load_n_pages(SPACE_ID, 8192, blocks, load_n_pages,
                                &cur_page_no, &mtr);
    mtr_commit(&mtr);
    ok(n_pages == load_n_pages, "test_btr_reclaim_n_pages: "
            "1 load 64 pages: succeed");

    /* reclaim 64 pages: failed, can not get descr of page */
    // btr_reclaim_item_t *r_item = new btr_reclaim_item_t(index_c);
    // mtr_start(&mtr);
    // last_page_no = btr_reclaim_n_pages(r_item, SPACE_ID, 8192, blocks, n_pages, &mtr);
    // mtr_commit(&mtr);
    // ok(last_page_no == 1024 - n_pages, "test_btr_reclaim_n_pages: "
    //         "2 reclaim n pages: succeed");
}

/**
 * Test btr_index_can_be_reclaimed
 * 1 load 64 pages
 * 2 check load 64 pages
 * 3 check pages can be reclaimed
*/
void test_btr_index_can_be_reclaimed() {
    uint n_pages = 0;
    uint load_n_pages = 64;
    buf_block_t *blocks[64];
    ulint cur_page_no = 1023;
    mtr_t mtr;
    bool ret = true;

    for (uint i = 0; i < load_n_pages; i++) {
        blocks[i] = NULL;
    }
    /* Load 64 pages */
    mtr_start(&mtr);
    n_pages = btr_load_n_pages(SPACE_ID, 8192, blocks, load_n_pages,
                                &cur_page_no, &mtr);
    mtr_commit(&mtr);
    ok(n_pages == load_n_pages, "test_btr_index_can_be_reclaimed: "
            "1 load 64 pages, n_pages:[%u]: succeed",
            n_pages);

    for (uint i = 0; i < load_n_pages; i++) {
        if (blocks[i] == NULL) {
            ret = false;
        } else {
            blocks[i]->page.buf_fix_count = 1;
        }
    }
    ok(ret, "test_btr_index_can_be_reclaimed: "
            "2 check load 64 pages: succeed");

    /* check index can be reclaimed */
    btr_reclaim_item_t *r_item = new btr_reclaim_item_t(index_c);
    mtr_start(&mtr);
    ret = btr_index_can_be_reclaimed(r_item, SPACE_ID, 8192, blocks, n_pages, &mtr);
    mtr_commit(&mtr);
    ok(ret, "test_btr_index_can_be_reclaimed: "
            "3 check pages can be reclaimed: succeed");
}

/**
 * Test btr_get_first_free_page_no
 * 1 test get first free page_no is 3
*/
void test_btr_get_first_free_page_no() {
    ulint page_no = btr_get_first_free_page_no(SPACE_ID, index_c, 8192, 0);
    ok(page_no == 3, "test_btr_get_first_free_page_no: "
            "1 test get first free page_no:[%lu] is 3: succeed",
            page_no);
}

/**
 * Test btr_get_fseg_header
 * 1 test get fsegment header is not NULL
*/
void test_btr_get_fseg_header() {
    fseg_header_t* seg_header = NULL;
    mtr_t mtr;
    index_c->page = CLUST_LEAF_PAGE;
    index_c->table = table;
    mtr_start(&mtr);
    seg_header = btr_get_fseg_header(index_c, 0, &mtr);
    mtr_commit(&mtr);
    ok(seg_header != NULL, "test_btr_get_fseg_header: "
            "1 test get fsegment header is not NULL: succeed");
}
/**
 * Test btr_load_n_pages
 * 1 test 10 pages is not NULL
 * 2 test load 10 pages
*/
void test_btr_load_n_pages() {
    uint n_pages = 0;
    buf_block_t *blocks[10];
    ulint cur_page_no = 1023;
    mtr_t mtr;
    bool ret = true;
    for (int i = 0; i < 10; i++) {
        blocks[i] = NULL;
    }
    mtr_start(&mtr);
    n_pages = btr_load_n_pages(SPACE_ID, 8192, blocks, 10,
                                &cur_page_no, &mtr);
    mtr_commit(&mtr);

    for (int i = 0; i < 10; i++) {
        if (blocks[i] == NULL) {
            ret = false;
        }
        ok(blocks[i] != NULL, "test_btr_load_n_pages: "
                "1 test [%d] pages is not NULL", i);
    }
    ok(n_pages == 10 && ret, "test_btr_load_n_pages: "
            "2 test load 10 pages: succeed");
}

/**
 * Test btr_gen_defragment_item_for_table
 * 1 test add defragment item
 * 2 test generate existent defragemnt item
 * 3 test remove defragment item
 * 4 test generate defragemnt item failed: check_frag: true frag_rate: 100
 * 5 test generate defragemnt item succeed: check_frag: false frag_rate: 1
*/
void test_btr_gen_defragment_item_for_table() {
    dberr_t err = DB_SUCCESS;
    bool ret = false;
    btr_defragment_item_t* d_item = NULL;

    btr_defragment_add_index(index_c, true, &err);
    ok(err == DB_SUCCESS, "test_btr_gen_defragment_item_for_table: "
            "1 test add defragment item: succeed");

    ret = btr_gen_defragment_item_for_table("sbtest1");
    ok(!ret, "test_btr_gen_defragment_item_for_table: "
            "2 test generate existent defragemnt item: succeed");

    btr_defragment_remove_index(index_c);
    d_item = btr_defragment_get_item();
    ok(d_item == NULL, "test_btr_gen_defragment_item_for_table: "
            "3 test remove defragment item: succeed");

    srv_reclaim_check_frag = true;
    srv_reclaim_frag_rate = 100;
    ret = btr_gen_defragment_item_for_table("sbtest1");
    ok(!ret, "test_btr_gen_defragment_item_for_table: "
            "4 test generate defragemnt item failed: "
            "check_frag: true, frag_rate: 100: succeed");

    srv_reclaim_check_frag = false;
    srv_reclaim_frag_rate = 1;
    ret = btr_gen_defragment_item_for_table("sbtest1");
    ok(ret, "test_btr_gen_defragment_item_for_table: "
            "5 test generate defragemnt item succeed: "
            "check_frag: false frag_rate: 1: succeed");
}


/**
 * Test btr_get_reclabtr_open_table_indexim_page_no
 * 1 test return cluster index of table
 * 2 test open all indexes of table
*/
void test_btr_open_table_index() {
    btr_reclaim_item_t *r_item = new btr_reclaim_item_t(index_c);
    dict_index_t *index = btr_open_table_index(r_item->index_map, "sbtest1");
    ok(index == index_c,
            "test_btr_open_table_index: "
            "1 test return cluster index of table: succeed");
    ok(r_item->index_map.size() == 2,
            "test_btr_open_table_index: "
            "2 test open all indexes of table: succeed");
}

/**
 * Test btr_get_reclaim_page_no
 * 1 test get last page_no
*/
void test_btr_get_reclaim_page_no() {
    btr_reclaim_item_t *r_item = new btr_reclaim_item_t(index_c);
    ulint page_no = btr_get_reclaim_page_no(r_item, fsp_header);
    ok(page_no == 1023, "test_btr_get_reclaim_page_no: "
            "1 test get last page_no: succeed, "
            "last page_no:[%lu]",
            page_no);
}

/**
 * Test btr_reclaim_remove_index
 * 1 test new reclaim item
 * 2 test get reclaim item
 * 3 test remove index
 * 4 test find nonexistent reclaim item
*/
void test_btr_reclaim_remove_index() {
    btr_reclaim_item_t *r_item = new btr_reclaim_item_t(index_c);
    ok(strcmp(r_item->table, "sbtest1") == 0 &&
            r_item->space == SPACE_ID,
            "test_btr_reclaim_remove_index: 1 test new reclaim item: succeed ");

    btr_reclaim_add_item(r_item);
    btr_reclaim_item_t *item = btr_reclaim_get_item();
    ok(item != NULL && strcmp(r_item->table, item->table) == 0, 
            "test_btr_reclaim_remove_index: 2 test get reclaim item: succeed");
    
    btr_reclaim_remove_index(index_c);

    item = btr_reclaim_get_item();
    ok(item == NULL || item->removed == true,
            "test_btr_reclaim_remove_index: 3 test remove table: succeed");
}

/**
 * Test btr_reclaim_remove_table
 * 1 test new reclaim item
 * 2 test get reclaim item
 * 3 test remove table
 * 4 test find nonexistent reclaim item
*/
void test_btr_reclaim_remove_table() {
    btr_reclaim_item_t *r_item = new btr_reclaim_item_t(index_c);
    ok(strcmp(r_item->table, "sbtest1") == 0 &&
            r_item->space == SPACE_ID,
            "test_btr_reclaim_remove_table: 1 test new reclaim item: succeed ");

    btr_reclaim_add_item(r_item);
    btr_reclaim_item_t *item = btr_reclaim_get_item();
    ok(item != NULL && strcmp(r_item->table, item->table) == 0, 
            "test_btr_reclaim_remove_table: 2 test get reclaim item: succeed");
    
    btr_reclaim_remove_table(table);

    item = btr_reclaim_get_item();
    ok(item == NULL || item->removed == true,
            "test_btr_reclaim_remove_table: 3 test remove table: succeed");
}

/**
 * Test test_btr_gen_defragment_item_for_db
*/
void test_btr_gen_defragment_item_for_db() {
    btr_gen_defragment_item_for_db("sbtest");
}

/**
 * Test btr_table_need_to_be_reclaimed
 * 1 test need no FSP_SIZE
 * 2 test write FSP_SIZE
 * 3 test need frag_size: 1
 * 4 test need frag_size: 100, frag_rate: 0
 * 5 test need frag_size: 100, frag_rate: 100
*/
void test_btr_table_need_to_be_reclaimed() {
    mtr_t mtr;
    bool need = true;

    need = btr_table_need_to_be_reclaimed("sbtest", table);
    ok(!need, "test_btr_table_need_to_be_reclaimed: "
            "1 test need no FSP_SIZE: succeed");

    mtr_start(&mtr);
    srv_reclaim_size = 1;
    fsp_header = btr_get_fsp_header(SPACE_ID, 8192, &mtr);
    mlog_write_ulint(fsp_header + FSP_SIZE, 1024, MLOG_4BYTES, &mtr);
    mtr_commit(&mtr);
    ok(mach_read_from_4(fsp_header + FSP_SIZE) == 1024,
            "test_btr_table_need_to_be_reclaimed: "
            "2 test write FSP_SIZE: succeed");

    /* create 1024 pages */
    for (int i = 6; i < 1024; i++) {
        mtr_start(&mtr);
        init_file_page(buf_page_create(SPACE_ID, i, 8192, &mtr));
        mtr_commit(&mtr);

    }
    srv_reclaim_frag_size = 1;
    need = btr_table_need_to_be_reclaimed("sbtest", table);
    ok(need, "test_btr_table_need_to_be_reclaimed: "
            "3 test need frag_size: 1: succeed");

    srv_reclaim_frag_size = 100;
    srv_reclaim_frag_rate = 0;
    need = btr_table_need_to_be_reclaimed("sbtest", table);
    ok(need, "test_btr_table_need_to_be_reclaimed: "
            "4 test need frag_size: 100, frag_rate: 0: succeed");
    
    srv_reclaim_frag_size = 100;
    srv_reclaim_frag_rate = 100;
    need = btr_table_need_to_be_reclaimed("sbtest", table);
    ok(!need, "test_btr_table_need_to_be_reclaimed: "
            "5 test need frag_size: 100, frag_rate: 100: succeed");
}

/**
 * Test btr_get_fsp_header
 * 1 test get not NULL fsp header
*/
void test_btr_get_fsp_header() {
    mtr_t mtr;
    /* 1. test sentinel page */
    ulint fold = buf_page_address_fold(SPACE_ID, HDR_PAGE);
    mtr_start(&mtr);
    buf_pool_t *buf_pool = NULL;
    rw_lock_t *hash_lock = NULL;

    buf_pool = buf_pool_get(SPACE_ID, HDR_PAGE);
    hash_lock = buf_page_hash_lock_get(buf_pool, fold); 
    rw_lock_x_lock(hash_lock);
    ok(buf_pool_watch_set(SPACE_ID, HDR_PAGE, fold) == NULL,
            "test_btr_get_fsp_header: 1 watch HDR_PAGE: succeed");
    rw_lock_x_unlock(hash_lock);

    fsp_header = btr_get_fsp_header(
        SPACE_ID, fil_space_get_zip_size(SPACE_ID), &mtr); 
    mtr_commit(&mtr);
    ok(fsp_header != NULL,
            "test_btr_get_fsp_header: 2 get fsp header: succeed, "
            "zip_size:[%lu]",
            fil_space_get_zip_size(SPACE_ID));
}

/**
 * Test add/get/find/remove item
 * 1 test add item
 * 2 test get item
 * 3 test find item
 * 4 test remove item
*/
void test_btr_reclaim_item() {
    int flags = 0;
    mtr_t mtr;
    dberr_t error;
    // THD *thd = current_thd;
    mem_heap_t *heap = mem_heap_create(450);
    // mem_heap_t *heap_tmp = mem_heap_create(450);
    // page_zip_des_t* page_zip;
    // page_t* page; 
    // int i; 
    // bool failed = FALSE;
    // dtuple_t* tuple;
    //btr_cur_t cursor;
    //byte* rec;
    // int n_uniq;
    // trx_t* trx = NULL;
    // que_thr_t* thr;
    buf_pool_t *buf_pool = NULL;
    rw_lock_t *hash_lock = NULL;

    /* 1. test sentinel page */
    ulint fold = buf_page_address_fold(SPACE_ID, SENTINEL_PAGE);
    mtr_start(&mtr);
    buf_pool = buf_pool_get(SPACE_ID, SENTINEL_PAGE);
    hash_lock = buf_page_hash_lock_get(buf_pool, fold); 
    rw_lock_x_lock(hash_lock);
    ok(buf_pool_watch_set(SPACE_ID, SENTINEL_PAGE, fold) == NULL,
            "test_btr_reclaim_item: 0 watch SENTINEL_PAGE: succeed");
    rw_lock_x_unlock(hash_lock);

    /* 2. page without index info */
    init_file_page(buf_page_create(SPACE_ID, HDR_PAGE, 8192, &mtr));
    init_file_page(buf_page_create(SPACE_ID, BITMAP_PAGE, 8192, &mtr));
    init_file_page(buf_page_create(SPACE_ID, INODE_PAGE, 8192, &mtr));
    test_block1 = buf_page_create(SPACE_ID, CLUST_LEAF_PAGE, 8192, &mtr);
    init_file_page(test_block1);
    test_block2 = buf_page_create(SPACE_ID, SEC_MID_PAGE, 8192, &mtr);
    init_file_page(test_block2);
    test_block3 = buf_page_create(SPACE_ID, SEC_LEAF_PAGE, 8192, &mtr);
    init_file_page(test_block3);
    mtr_commit(&mtr);

    my_pthread_setspecific_ptr(THR_THD,  0);
    mutex_enter(&(dict_sys->mutex));
    flags |= DICT_TF_COMPACT;
    flags |= (0x4 << 1);
    flags |= (0x1 << 5);
    table = dict_mem_table_create("sbtest1", SPACE_ID, 2, flags, 0);
    dict_mem_table_add_col(table, heap, "c1", DATA_INT, 0, 4);
    dict_mem_table_add_col(table, heap, "c2", DATA_VARCHAR, 0, VARCHAR_FIELD_LEN);
    table->id = TEST_TABLE_ID;
    dict_table_add_to_cache(table, FALSE, heap);
    mem_heap_empty(heap);

    /* cluster index */
    index_c = dict_mem_index_create("sbtest1", "i1", SPACE_ID, DICT_UNIQUE | DICT_CLUSTERED, 1);
    dict_mem_index_add_field(index_c, "c1", 0);
    index_c->id = TEST_CLUST_IND_ID;
    error = dict_index_add_to_cache(table, index_c, CLUST_LEAF_PAGE, FALSE);
    ok(error == 10, "test_btr_reclaim_item: "
            "1 add cluster index: succeed");

    /* second index */
    index_s = dict_mem_index_create("sbtest1", "i2", SPACE_ID, 0, 1);
    dict_mem_index_add_field(index_s, "c2", 0);
    index_s->id = TEST_SEC_IND_ID; 
    error = dict_index_add_to_cache(table, index_s, SEC_MID_PAGE, FALSE);
    ok(error == 10, "test_btr_reclaim_item: "
            "2 add second index: succeed");
    mutex_exit(&(dict_sys->mutex));

    mtr_start(&mtr);
    index_c = dict_index_find_on_id_low(TEST_CLUST_IND_ID);
    ok(index_c != NULL, "test_btr_reclaim_item: "
            "3 find the cluster index: succeed");

    index_s = dict_index_find_on_id_low(TEST_SEC_IND_ID);
    ok(index_s != NULL, "test_btr_reclaim_item: "
            "4 find the second index: succeed");

    btr_reclaim_item_t *r_item = new btr_reclaim_item_t(index_c);
    ok(strcmp(r_item->table, "sbtest1") == 0 &&
            r_item->space == SPACE_ID,
            "test_btr_reclaim_item: 5 new reclaim item: succeed "
            "table:[%s], space:[%lu]",
            r_item->table, r_item->space);

    /* test add item */
    btr_reclaim_add_item(r_item);
    btr_reclaim_item_t *item = btr_reclaim_get_item();
    ok(item != NULL,
            "test_btr_reclaim_item: 6 add reclaim item: succeed");

    /* test get item */
    ok(item != NULL && strcmp(r_item->table, item->table) == 0, 
            "test_btr_reclaim_item: 7 get reclaim item: succeed");
    
    /* test find item */
    bool find = btr_find_reclaim_item_with_name("sbtest1");
    ok(find, "test_btr_reclaim_item: 8 find existent reclaim item: succeed");
    find = btr_find_reclaim_item_with_name("test");
    ok(!find, "test_btr_reclaim_item: 9 find nonexistent reclaim item: succeed");

    /* test remove item */
    btr_reclaim_remove_item(r_item);
    item = btr_reclaim_get_item();
    ok(item == NULL, "test_btr_reclaim_item: 10 remove item succeed");
}

/**
 * Test btr_reclaim_add_defragment_item
 * 1 test interval
 * 2 test process srv_reclaim_db
*/
void test_btr_reclaim_add_defragment_item() {
    srv_reclaim_day_interval = 1;
    bool check_interval = false;
    ulonglong last_reclaim_time = 0;
    btr_reclaim_add_defragment_item(&check_interval,
            &last_reclaim_time);
    ok(check_interval,
            "test_btr_reclaim_add_defragment_item: "
            "1 test interval: succeed");
    ok(last_reclaim_time > 0, "test_btr_reclaim_add_defragment_item: "
            "2 test process srv_reclaim_db: succeed");
}

/**
 * Test create, init defragment and reclaim thread.
*/
void test_create() {
    // int i;
    int err;
    char *ret;
    // os_thread_t id[THREADS];
    srv_buf_pool_instances = 8;
    srv_max_n_threads = 1024;
    srv_thread_concurrency = 16;
    srv_buf_pool_size = (1024 * 1024 * 16 * 4);
    srv_log_buffer_size = (1024 * 1024 * 16 * 4 / UNIV_PAGE_SIZE);
    srv_lock_table_size = 5 * (srv_buf_pool_size / UNIV_PAGE_SIZE);
    srv_log_write_ahead_size = 4096;
    srv_log_flush_events = 64;
    srv_log_write_events = 64;
    srv_log_file_size = 1024;
    srv_force_recovery = 3;
    srv_log_write_max_size = 4096;
    srv_log_recent_written_size = 4 * 4096;
    srv_log_recent_closed_size = 4 * 4096;

    init_compiled_charsets(MYF(0));
    os_sync_init();
    sync_init();
    init_tmpdir(&mysql_tmpdir_list, "./");
    lock_sys_create(srv_lock_table_size);
    dict_init();
    fil_init(5000, 300);
    ibool success = fil_space_create("sbtest1", SPACE_ID,
            0x569, FIL_TABLESPACE);
    ok(success, "test_create: 0 create space: succeed");

    ret = fil_node_create("./sbtest1", 16384, SPACE_ID, FALSE);

    ok(ret != NULL,
            "test_create: 1 create test file: succeed, "
            "filename:[%s]", ret);

    srv_latin1_ordering = my_charset_latin1.sort_order;
    trx_sys_create();
    trx_sys->max_trx_id = 1;
    err = buf_pool_init(srv_buf_pool_size, srv_buf_pool_instances);
    ok(err == 10, "test_create: 2 init buffer pool: succeed");
    //undo_init;

    log_sys_init(2, srv_log_file_size * UNIV_PAGE_SIZE,
                SRV_LOG_SPACE_FIRST_ID);
    const lsn_t lsn = LOG_START_LSN + LOG_BLOCK_HDR_SIZE;
    recv_reset_logs(lsn);
    log_t &log = *log_sys;
    log_start(log, 1, lsn, lsn);
    log_start_background_threads(log);

    srv_defragment_interval = 0;
    srv_defragment_frequency = SRV_DEFRAGMENT_FREQUENCY_DEFAULT;
    ut_init_timer();
    btr_defragment_init();
    ok(srv_defragment_interval > 0,
            "test_create: 3 init defragment thread: succeed, "
            "srv_defragment_interval:%llu",
            srv_defragment_interval);
    btr_reclaim_init();
    ok(srv_reclaim_truncate_interval > 0,
            "test_create: 4 init reclaim thread: succeed, "
            "srv_reclaim_truncate_interval:%llu",
            srv_reclaim_truncate_interval);
}
/**
 * Test shutdown, thread will shutdown automatically,
 * we need to check item list whether is empty.
*/
void test_shutdown()
{
    srv_shutdown_state = SRV_SHUTDOWN_CLEANUP;
    my_sleep(1000000);
    btr_defragment_item_t *d_item = btr_defragment_get_item();
    ok(d_item == NULL, "test_shutdown: 1 shutdown defragment thread: succeed");
    btr_reclaim_item_t *r_item = btr_reclaim_get_item();
    ok(r_item == NULL, "test_shutdown: 2 shutdown reclaim thread: succeed");
}

/**
 * Test cal_cpuidle
*/
void test_cal_cpuidle() {
    cpu_stat_t s1;
    cpu_stat_t s2;
    double idle = 0.0;
    get_cpu_stat(&s1);
    my_sleep(1000000);
    get_cpu_stat(&s2);
    idle = cal_cpuidle(&s1, &s2);
    ok(idle > 0,
            "test_cal_cpuidle: 1 calculate CPU idle succeed, "
            "CPU_IDLE:[%lf]", idle);
}

void do_all_tests()
{
    test_create();

    /* Test btr_reclaim_add_defragment_item */
    test_btr_reclaim_add_defragment_item();

    /* Test add/get/find/remove item */
    test_btr_reclaim_item();

    /** Test btr_get_fsp_header */
    test_btr_get_fsp_header();

    /* Test btr_table_need_to_be_reclaimed */
    test_btr_table_need_to_be_reclaimed();

    /* Test test_btr_gen_defragment_item_for_db */
    test_btr_gen_defragment_item_for_db();

    /* Test btr_reclaim_remove_table */
    test_btr_reclaim_remove_table();

    /* Test btr_reclaim_remove_index */
    test_btr_reclaim_remove_index();

    /* Test btr_get_reclaim_page_no */
    test_btr_get_reclaim_page_no();

    /* Test btr_get_reclabtr_open_table_indexim_page_no */
    test_btr_open_table_index();

    /*Test btr_gen_defragment_item_for_table */
    test_btr_gen_defragment_item_for_table();

    /* Test btr_load_n_pages */
    test_btr_load_n_pages();

    /* Test btr_get_fseg_header */
    // test_btr_get_fseg_header(); // failed

    /* Test btr_get_first_free_page_no */
    // test_btr_get_first_free_page_no(); // failed

    /* Test btr_index_can_be_reclaimed */
    test_btr_index_can_be_reclaimed();

    /* Test btr_reclaim_n_pages */
    test_btr_reclaim_n_pages();

    /* Test btr_check_freed */
    test_btr_check_freed();

    /* Test btr_try_to_truncate_ibd */
    // test_btr_try_to_truncate_ibd(); // failed, can not get descr

    test_shutdown();

    test_cal_cpuidle();
}

int main(int, char **)
{
  plan(62);
  MY_INIT("reclaim-t");
  do_all_tests();
  return 0;
}