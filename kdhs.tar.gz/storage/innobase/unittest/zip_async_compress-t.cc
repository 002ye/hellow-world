/* Copyright (c) 2014, , Baidu Inc. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; version 2 of the License.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software Foundation,
  51 Franklin Street, Suite 500, Boston, MA 02110-1335 USA */
//#include "zip_async_compress-t.h"
#include <btr0btr.h>
#include <srv0start.h>
#include "my_sys.h"
#include "buf0buf.h"
#include "mtr0mtr.h"
#include "lock0lock.h"
#include "mysqld.h"
#include <tap.h>
#include <stdio.h>
#include "page0zip.h"
#include "row0ins.h"
#include "pars0pars.h"
#include "trx0rseg.h"
#include "ibuf0ibuf.h"
#include "zlib.h"
#include "lz4.h"

#define THREADS 16
extern os_ib_mutex_t async_compress_mutex;
extern async_compress_slot_t* async_compress_thread_slots;
// cluster leaf page, second leaf page, second middle page
static buf_block_t *test_block1,*test_block2,*test_block3;
#define VARCHAR_FIELD_LEN 1024 
#define SPACE_ID 1
#define CLUST_LEAF_PAGE 3
#define SEC_MID_PAGE 4
#define SEC_LEAF_PAGE 5
#define SENTINEL_PAGE 1024
#define BITMAP_PAGE 1
#define TEST_TABLE_ID 1
#define TEST_CLUST_IND_ID 1
#define TEST_SEC_IND_ID 2
#define CH_NEW_LEN 35
#define CH_LEN 35
#define SMALL_OUT_LEN 35
#define BIG_OUT_LEN 1024
#define DECOMPRESS_OUT_LEN 1024


Bytef ch[35];
Bytef buf[1024];
Bytef small_out[35];
Bytef big_out[1024];
Bytef decompress_out[1024];
Bytef ch_new[35];
z_stream strm;

bool all_slots_are_empty(void)
{
    int i;
    for (i = 0; i < THREADS; i++)
    {
        if (async_compress_thread_slots[i].page.space_no != 0 ||
                async_compress_thread_slots[i].page.page_no != 0 ||
                async_compress_thread_slots[i].page.m_end != 0)
        {
            diag("%lu", async_compress_thread_slots[i].page.space_no);
            break;
        }
    }

    if (i == THREADS)
        return true;
    return false;
}

void make_sec_leaf_tuple(dtuple_t** tuple, mem_heap_t* heap, int var_field_len, int k)
{
    dfield_t* field;
    byte* ptr;
    int i;

    *tuple = dtuple_create(heap, 2);
    //field c2 int data string 
    field = dtuple_get_nth_field(*tuple, 0);
    ptr = static_cast<byte*>(mem_heap_alloc(heap, var_field_len));
    ptr[0] = k;
    ptr[var_field_len-1] = 0x0;
    for (i=1; i<var_field_len-1; i++) 
        ptr[i] = random() % 256;
    dfield_set_data(field, ptr, var_field_len);
    dtype_set(dfield_get_type(field),
            DATA_VARCHAR, 0, VARCHAR_FIELD_LEN);
    //field c1
    field = dtuple_get_nth_field(*tuple, 1);
    ptr = static_cast<byte*>(mem_heap_alloc(heap, 4));
    mach_write_to_4(ptr, k);
    dfield_set_data(field, ptr, 4);
    dtype_set(dfield_get_type(field),
            DATA_INT, 0, 4);
}

void make_cluster_leaf_tuple(dtuple_t** tuple, mem_heap_t* heap, int var_field_len, int k)
{
    dfield_t* field;
    byte* ptr;
    int i;

    *tuple = dtuple_create(heap, 1 + DATA_N_SYS_COLS);
    //field c1
    field = dtuple_get_nth_field(*tuple, 0);
    ptr = static_cast<byte*>(mem_heap_alloc(heap, 4));
    mach_write_to_4(ptr, k);
    dfield_set_data(field, ptr, 4);
    dtype_set(dfield_get_type(field),
            DATA_INT, 0, 4);
    //field  trx_id
    field = dtuple_get_nth_field(*tuple, 1);
    ptr = static_cast<byte*>(mem_heap_alloc(heap, DATA_TRX_ID_LEN));
    memset(ptr, 0, DATA_TRX_ID_LEN); 
    dfield_set_data(field, ptr, DATA_TRX_ID_LEN);
    dtype_set(dfield_get_type(field),
            DATA_SYS, DATA_TRX_ID|DATA_NOT_NULL, DATA_TRX_ID_LEN);

    //field roll_ptr
    field = dtuple_get_nth_field(*tuple, 2);
    ptr = static_cast<byte*>(mem_heap_alloc(heap, DATA_ROLL_PTR_LEN));
    memset(ptr, 0, DATA_ROLL_PTR_LEN); 
    dfield_set_data(field, ptr, DATA_ROLL_PTR_LEN); 
    dtype_set(dfield_get_type(field),
            DATA_SYS, DATA_ROLL_PTR|DATA_NOT_NULL, 4);

    //field c2 int data string 
    field = dtuple_get_nth_field(*tuple, 3);
    ptr = static_cast<byte*>(mem_heap_alloc(heap, var_field_len));
    ptr[var_field_len-1] = 0x0;
    for (i=0; i<var_field_len-1; i++) 
        ptr[i] = random() % 26;
    dfield_set_data(field, ptr, var_field_len);
    dtype_set(dfield_get_type(field),
            DATA_VARCHAR, 0, VARCHAR_FIELD_LEN);
}

void make_sec_mid_tuple(dtuple_t** tuple, mem_heap_t* heap, int var_field_len, int k, int page_no)
{
    dfield_t* field;
    byte* ptr;
    int i;

    *tuple = dtuple_create(heap, 3);
    //field c2 int data string 
    field = dtuple_get_nth_field(*tuple, 0);
    ptr = static_cast<byte*>(mem_heap_alloc(heap, var_field_len));
    ptr[0] = k;
    ptr[var_field_len-1] = 0x0;
    for (i=1; i<var_field_len-1; i++) 
        ptr[i] = random() % 256;
    dfield_set_data(field, ptr, var_field_len);
    dtype_set(dfield_get_type(field),
            DATA_VARCHAR, 0, VARCHAR_FIELD_LEN);
    //field c1
    field = dtuple_get_nth_field(*tuple, 1);
    ptr = static_cast<byte*>(mem_heap_alloc(heap, 4));
    mach_write_to_4(ptr, k);
    dfield_set_data(field, ptr, 4);
    dtype_set(dfield_get_type(field),
            DATA_INT, 0, 4);

    //field node_ptr
    field = dtuple_get_nth_field(*tuple, 2);
    ptr = static_cast<byte*>(mem_heap_alloc(heap, 4));
    mach_write_to_4(ptr, page_no);
    dfield_set_data(field, ptr, 4);
    dtype_set(dfield_get_type(field), DATA_SYS_CHILD, DATA_NOT_NULL, 4);
    dtuple_set_info_bits(*tuple, dtuple_get_info_bits(*tuple)
                             | REC_STATUS_NODE_PTR);
}

void insert_data_to_test_page(buf_block_t* test_block, mem_heap_t* heap, 
        dict_index_t* index, mtr_t* mtr, bool* failed, int n_recs)
{
    page_t* page;
    dtuple_t* tuple;
    //dfield_t* field;
    //byte* ptr;
    //int i;
    int k;
    ulint* offsets = NULL;
    page_cur_t cursor;
    byte *insert_rec, *back_rec;
    page_zip_des_t* page_zip;
    //int rec_size;
    int avail_size;
    int var_field_len = VARCHAR_FIELD_LEN;
    bool is_clust = dict_index_is_clust(index);
    ulint height;

    mtr_start(mtr);
    buf_block_buf_fix_inc(test_block, __FILE__, __LINE__);
    rw_lock_x_lock_inline(&(test_block->lock),
                   0, __FILE__, __LINE__);
    mtr_memo_push(mtr, test_block, MTR_MEMO_PAGE_X_FIX);
    page = buf_block_get_frame(test_block);
    height = btr_page_get_level(page, mtr);
    page_zip = buf_block_get_page_zip(test_block);
    insert_rec = page_get_infimum_rec(page);
    //insert data which is not fit for compress
    for (k=0;k<n_recs;k++)
    {
        if (is_clust)
        {
            make_cluster_leaf_tuple(&tuple, heap, var_field_len, k);
        }else
        {
            //ulint height = btr_page_get_level(page, mtr);
            if (height == 0)
            {
               make_sec_leaf_tuple(&tuple, heap, var_field_len, k); 
            } else
            {
               make_sec_mid_tuple(&tuple, heap, var_field_len, k, k+5);          
            }
        }
        cursor.rec = insert_rec;
        cursor.block = test_block;
        back_rec = insert_rec;
        insert_rec = page_cur_tuple_insert(&cursor, tuple, index, &offsets, &heap, 0, mtr);
        if (insert_rec == NULL)
        {
            if (!btr_page_reorganize_low(FALSE, 6, &cursor, index, mtr, FALSE))
            {
                diag("the page can't be compressed now ^^");
                *failed = TRUE;
                break;
            }
            //rec_size = rec_offs_size(offsets);
            avail_size = page_zip_get_size(page_zip) - page_zip_get_trailer_len(page_zip, is_clust) 
                - PAGE_ZIP_DIR_SLOT_SIZE + (REC_N_NEW_EXTRA_BYTES - 2) - page_zip->m_end;
            //diag("insert failed k is %d, rec_size %d, avail_size %d", k, rec_size, avail_size);
            var_field_len = avail_size - ((height == 1)?17:(is_clust?26:13));
            if (var_field_len <= 0)
            {
                diag("varchar field len < 0, can not create the page con't be compressed");
                break;
            }
            insert_rec = back_rec;
        }
    }
    if (!(*failed))
        page_create_zip(test_block, index, height, 1, mtr);
    mtr_commit(mtr);
}

void undo_init(mtr_t* mtr,mem_heap_t* heap)
{
    //ib_bh_t*    ib_bh;
    trx_rseg_t* rseg = NULL;
    //trx_sysf_t* header;

    //ib_bh = ib_bh_create(
    //    NULL,
    //sizeof(rseg_queue_t), TRX_SYS_N_RSEGS);
    rseg = static_cast<trx_rseg_t*>(mem_heap_alloc(heap, sizeof(*rseg)));
    //rseg = trx_rseg_mem_create(0, 0, 8192, 0, ib_bh, mtr);
    //trx_rseg_array_init(header, ib_bh, mtr);
    //trx_sys->rseg_array = rseg;
    mutex_create(rseg_mutex_key, &rseg->mutex, SYNC_RSEG);
    *((trx_rseg_t**) trx_sys->rseg_array + rseg->id) = rseg;
}

void compress_normal_index_page()
{
    dict_index_t *index;
    dict_table_t *table;
    int flags = 0;
    mtr_t mtr;
    int error;
    THD *thd = current_thd;
    mem_heap_t *heap = mem_heap_create(450);
    mem_heap_t *heap_tmp = mem_heap_create(450);
    page_zip_des_t* page_zip;
    page_t* page; 
    int i; 
    bool failed = FALSE;
    dtuple_t* tuple;
    //btr_cur_t cursor;
    //byte* rec;
    int n_uniq;
    trx_pool_init();
    trx_t* trx = trx_allocate_for_background();
    que_thr_t* thr;
#ifdef UNIV_DEBUG
    dberr_t err;
#endif

    //create the test table and indes in cache
    //test(c1 int primary key, c2 varchar(1024));
    my_pthread_setspecific_ptr(THR_THD,  0);
    mutex_enter(&(dict_sys->mutex));
    flags |= DICT_TF_COMPACT;
    flags |= (0x4 << 1);
    flags |= (0x1 << 5);
    table = dict_mem_table_create("test", SPACE_ID, 2, flags, 0); 
    dict_mem_table_add_col(table, heap, "c1", DATA_INT, 0, 4);
    dict_mem_table_add_col(table, heap, "c2", DATA_VARCHAR, 0, VARCHAR_FIELD_LEN);
    table->id = TEST_TABLE_ID; 
    dict_table_add_to_cache(table, FALSE, heap);
    mem_heap_empty(heap);
    //cluster index
    index = dict_mem_index_create("test", "i1", SPACE_ID, DICT_UNIQUE | DICT_CLUSTERED, 1);
    dict_mem_index_add_field(index, "c1", 0);
    index->id = TEST_CLUST_IND_ID;
    error = dict_index_add_to_cache(table, index, CLUST_LEAF_PAGE, FALSE); 
    //second index
    index = dict_mem_index_create("test", "i2", SPACE_ID, 0, 1);
    dict_mem_index_add_field(index, "c2", 0);
    index->id = TEST_SEC_IND_ID; 
    error = dict_index_add_to_cache(table, index, SEC_MID_PAGE, FALSE);
    mutex_exit(&(dict_sys->mutex));
    skip(error != 10, "create the index in cache failed");
    mtr_start(&mtr);
    index = dict_index_find_on_id_low(TEST_CLUST_IND_ID);
    skip(index == NULL, "can't find the cluster index");

    // compress cluster index
    buf_block_buf_fix_inc(test_block1, __FILE__, __LINE__);
    rw_lock_x_lock_inline(&(test_block1->lock),
                   0, __FILE__, __LINE__);
    mtr_memo_push(&mtr, test_block1, MTR_MEMO_PAGE_X_FIX);
    dict_ind_init();
    page_create_zip(test_block1, index, 0, 1, &mtr);
    page = buf_block_get_frame(test_block1);
    page_zip = buf_block_get_page_zip(test_block1);
    btr_page_set_index_id(page, page_zip, index->id, &mtr);
    mtr_commit(&mtr);
    btr_async_compress_add(SPACE_ID, CLUST_LEAF_PAGE, page_zip->m_end);
    my_sleep(10000);
    ok(all_slots_are_empty() == true, "compress normal cluster page");

#ifdef UNIV_DEBUG
    // async_compress leaf page when insert to the page
    mtr_start(&mtr);
    async_compress_sleep_time = 100000; // async_compress sleep 0.1s
    btr_async_compress_add(SPACE_ID, CLUST_LEAF_PAGE, page_zip->m_end);
    my_sleep(10000);
    make_cluster_leaf_tuple(&tuple, heap, 1024, 6);
    n_uniq = dict_index_get_n_unique(index);
    tuple->n_fields_cmp = n_uniq;
    trx->start_file = __FILE__;
    trx->start_line = __LINE__;
    my_pthread_setspecific_ptr(THR_THD,  thd);
    undo_init(&mtr, heap);
    trx_start_if_not_started_low(trx, true);
    my_pthread_setspecific_ptr(THR_THD,  0);
    thr = pars_complete_graph_for_exec(NULL, trx, heap);
    err = lock_table(0, table, LOCK_IX, thr);
    skip(err != DB_SUCCESS, "lock table failed");
    flags = BTR_NO_UNDO_LOG_FLAG;
    err = row_ins_clust_index_entry_low(flags, BTR_MODIFY_LEAF,
            index, n_uniq, tuple, 0, thr);
    if (err != DB_SUCCESS)
        diag("insert failed %d : %s", err, ut_strerr(err));
    ok(err == DB_SUCCESS && all_slots_are_empty() == true, "test insert when async_compress");
    async_compress_sleep_time = 0;
    mtr_commit(&mtr);
#endif


    //compress cluster page con't be compressed 
    srand(time(NULL));
    for (i=0; i<10; i++)
    {// try 10 times
        insert_data_to_test_page(test_block1, heap, index, &mtr,&failed, 256);
        if (failed)
            break;
    }
    if (failed)
    {
        btr_async_compress_add(SPACE_ID, CLUST_LEAF_PAGE, page_zip->m_end);
        my_sleep(10000);
        ok(all_slots_are_empty() == true, "cluster page which can not be compressed");
    } else
        skip(1, "can not create page con't be compressed");

    // compress second index leaf page
    index = dict_index_find_on_id_low(TEST_SEC_IND_ID);
    skip(index == NULL, "can't find the second index");
    mtr_start(&mtr);
    buf_block_buf_fix_inc(test_block3, __FILE__, __LINE__);
    rw_lock_x_lock_inline(&(test_block3->lock),
                   0, __FILE__, __LINE__);
    mtr_memo_push(&mtr, test_block3, MTR_MEMO_PAGE_X_FIX);
    page_create_zip(test_block3, index, 0, 1, &mtr);
    page = buf_block_get_frame(test_block3);
    page_zip = buf_block_get_page_zip(test_block3);
    btr_page_set_index_id(page, page_zip, index->id, &mtr);
    //my_pthread_setspecific_ptr(THR_THD,  thd);
    mtr_commit(&mtr);
    btr_async_compress_add(SPACE_ID, SEC_LEAF_PAGE, page_zip->m_end);
    my_sleep(10000);
    ok(all_slots_are_empty() == true, "compress normal second page");

    //compress second index page con't be compressed
    failed = FALSE;
    for (i=0; i<10; i++)
    {// try 10 times
        insert_data_to_test_page(test_block3, heap, index, &mtr, &failed, 256);
        if (failed)
            break;
    }
    if (failed)
    {
        btr_async_compress_add(SPACE_ID, SEC_LEAF_PAGE, page_zip->m_end);
        my_sleep(10000);
        ok(all_slots_are_empty() == true, "second page which can not be compressed");
    } else
        skip(1, "can not create page con't be compressed");

    // compress second middle page
    //index = dict_index_find_on_id_low(TEST_SEC_IND_ID);
    //skip(index == NULL, "can't find the second index");
    mtr_start(&mtr);
    buf_block_buf_fix_inc(test_block2, __FILE__, __LINE__);
    rw_lock_x_lock_inline(&(test_block2->lock),
                   0, __FILE__, __LINE__);
    mtr_memo_push(&mtr, test_block2, MTR_MEMO_PAGE_X_FIX);
    page_create_zip(test_block2, index, 1, 1, &mtr);
    page = buf_block_get_frame(test_block2);
    page_zip = buf_block_get_page_zip(test_block2);
    btr_page_set_index_id(page, page_zip, index->id, &mtr);
    //my_pthread_setspecific_ptr(THR_THD,  thd);
    mtr_commit(&mtr);
    btr_async_compress_add(SPACE_ID, SEC_MID_PAGE, page_zip->m_end);
    my_sleep(10000);
    ok(all_slots_are_empty() == true, "compress normal second middle page");

#ifdef UNIV_DEBUG
    // async_compress middle page when insert to leaf page
    mtr_start(&mtr);
    buf_block_buf_fix_inc(test_block3, __FILE__, __LINE__);
    rw_lock_x_lock_inline(&(test_block3->lock),
                   0, __FILE__, __LINE__);
    mtr_memo_push(&mtr, test_block3, MTR_MEMO_PAGE_X_FIX);
    page_create_zip(test_block3, index, 0, 1, &mtr);
    mtr_commit(&mtr);
    insert_data_to_test_page(test_block2, heap, index, &mtr, &failed, 1);
    mtr_start(&mtr);
    async_compress_sleep_time = 100000; // async_compress sleep 0.1s
    btr_async_compress_add(SPACE_ID, SEC_MID_PAGE, page_zip->m_end);
    my_sleep(10000);
    make_sec_leaf_tuple(&tuple, heap, 1024, 6);
    n_uniq = dict_index_get_n_unique(index);
    flags = BTR_NO_UNDO_LOG_FLAG;
    ibuf_use = IBUF_USE_NONE;
    err = row_ins_sec_index_entry_low(flags, BTR_MODIFY_LEAF,
            index, heap_tmp, heap, tuple, 1, thr);
    if (err != DB_SUCCESS)
        diag("insert failed %d : %s", err, ut_strerr(err));
    ok(err == DB_SUCCESS && all_slots_are_empty() == true, "test insert when async_compress middle page");
    async_compress_sleep_time = 0;
    mtr_commit(&mtr);
#endif

    //compress second middle page failed
    mtr_start(&mtr);
    buf_block_buf_fix_inc(test_block2, __FILE__, __LINE__);
    rw_lock_x_lock_inline(&(test_block2->lock),
                   0, __FILE__, __LINE__);
    mtr_memo_push(&mtr, test_block2, MTR_MEMO_PAGE_X_FIX);
    page_create_zip(test_block2, index, 0, 1, &mtr);
    mtr_commit(&mtr);
    failed = FALSE;
    for (i=0; i<10; i++)
    {// try 10 times
        insert_data_to_test_page(test_block2, heap, index, &mtr, &failed, 256);
        if (failed)
            break;
    }
    if (failed)
    {
        btr_async_compress_add(SPACE_ID, SEC_MID_PAGE, page_zip->m_end);
        my_sleep(10000);
        ok(all_slots_are_empty() == true, "second middle page which can not be compressed");
    } else
        skip(1, "can not create page con't be compressed");

    my_pthread_setspecific_ptr(THR_THD,  thd);
    mem_heap_free(heap);
}

// copy from server which defined as static 
void
init_file_page(
/*===================*/
	buf_block_t*	block)	/*!< in: pointer to a page */
{
	page_t*		page	= buf_block_get_frame(block);
	page_zip_des_t*	page_zip= buf_block_get_page_zip(block);

#ifndef UNIV_HOTBACKUP
	block->check_index_page_at_flush = FALSE;
#endif /* !UNIV_HOTBACKUP */

	if (page_zip) {
		memset(page, 0, UNIV_PAGE_SIZE);
		memset(page_zip->data, 0, page_zip_get_size(page_zip));
		mach_write_to_4(page + FIL_PAGE_OFFSET,
				buf_block_get_page_no(block));
		mach_write_to_4(page
				+ FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID,
				buf_block_get_space(block));
		memcpy(page_zip->data + FIL_PAGE_OFFSET,
		       page + FIL_PAGE_OFFSET, 4);
		memcpy(page_zip->data + FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID,
		       page + FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID, 4);
		return;
	}

	memset(page, 0, UNIV_PAGE_SIZE);
	mach_write_to_4(page + FIL_PAGE_OFFSET, buf_block_get_page_no(block));
	mach_write_to_4(page + FIL_PAGE_ARCH_LOG_NO_OR_SPACE_ID,
			buf_block_get_space(block));
}



void test_compress_page()
{
    mtr_t init_mtr;
    //buf_block_t *block;
    buf_pool_t *buf_pool;
    rw_lock_t *hash_lock;

    /* 1. test sentinel page */
    ulint fold = buf_page_address_fold(SPACE_ID, SENTINEL_PAGE);
    mtr_start(&init_mtr);
    buf_pool = buf_pool_get(SPACE_ID, SENTINEL_PAGE);
    hash_lock = buf_page_hash_lock_get(buf_pool, fold); 
    rw_lock_x_lock(hash_lock);
    skip(buf_pool_watch_set(SPACE_ID, SENTINEL_PAGE, fold) != NULL, "can not create sentinel page");
    rw_lock_x_unlock(hash_lock);
    btr_async_compress_add(SPACE_ID, SENTINEL_PAGE, 0);
    my_sleep(10000);
    ok(all_slots_are_empty() == true, "compress sentinel page");

    /* 2. page without index info */
    init_file_page(buf_page_create(SPACE_ID, BITMAP_PAGE, 8192, &init_mtr)); 
    test_block1 = buf_page_create(SPACE_ID, CLUST_LEAF_PAGE, 8192, &init_mtr);
    init_file_page(test_block1);
    test_block2 = buf_page_create(SPACE_ID, SEC_MID_PAGE, 8192, &init_mtr);
    init_file_page(test_block2);
    test_block3 = buf_page_create(SPACE_ID, SEC_LEAF_PAGE, 8192, &init_mtr);
    init_file_page(test_block3);
    mtr_commit(&init_mtr);
    btr_async_compress_add(SPACE_ID, CLUST_LEAF_PAGE, 0);
    my_sleep(10000);
    ok(all_slots_are_empty() == true, "compress page without index struct");

    /* 3. normal page */
    compress_normal_index_page();
}

void test_add_page()
{
    /* test different space_no and page_no and m_end */
    btr_async_compress_add(0x0,0x0,0x0);
    my_sleep(10000); // sleep 10 ms 
    ok(all_slots_are_empty() == true, "0,0,0");
    btr_async_compress_add(0x0,0x0,0xFFFFFFFFFFFFFFFF);
    my_sleep(10000); // sleep 10 ms 
    ok(all_slots_are_empty() == true, "0,0,max");
    btr_async_compress_add(0x0,0xFFFFFFFFFFFFFFFF,0x0);
    my_sleep(10000); // sleep 10 ms 
    ok(all_slots_are_empty() == true, "0,max,0");
    btr_async_compress_add(0x0,0xFFFFFFFFFFFFFFFF,0xFFFFFFFFFFFFFFFF);
    my_sleep(10000); // sleep 10 ms 
    ok(all_slots_are_empty() == true, "0,max,max");
    btr_async_compress_add(0xFFFFFFFFFFFFFFFF,0x0,0x0);
    my_sleep(10000); // sleep 10 ms 
    ok(all_slots_are_empty() == true, "max,0,0");
    btr_async_compress_add(0xFFFFFFFFFFFFFFFF,0x0,0xFFFFFFFFFFFFFFFF);
    my_sleep(10000); // sleep 10 ms 
    ok(all_slots_are_empty() == true, "max,0,max");
    btr_async_compress_add(0xFFFFFFFFFFFFFFFF,0xFFFFFFFFFFFFFFFF,0x0);
    my_sleep(10000); // sleep 10 ms 
    ok(all_slots_are_empty() == true, "max,max,0");
    btr_async_compress_add(0xFFFFFFFFFFFFFFFF,0xFFFFFFFFFFFFFFFF,0xFFFFFFFFFFFFFFFF);
    my_sleep(10000); // sleep 10 ms 
    ok(all_slots_are_empty() == true, "max,max,max");
}

void test_create()
{
    int i;
    int err;
    char *ret;

    //init the innobase for test, call innobase_start_or_create_for_mysql?
    os_thread_t id[THREADS];
    srv_buf_pool_instances = 8;
    srv_max_n_threads = 1024;
    srv_thread_concurrency = 16;
    srv_buf_pool_size = (1024*1024*8);
    srv_log_buffer_size = (1024*1024*8/UNIV_PAGE_SIZE);
    srv_lock_table_size = 5 * (srv_buf_pool_size / UNIV_PAGE_SIZE);
    init_compiled_charsets(MYF(0));
    os_sync_init();
    sync_init();
    init_tmpdir(&mysql_tmpdir_list, "./");
    
    srv_buf_pool_instances = 8;
    srv_max_n_threads = 1024;
    srv_thread_concurrency = 16;
    srv_buf_pool_size = (1024*1024*8);
    srv_log_buffer_size = (1024*1024*8/UNIV_PAGE_SIZE);
    srv_lock_table_size = 5 * (srv_buf_pool_size / UNIV_PAGE_SIZE);
    srv_log_write_ahead_size = 4096;
    srv_log_write_events = 64;
	srv_log_flush_events = 64;
    srv_force_recovery = 3;
    srv_log_file_size = 1024;
    srv_log_write_max_size = 4096;
    srv_log_recent_written_size = 4 * 4096;
    srv_log_recent_closed_size = 4 * 4096;
 
    lock_sys_create(srv_lock_table_size);
    dict_init();
    fil_init(5000,300);
    fil_space_create("test", 1 , 0x569, FIL_TABLESPACE);
    ret = fil_node_create("./test", 16384, 1, FALSE);
    skip(ret == NULL, "create test file failed");
    srv_latin1_ordering = my_charset_latin1.sort_order;
    trx_sys_create();
    trx_sys->max_trx_id = 1;
    err = buf_pool_init(srv_buf_pool_size, srv_buf_pool_instances);
    skip(err != 10, "init buffer pool failed");
    //undo_init;

    log_sys_init(2, srv_log_file_size * UNIV_PAGE_SIZE,
            SRV_LOG_SPACE_FIRST_ID);
	log_t &log = *log_sys;
	const lsn_t lsn = LOG_START_LSN + LOG_BLOCK_HDR_SIZE;
	recv_reset_logs(lsn);
	log_start(log, 1, lsn, lsn);
	log_start_background_threads(log);

    async_compress_init(THREADS);
    for (i = 0; i < THREADS; i++)
    {
        os_thread_create(buf_pool_reorganize_page_thread,
                (void*)(async_compress_thread_slots + i), &id[i]); 
        if (id[i] == (os_thread_t)0)
            break;
    }
    skip(i != THREADS, "can not create 16 threads");
    my_sleep(100000);//wait all the threads to startup
    for (i = 0; i < THREADS; i++)
        btr_async_compress_add(1,i,1);
    my_sleep(100000);
    ok(all_slots_are_empty() == true, "16 threads have ran");
}

void test_shutdown()
{
    int i;
    srv_shutdown_state = SRV_SHUTDOWN_CLEANUP;
    async_compress_wake_all_shutdown(THREADS);
    my_sleep(100000);//wait all the threads exit
    for (i = 0; i < THREADS; i++)
        btr_async_compress_add(1,i,1);
    for (i=0; i<THREADS; i++)
    {
        if (async_compress_thread_slots[i].page.space_no != 1 ||
                async_compress_thread_slots[i].page.m_end !=1)
            break;
    }
    ok(i == THREADS, "all %d threads exit", i);
    async_compress_free(THREADS);
    ok(async_compress_thread_slots == NULL, "threads are freed");
}

/*the compress interfaces*/
int deflate_lz4( z_stream* strm, int flush)
{
    uint len;
	if (strm->avail_in > 0) {
		memcpy(strm->buf_tmp + strm->len, strm->next_in, strm->avail_in);//memcpy(*dest,*src,size)
		strm->len += strm->avail_in;
		strm->next_in += strm->avail_in;
		strm->total_in += strm->avail_in;
		strm->avail_in = 0;
	}

	if(Z_FULL_FLUSH == flush) {
		memmove(strm->buf_tmp + sizeof(uint), strm->buf_tmp, strm->len);
        *(uint*)strm->buf_tmp = strm->len;
		strm->len += sizeof(uint);
	}

    if (Z_FINISH == flush) {
		fprintf(stderr,"into Z_FINISH IF!!!!\n");
        len = LZ4_compress_limitedOutput((const char*) strm->buf_tmp, 
                (char*)(strm->next_out + sizeof(uint)), strm->len, strm->avail_out);
        if(len == 0 || (len + sizeof(uint) > strm->avail_out)) {
			fprintf(stderr,"finish 3nd IF with !!!ERROR!!!\n");
            return Z_STREAM_ERROR;
        }
        /* total len */
        *(uint*)(strm->next_out) = len;
		fprintf(stderr,"len after compress = %u\n",len);
        strm->avail_out -= (len + sizeof(uint));
        strm->total_out += (len + sizeof(uint));
        strm->next_out += (len + sizeof(uint));
        strm->len = 0;

        return Z_STREAM_END;
	}
	return Z_OK;
}

/** the decompress interfaces */
int 
inflate_lz4(
z_stream* strm,
int flush)
{
	uint len = 0;
	uint in_len;
	if(Z_BLOCK == flush) {
        int de_len = 0;
        fprintf(stderr,"Decompress into 1st IF!!!!\n");
        in_len = *(uint*)strm->next_in;
		strm->next_in += sizeof(uint);
        strm->total_in += sizeof(uint);
		strm->avail_in -= sizeof(uint);
        de_len = LZ4_decompress_safe ((const char*) strm->next_in, 
                                        (char *)strm->buf_tmp, in_len, strm->avail_out);
        if (de_len < 0) {
            fprintf(stderr, "decompress failed: in_len %u, avail_out %u, delen %d\n", 
                    in_len, strm->avail_out, de_len);
            return Z_STREAM_ERROR;
        }
        strm->total_in += in_len;
        strm->next_in += in_len;
        strm->avail_in -= in_len;
        strm->len = (uint)de_len; /* total out, negative has returned */

        len = *(uint*)strm->buf_tmp;
        strm->total_out += sizeof(uint);
        memcpy(strm->next_out, strm->buf_tmp + strm->total_out, len);
        strm->next_out += len;
        strm->avail_out -= len;
        strm->total_out += len;
        ok(de_len >= 0,"finish Z_BLOCK IF!!!!");
		return Z_OK;
	}

	if (strm->avail_out > 0) { 
		memcpy(strm->next_out, strm->buf_tmp + strm->total_out, strm->avail_out);
		strm->next_out += strm->avail_out;
		strm->total_out += strm->avail_out;
		strm->avail_out -= strm->avail_out;
		fprintf(stderr,"Decompress into 2nd IF!!!!\n");
	}

	if (flush == Z_SYNC_FLUSH || flush == Z_FINISH) {
		if (strm->total_out >= strm->len) 
		{   fprintf(stderr,"Decompress into 3rd IF!!!!\n");
			return Z_STREAM_END;
		}
	}
	return Z_OK;
}

static int
init_strm(z_stream* strm)
{
    strm->next_in = NULL;
	strm->avail_in = 0;
	strm->total_in = 0;
	strm->next_out = NULL;
	strm->avail_out = 1000;
	strm->total_out = 0;
	strm->msg = NULL;
	strm->state = NULL;
	strm->zalloc = NULL;
	strm->zfree = NULL;
	strm->opaque = NULL;
	strm->data_type = 0;
	strm->adler = 0;
	strm->reserved = 0;
	strm->buf_tmp = NULL;
	strm->len =0;
	return Z_OK;

}

void init_a_compress_case()
{
	init_strm(&strm);
	memcpy(ch_new, "abcdefghijklmnopqrstuvwxyzxyzxyzxyz",35);
	strm.next_in = ch_new;
	strm.avail_in = CH_NEW_LEN;
	strm.buf_tmp = buf;
	strm.next_out = big_out;
    deflate_lz4(&strm,Z_NO_FLUSH);
	deflate_lz4(&strm,Z_FULL_FLUSH);
	deflate_lz4(&strm,Z_FINISH);
}

void compress_and_decompress_branch()
{
	init_strm(&strm);
	memcpy(ch, "abcdefghijklmnopqrstuvwxyzxyzxyzxyz",35);
	/*Compress branches*/
	/* Z_NO_FLUSH case */
	strm.next_in = ch;
	strm.avail_in = CH_LEN;
	strm.buf_tmp = buf;
	strm.next_out = big_out;
	deflate_lz4(&strm, Z_NO_FLUSH);
	ok(strm.total_in == 35,"finish 1st IF!!!!");
	/*Z_FULL_FLUSH case*/
	deflate_lz4(&strm, Z_FULL_FLUSH);
	ok(strm.len == (35+sizeof(uint)),"finish 2nd IF!!!!");
	/*Z_FINISH case (with & without error)*/
	deflate_lz4(&strm,Z_FINISH);
	ok(strm.len == 0,"finish 3nd IF!!!!");
	init_strm(&strm);
	strm.next_in = ch;
	strm.avail_in = CH_LEN;
	strm.buf_tmp = buf;
	strm.next_out = small_out;
    strm.avail_out = SMALL_OUT_LEN;
	deflate_lz4(&strm,Z_FINISH);

    /*Decompress branches*/
	init_a_compress_case();	
	strm.next_in = big_out;
	strm.avail_in = BIG_OUT_LEN;
    strm.next_out = decompress_out;
	strm.avail_out = DECOMPRESS_OUT_LEN;
	inflate_lz4(&strm,Z_BLOCK);
	ok(strm.avail_out > 0,"avail_out>0");
    inflate_lz4(&strm,Z_FINISH);
	ok(*(uint*)strm.buf_tmp == CH_NEW_LEN,"decompress length succeed!!!");
	memmove(strm.buf_tmp, strm.buf_tmp + sizeof(uint), *(uint*)strm.buf_tmp);
    ok(memcmp(strm.buf_tmp, ch_new, CH_NEW_LEN) == 0, "decompress succeed!!!");
}

void do_all_tests()
{
    test_create();
    test_add_page();
    test_compress_page();
    test_shutdown();
    compress_and_decompress_branch();

}

int main(int, char **)
{
  plan(28);
  MY_INIT("zip_async_compress-t");
  do_all_tests();
  return 0;
}
