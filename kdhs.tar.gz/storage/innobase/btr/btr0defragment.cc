/*****************************************************************************

Copyright (C) 2013, 2014 Facebook, Inc. All Rights Reserved.
Copyright (C) 2014, 2015, MariaDB Corporation. All Rights Reserved.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Suite 500, Boston, MA 02110-1335 USA

*****************************************************************************/
/**************************************************//**
@file btr/btr0defragment.cc
Index defragmentation.

Created  05/29/2014 Rongrong Zhong
Modified 16/07/2014 Sunguck Lee
Modified 30/07/2014 Jan Lindström jan.lindstrom@mariadb.com
*******************************************************/

#include <log.h>
#include "btr0defragment.h"
#ifndef UNIV_HOTBACKUP
#include "btr0cur.h"
#include "btr0sea.h"
#include "btr0pcur.h"
#include "dict0stats.h"
#include "dict0stats_bg.h"
#include "ibuf0ibuf.h"
#include "lock0lock.h"
#include "srv0start.h"
#include "ut0timer.h"
#include "dict0priv.h"
#include "dict0boot.h"

#include <list>
#include <map>

/**************************************************//**
Custom nullptr implementation for under g++ 4.6
*******************************************************/
// #pragma once
/*
namespace std
{
 // based on SC22/WG21/N2431 = J16/07-0301
 struct nullptr_t
 {
 template<typename any> operator any * () const
 {
 return 0;
 }
 template<class any, typename T> operator T any:: * () const
 {
 return 0;
 }

#ifdef _MSC_VER
 struct pad {};
 pad __[sizeof(void*)/sizeof(pad)];
#else
 char __[sizeof(void*)];
#endif
private:
 // nullptr_t();// {}
 // nullptr_t(const nullptr_t&);
 // void operator = (const nullptr_t&);
 void operator &() const;
 template<typename any> void operator +(any) const
 {
 // I Love MSVC 2005!
 }
 template<typename any> void operator -(any) const
 {
 // I Love MSVC 2005!
 }
 };
static const nullptr_t __nullptr = {};
}

#ifndef nullptr
#define nullptr std::__nullptr
#endif
*/

/**************************************************//**
End of Custom nullptr implementation for under g++ 4.6
*******************************************************/

/* When there's no work, either because defragment is disabled, or because no
query is submitted, thread checks state every BTR_DEFRAGMENT_SLEEP_IN_USECS.*/
#define BTR_DEFRAGMENT_SLEEP_IN_USECS        1000000

/* When there's no work, either because reclaim is disabled, or because no
query is submitted, thread checks state every BTR_DEFRAGMENT_SLEEP_IN_USECS.*/
#define BTR_RECLAIM_SLEEP_IN_USECS        1000000

/* Reduce the target page size by this amount when compression failure happens
during defragmentaiton. 512 is chosen because it's a power of 2 and it is about
3% of the page size. When there are compression failures in defragmentation,
our goal is to get a decent defrag ratio with as few compression failure as
possible. From experimentation it seems that reduce the target size by 512 every
time will make sure the page is compressible within a couple of iterations. */
#define BTR_DEFRAGMENT_PAGE_REDUCTION_STEP_SIZE    512

/* Work queue for defragmentation. */
typedef std::list<btr_defragment_item_t*>    btr_defragment_wq_t;
static btr_defragment_wq_t    btr_defragment_wq;

/* Mutex protecting the defragmentation work queue.*/
ib_mutex_t        btr_defragment_mutex;
#ifdef UNIV_PFS_MUTEX
UNIV_INTERN mysql_pfs_key_t    btr_defragment_mutex_key;
#endif /* UNIV_PFS_MUTEX */

typedef std::list<btr_reclaim_item_t*>    btr_reclaim_wq_t;
static btr_reclaim_wq_t    btr_reclaim_wq;

ib_mutex_t      btr_reclaim_mutex;
#ifdef UNIV_PFS_MUTEX
UNIV_INTERN mysql_pfs_key_t    btr_reclaim_mutex_key;
#endif /* UNIV_PFS_MUTEX */

/* Number of compression failures caused by defragmentation since server
start. */
ulint btr_defragment_compression_failures = 0;
/* Number of btr_defragment_n_pages calls that altered page but didn't
manage to release any page. */
ulint btr_defragment_failures = 0;
/* Total number of btr_defragment_n_pages calls that altered page.
The difference between btr_defragment_count and btr_defragment_failures shows
the amount of effort wasted. */
ulint btr_defragment_count = 0;

/******************************************************************//**
Constructor for btr_defragment_item_t. */
btr_defragment_item_t::btr_defragment_item_t(
    btr_pcur_t* pcur,
    os_event_t event,
    dict_index_t* index,
    ulint space)
{
    this->pcur = pcur;
    this->event = event;
    this->removed = false;
    this->last_processed = 0;
    this->index = index;
    this->space = space;
}

/******************************************************************//**
Destructor for btr_defragment_item_t. */
btr_defragment_item_t::~btr_defragment_item_t() {
    if (this->pcur) {
        btr_pcur_free_for_mysql(this->pcur);
    }
    if (this->event) {
        os_event_set(this->event);
    }
}

/******************************************************************//**
Initialize defragmentation. */
void
btr_defragment_init()
{
    srv_defragment_interval = ut_microseconds_to_timer(
        1000000.0 / srv_defragment_frequency);
    mutex_create(btr_defragment_mutex_key, &btr_defragment_mutex,
             SYNC_ANY_LATCH);
    os_thread_create(btr_defragment_thread, NULL, NULL);
}

/******************************************************************//**
Shutdown defragmentation. Release all resources. */
void
btr_defragment_shutdown()
{
    mutex_enter(&btr_defragment_mutex);
    list< btr_defragment_item_t* >::iterator iter = btr_defragment_wq.begin();
    while (iter != btr_defragment_wq.end()) {
        btr_defragment_item_t* item = *iter;
        iter = btr_defragment_wq.erase(iter);
        delete item;
    }
    mutex_exit(&btr_defragment_mutex);
    mutex_free(&btr_defragment_mutex);
}


/******************************************************************//**
Functions used by the query threads: btr_defragment_xxx_index
Query threads find/add/remove index. */
/******************************************************************//**
Check whether the indexes of table are in btr_defragment_wq. We use index->space
to identify. */
bool
btr_defragment_find_index_by_space(ulint space) {
    mutex_enter(&btr_defragment_mutex);
    for (list< btr_defragment_item_t* >::iterator iter = btr_defragment_wq.begin();
            iter != btr_defragment_wq.end();
            ++iter) {
        btr_defragment_item_t* item = *iter;
        if (space == item->space) {
            mutex_exit(&btr_defragment_mutex);
            return true;
        }
    }
    mutex_exit(&btr_defragment_mutex);
    return false;
}
/******************************************************************//**
Check whether the given index is in btr_defragment_wq. We use index->id
to identify indices. */
bool
btr_defragment_find_index(
    dict_index_t*    index)    /*!< Index to find. */
{
    mutex_enter(&btr_defragment_mutex);
    for (list< btr_defragment_item_t* >::iterator iter = btr_defragment_wq.begin();
         iter != btr_defragment_wq.end();
         ++iter) {
        btr_defragment_item_t* item = *iter;
        btr_pcur_t* pcur = item->pcur;
        btr_cur_t* cursor = btr_pcur_get_btr_cur(pcur);
        dict_index_t* idx = btr_cur_get_index(cursor);
        if (index->id == idx->id) {
            mutex_exit(&btr_defragment_mutex);
            return true;
        }
    }
    mutex_exit(&btr_defragment_mutex);
    return false;
}

/******************************************************************//**
Query thread uses this function to add an index to btr_defragment_wq.
Return a pointer to os_event for the query thread to wait on if this is a
synchronized defragmentation. */
os_event_t
btr_defragment_add_index(
    dict_index_t*    index,    /*!< index to be added  */
    bool        async,    /*!< whether this is an async
                defragmentation */
    dberr_t*    err)    /*!< out: error code */
{
    mtr_t mtr;
    ulint space = dict_index_get_space(index);
    ulint zip_size = dict_table_zip_size(index->table);
    ulint page_no = dict_index_get_page(index);
    *err = DB_SUCCESS;

    mtr_start(&mtr);
    // Load index rood page.
    buf_block_t* block = btr_block_get(space, zip_size, page_no, RW_NO_LATCH, index, &mtr);
    page_t* page = NULL;

    if (block) {
        page = buf_block_get_frame(block);
    }
    /*
    if (page == NULL && index->table->is_encrypted) {
        mtr_commit(&mtr);
        *err = DB_DECRYPTION_FAILED;
        return NULL;
    }
    */

    if (btr_page_get_level(page, &mtr) == 0) {
        // Index root is a leaf page, no need to defragment.
        mtr_commit(&mtr);
        return NULL;
    }
    btr_pcur_t* pcur = btr_pcur_create_for_mysql();
    os_event_t event = NULL;
    // create event for sync
    if (!async) {
        event = os_event_create();
    }
    // open pcur from left: set the cursor object to 
    // point before the first user record (infimum) on the page
    btr_pcur_open_at_index_side(true, index, BTR_SEARCH_LEAF, pcur,
                    true, 0, &mtr);
    // set pcur to point first user record
    btr_pcur_move_to_next(pcur, &mtr);
    btr_pcur_store_position(pcur, &mtr);
    mtr_commit(&mtr);
    dict_stats_empty_defrag_summary(index);
    btr_defragment_item_t*    item = new btr_defragment_item_t(pcur, event, index, space);
    mutex_enter(&btr_defragment_mutex);
    btr_defragment_wq.push_back(item);
    mutex_exit(&btr_defragment_mutex);
    return event;
}

/******************************************************************//**
When table is dropped, this function is called to mark a table as removed in
btr_efragment_wq. The difference between this function and the remove_index
function is this will not NULL the event. */
void
btr_defragment_remove_table(
    dict_table_t*    table)    /*!< Index to be removed. */
{
    mutex_enter(&btr_defragment_mutex);
    for (list< btr_defragment_item_t* >::iterator iter = btr_defragment_wq.begin();
         iter != btr_defragment_wq.end();
         ++iter) {
        btr_defragment_item_t* item = *iter;
        btr_pcur_t* pcur = item->pcur;
        btr_cur_t* cursor = btr_pcur_get_btr_cur(pcur);
        dict_index_t* idx = btr_cur_get_index(cursor);
        if (table->id == idx->table->id) {
            item->removed = true;
        }
    }
    mutex_exit(&btr_defragment_mutex);
}

/******************************************************************//**
Query thread uses this function to mark an index as removed in
btr_efragment_wq. */
void
btr_defragment_remove_index(
    dict_index_t*    index)    /*!< Index to be removed. */
{
    mutex_enter(&btr_defragment_mutex);
    for (list< btr_defragment_item_t* >::iterator iter = btr_defragment_wq.begin();
         iter != btr_defragment_wq.end();
         ++iter) {
        btr_defragment_item_t* item = *iter;
        btr_pcur_t* pcur = item->pcur;
        btr_cur_t* cursor = btr_pcur_get_btr_cur(pcur);
        dict_index_t* idx = btr_cur_get_index(cursor);
        if (index->id == idx->id) {
            item->removed = true;
            item->event = NULL;
            break;
        }
    }
    mutex_exit(&btr_defragment_mutex);
}

/******************************************************************//**
Functions used by defragmentation thread: btr_defragment_xxx_item.
Defragmentation thread operates on the work *item*. It gets/removes
item from the work queue. */
/******************************************************************//**
Defragment thread uses this to remove an item from btr_defragment_wq.
When an item is removed from the work queue, all resources associated with it
are free as well. */
void
btr_defragment_remove_item(
    btr_defragment_item_t*    item) /*!< Item to be removed. */
{
    mutex_enter(&btr_defragment_mutex);
    for (list< btr_defragment_item_t* >::iterator iter = btr_defragment_wq.begin();
         iter != btr_defragment_wq.end();
         ++iter) {
        if (item == *iter) {
            btr_defragment_wq.erase(iter);
            delete item;
            break;
        }
    }
    mutex_exit(&btr_defragment_mutex);
}

/******************************************************************//**
Defragment thread uses this to get an item from btr_defragment_wq to work on.
The item is not removed from the work queue so query threads can still access
this item. We keep it this way so query threads can find and kill a
defragmentation even if that index is being worked on. Be aware that while you
work on this item you have no lock protection on it whatsoever. This is OK as
long as the query threads and defragment thread won't modify the same fields
without lock protection.
*/
btr_defragment_item_t*
btr_defragment_get_item()
{
    if (btr_defragment_wq.empty()) {
        return NULL;
        //return nullptr;
    }

    /* If there is a running reclaim item, we will pause defragment. */
    if (srv_reclaim) {
        mutex_enter(&btr_reclaim_mutex);
        list<btr_reclaim_item_t*>::iterator iter = btr_reclaim_wq.begin();
        for (; iter != btr_reclaim_wq.end(); iter++) {
            if (!(*iter)->removed) {
                /* Found a running item, return NULL to pause defragment. */
                mutex_exit(&btr_reclaim_mutex);
                return NULL;
            }
        }
        mutex_exit(&btr_reclaim_mutex);
    }

    mutex_enter(&btr_defragment_mutex);
    list< btr_defragment_item_t* >::iterator iter = btr_defragment_wq.begin();
    if (iter == btr_defragment_wq.end()) {
        iter = btr_defragment_wq.begin();
    }
    btr_defragment_item_t* item = *iter;
    iter++;
    mutex_exit(&btr_defragment_mutex);
    return item;
}

/*********************************************************************//**
Check whether we should save defragmentation statistics to persistent storage.
Currently we save the stats to persistent storage every 100 updates. */
UNIV_INTERN
void
btr_defragment_save_defrag_stats_if_needed(
    dict_index_t*    index)    /*!< in: index */
{
    if (srv_defragment_stats_accuracy != 0 // stats tracking disabled
        && dict_index_get_space(index) != 0 // do not track system tables
        && index->stat_defrag_modified_counter
           >= srv_defragment_stats_accuracy) {
        dict_stats_defrag_pool_add(index);
        index->stat_defrag_modified_counter = 0;
    }
}

/*********************************************************************//**
Main defragment functionalities used by defragment thread.*/
/*************************************************************//**
Calculate number of records from beginning of block that can
fit into size_limit
@return number of records */
UNIV_INTERN
ulint
btr_defragment_calc_n_recs_for_size(
    buf_block_t* block,    /*!< in: B-tree page */
    dict_index_t* index,    /*!< in: index of the page */
    ulint size_limit,    /*!< in: size limit to fit records in */
    ulint* n_recs_size)    /*!< out: actual size of the records that fit
                in size_limit. */
{
    page_t* page = buf_block_get_frame(block);
    ulint n_recs = 0;
    ulint offsets_[REC_OFFS_NORMAL_SIZE];
    ulint* offsets = offsets_;
    rec_offs_init(offsets_);
    mem_heap_t* heap = NULL;
    ulint size = 0;
    page_cur_t cur;

    page_cur_set_before_first(block, &cur);
    page_cur_move_to_next(&cur);
    while (page_cur_get_rec(&cur) != page_get_supremum_rec(page)) {
        rec_t* cur_rec = page_cur_get_rec(&cur);
        offsets = rec_get_offsets(cur_rec, index, offsets,
                      ULINT_UNDEFINED, &heap);
        ulint rec_size = rec_offs_size(offsets);
        size += rec_size;
        if (size > size_limit) {
            size = size - rec_size;
            break;
        }
        n_recs ++;
        page_cur_move_to_next(&cur);
    }
    *n_recs_size = size;
    return n_recs;
}

/*************************************************************//**
Merge as many records from the from_block to the to_block. Delete
the from_block if all records are successfully merged to to_block.
@return the to_block to target for next merge operation. */
UNIV_INTERN
buf_block_t*
btr_defragment_merge_pages(
    dict_index_t*    index,        /*!< in: index tree */
    buf_block_t*    from_block,    /*!< in: origin of merge */
    buf_block_t*    to_block,    /*!< in: destination of merge */
    ulint        zip_size,    /*!< in: zip size of the block */
    ulint        reserved_space,    /*!< in: space reserved for future
                    insert to avoid immediate page split */
    ulint*        max_data_size,    /*!< in/out: max data size to
                    fit in a single compressed page. */
    mem_heap_t*    heap,        /*!< in/out: pointer to memory heap */
    mtr_t*        mtr)        /*!< in/out: mini-transaction */
{
    page_t* from_page = buf_block_get_frame(from_block);
    page_t* to_page = buf_block_get_frame(to_block);
    ulint space = dict_index_get_space(index);
    ulint level = btr_page_get_level(from_page, mtr);
    ulint n_recs = page_get_n_recs(from_page);
    ulint new_data_size = page_get_data_size(to_page);
    ulint max_ins_size =
        page_get_max_insert_size(to_page, n_recs);
    ulint max_ins_size_reorg =
        page_get_max_insert_size_after_reorganize(
            to_page, n_recs);
    ulint max_ins_size_to_use = max_ins_size_reorg > reserved_space
                    ? max_ins_size_reorg - reserved_space : 0;
    ulint move_size = 0;
    ulint n_recs_to_move = 0;
    rec_t* rec = NULL;
    ulint target_n_recs = 0;
    rec_t* orig_pred = NULL;

    // Estimate how many records can be moved from the from_page to
    // the to_page.
    if (zip_size) {
        ulint page_diff = UNIV_PAGE_SIZE - *max_data_size;
        max_ins_size_to_use = (max_ins_size_to_use > page_diff)
                   ? max_ins_size_to_use - page_diff : 0;
    }
    n_recs_to_move = btr_defragment_calc_n_recs_for_size(
        from_block, index, max_ins_size_to_use, &move_size);

    // If max_ins_size >= move_size, we can move the records without
    // reorganizing the page, otherwise we need to reorganize the page
    // first to release more space.
    if (move_size > max_ins_size) {
        sql_print_warning("defredgment: need reorganize page: move %lu; max_ins_size %lu", 
                   move_size, max_ins_size);
        if (!btr_page_reorganize_block(false, page_zip_level,
                           to_block, index,
                           mtr)) {
            if (!dict_index_is_clust(index)
                && page_is_leaf(to_page)) {
                ibuf_reset_free_bits(to_block);
            }
            sql_print_warning("defredgment: reorganize failed");
            // If reorganization fails, that means page is
            // not compressable. There's no point to try
            // merging into this page. Continue to the
            // next page.
            return from_block;
        }
        ut_ad(page_validate(to_page, index));
        max_ins_size = page_get_max_insert_size(to_page, n_recs);
        sql_print_warning("defredgment: new max_ins_size: %lu", max_ins_size);
        ut_a(max_ins_size >= move_size);
    }

    // Move records to pack to_page more full.
    orig_pred = NULL;
    target_n_recs = n_recs_to_move;

    while (n_recs_to_move > 0) {
        rec = page_rec_get_nth(from_page,
                    n_recs_to_move + 1);
        orig_pred = page_copy_rec_list_start(
            to_block, from_block, rec, index, mtr);
#ifdef BAIDU_RECLAIM_DEBUG
        sql_print_warning("defredgment: pointer of sup: %s(NULL means failed)",
                orig_pred);
#endif
        if (orig_pred)
            break;
        // If we reach here, that means compression failed after packing
        // n_recs_to_move number of records to to_page. We try to reduce
        // the targeted data size on the to_page by
        // BTR_DEFRAGMENT_PAGE_REDUCTION_STEP_SIZE and try again.
        os_atomic_increment_ulint(
            &btr_defragment_compression_failures, 1);
        max_ins_size_to_use =
            move_size > BTR_DEFRAGMENT_PAGE_REDUCTION_STEP_SIZE
            ? move_size - BTR_DEFRAGMENT_PAGE_REDUCTION_STEP_SIZE
            : 0;
        if (max_ins_size_to_use == 0) {
            n_recs_to_move = 0;
            move_size = 0;
            break;
        }
        n_recs_to_move = btr_defragment_calc_n_recs_for_size(
            from_block, index, max_ins_size_to_use, &move_size);
    }
    // If less than target_n_recs are moved, it means there are
    // compression failures during page_copy_rec_list_start. Adjust
    // the max_data_size estimation to reduce compression failures
    // in the following runs.
    if (target_n_recs > n_recs_to_move
        && *max_data_size > new_data_size + move_size) {
        *max_data_size = new_data_size + move_size;
    }
    // Set ibuf free bits if necessary.
    if (!dict_index_is_clust(index)
        && page_is_leaf(to_page)) {
        if (zip_size) {
            ibuf_reset_free_bits(to_block);
        } else {
            ibuf_update_free_bits_if_full(
                to_block,
                UNIV_PAGE_SIZE,
                ULINT_UNDEFINED);
        }
    }
    if (n_recs_to_move == n_recs) {
        /* The whole page is merged with the previous page,
        free it. */
        sql_print_warning("Yes, we have released one page");
        lock_update_merge_left(to_block, orig_pred,
                       from_block);
        btr_search_drop_page_hash_index(from_block);
        btr_level_list_remove(space, zip_size, from_page,
                      index, mtr);
        btr_node_ptr_delete(index, from_block, mtr);
        btr_blob_dbg_remove(from_page, index,
                    "btr_defragment_n_pages");
        btr_page_free(index, from_block, mtr);
    } else {
        // There are still records left on the page, so
        // increment n_defragmented. Node pointer will be changed
        // so remove the old node pointer.
        if (n_recs_to_move > 0) {
            // Part of the page is merged to left, remove
            // the merged records, update record locks and
            // node pointer.
            dtuple_t* node_ptr = NULL;
            page_delete_rec_list_start(rec, from_block,
                           index, mtr);
            lock_update_split_and_merge(to_block,
                            orig_pred,
                            from_block);
            btr_node_ptr_delete(index, from_block, mtr);
            rec = page_rec_get_next(
                page_get_infimum_rec(from_page));
            node_ptr = dict_index_build_node_ptr(
                index, rec, page_get_page_no(from_page),
                heap, level + 1);
            btr_insert_on_non_leaf_level(0, index, level+1,
                             node_ptr, mtr);
        }
        to_block = from_block;
    }
    return to_block;
}

/*************************************************************//**
Tries to merge N consecutive pages, starting from the page pointed by the
cursor. Skip space 0. Only consider leaf pages.
This function first loads all N pages into memory, then for each of
the pages other than the first page, it tries to move as many records
as possible to the left sibling to keep the left sibling full. During
the process, if any page becomes empty, that page will be removed from
the level list. Record locks, hash, and node pointers are updated after
page reorganization.
@return pointer to the last block processed, or NULL if reaching end of index */
UNIV_INTERN
buf_block_t*
btr_defragment_n_pages(
    buf_block_t*    block,    /*!< in: starting block for defragmentation */
    dict_index_t*    index,    /*!< in: index tree */
    uint        n_pages,/*!< in: number of pages to defragment */
    mtr_t*        mtr)    /*!< in/out: mini-transaction */
{
    ulint        space;
    ulint        zip_size;
    /* We will need to load the n+1 block because if the last page is freed
    and we need to modify the prev_page_no of that block. */
    buf_block_t*    blocks[BTR_DEFRAGMENT_MAX_N_PAGES + 1];
    page_t*         first_page = NULL;
    buf_block_t*    current_block = NULL;
    ulint       total_data_size = 0;
    ulint       total_n_recs = 0;
    ulint       data_size_per_rec;
    ulint       optimal_page_size;
    ulint       reserved_space;
    ulint       level;
    ulint       max_data_size = 0;
    uint        n_defragmented = 0;
    uint        n_new_slots;
    mem_heap_t* heap = NULL;
    bool       end_of_index = false;

    /* It doesn't make sense to call this function with n_pages = 1. */
    ut_ad(n_pages > 1);

    ut_ad(mtr_memo_contains(mtr, dict_index_get_lock(index),
                MTR_MEMO_X_LOCK));
    space = dict_index_get_space(index);
    if (space == 0) {
        /* Ignore space 0. */
        return NULL;
    }

    if (n_pages > BTR_DEFRAGMENT_MAX_N_PAGES) {
        n_pages = BTR_DEFRAGMENT_MAX_N_PAGES;
    }

    zip_size = dict_table_zip_size(index->table);
    first_page = buf_block_get_frame(block);
    level = btr_page_get_level(first_page, mtr);

    if (level != 0) {
        return NULL;
    }

    /* 1. Load the pages and calculate the total data size. */
    blocks[0] = block;
    for (uint i = 1; i <= n_pages; i++) {
        page_t* page = buf_block_get_frame(blocks[i-1]);
        ulint page_no = btr_page_get_next(page, mtr);
        total_data_size += page_get_data_size(page);
        total_n_recs += page_get_n_recs(page);
        if (page_no == FIL_NULL) {
            n_pages = i;
            end_of_index = true;
            break;
        }
        blocks[i] = btr_block_get(space, zip_size, page_no,
                      RW_X_LATCH, index, mtr);
    }

    if (n_pages == 1) {
        if (btr_page_get_prev(first_page, mtr) == FIL_NULL) {
            /* last page in the index */
            if (dict_index_get_page(index)
                == page_get_page_no(first_page))
                return NULL;
            /* given page is the last page.
            Lift the records to father. */
            btr_lift_page_up(index, block, mtr);
        }
        return NULL;
    }

    /* 2. Calculate how many pages data can fit in. If not compressable,
    return early. */
    ut_a(total_n_recs != 0);
    data_size_per_rec = total_data_size / total_n_recs;
    // For uncompressed pages, the optimal data size if the free space of a
    // empty page.
    optimal_page_size = page_get_free_space_of_empty(
        page_is_comp(first_page));
    // For compressed pages, we take compression failures into account.
    if (zip_size) {
        ulint size = 0;
        int i = 0;
        // We estimate the optimal data size of the index use samples of
        // data size. These samples are taken when pages failed to
        // compress due to insertion on the page. We use the average
        // of all samples we have as the estimation. Different pages of
        // the same index vary in compressibility. Average gives a good
        // enough estimation.
        for (;i < STAT_DEFRAG_DATA_SIZE_N_SAMPLE; i++) {
            if (index->stat_defrag_data_size_sample[i] == 0) {
                break;
            }
            size += index->stat_defrag_data_size_sample[i];
        }
        if (i != 0) {
            size = size / i;
            optimal_page_size = min(optimal_page_size, size);
        }
        max_data_size = optimal_page_size;
    }

    reserved_space = min((ulint)(optimal_page_size
                  * (1 - srv_defragment_fill_factor)),
                 (data_size_per_rec
                  * srv_defragment_fill_factor_n_recs));
    optimal_page_size -= reserved_space;
    n_new_slots = (total_data_size + optimal_page_size - 1)
              / optimal_page_size;
#ifdef BAIDU_RECLAIM_DEBUG
    sql_print_warning("Defragment before: %d, after: %d", n_pages, n_new_slots);
#endif
    if (n_new_slots >= n_pages) {
        /* Can't defragment. */
        if (end_of_index)
            return NULL;
        return blocks[n_pages-1];
    }

    /* 3. Defragment pages. */
    heap = mem_heap_create(256);
    // First defragmented page will be the first page.
    current_block = blocks[0];
    // Start from the second page.
    for (uint i = 1; i < n_pages; i ++) {
        buf_block_t* new_block = btr_defragment_merge_pages(
            index, blocks[i], current_block, zip_size,
            reserved_space, &max_data_size, heap, mtr);
        if (new_block != current_block) {
            n_defragmented ++;
            current_block = new_block;
        }
    }
    mem_heap_free(heap);
    n_defragmented ++;
    os_atomic_increment_ulint(
        &btr_defragment_count, 1);
    if (n_pages == n_defragmented) {
        os_atomic_increment_ulint(
            &btr_defragment_failures, 1);
    } else {
        index->stat_defrag_n_pages_freed += (n_pages - n_defragmented);
    }
    if (end_of_index)
        return NULL;
    return current_block;
}

/******************************************************************//**
Thread that merges consecutive b-tree pages into fewer pages to defragment
the index. */
extern "C" UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(btr_defragment_thread)(
/*==========================================*/
    void*    arg)    /*!< in: work queue */
{
    btr_pcur_t*    pcur;
    btr_cur_t*    cursor;
    dict_index_t*    index;
    mtr_t        mtr;
    buf_block_t*    first_block;
    buf_block_t*    last_block;

    while (srv_shutdown_state == SRV_SHUTDOWN_NONE) {
        /* If defragmentation is disabled, sleep before
        checking whether it's enabled. */
        if (!srv_defragment) {
            os_thread_sleep(BTR_DEFRAGMENT_SLEEP_IN_USECS);
            continue;
        }
        /* The following call won't remove the item from work queue.
        We only get a pointer to it to work on. This will make sure
        when user issue a kill command, all indices are in the work
        queue to be searched. This also means that the user thread
        cannot directly remove the item from queue (since we might be
        using it). So user thread only marks index as removed. */
        btr_defragment_item_t* item = btr_defragment_get_item();
        /* If work queue is empty, sleep and check later. */
        if (!item) {
            os_thread_sleep(BTR_DEFRAGMENT_SLEEP_IN_USECS);
            continue;
        }
        /* If an index is marked as removed, we remove it from the work
        queue. No other thread could be using this item at this point so
        it's safe to remove now. */
        if (item->removed) {
            btr_defragment_remove_item(item);
            continue;
        }

        pcur = item->pcur;
        ulonglong now = ut_timer_now();
        ulonglong elapsed = now - item->last_processed;

        if (elapsed < srv_defragment_interval) {
            /* If we see an index again before the interval
            determined by the configured frequency is reached,
            we just sleep until the interval pass. Since
            defragmentation of all indices queue up on a single
            thread, it's likely other indices that follow this one
            don't need to sleep again. */
            os_thread_sleep(((ulint)ut_timer_to_microseconds(
                        srv_defragment_interval - elapsed)));
        }

        now = ut_timer_now();
        mtr_start(&mtr);
        btr_pcur_restore_position(BTR_MODIFY_TREE, pcur, &mtr);
        cursor = btr_pcur_get_btr_cur(pcur);
        index = btr_cur_get_index(cursor);
        first_block = btr_cur_get_block(cursor);
        last_block = btr_defragment_n_pages(first_block, index,
                            srv_defragment_n_pages,
                            &mtr);
        if (last_block) {
            /* If we haven't reached the end of the index,
            place the cursor on the last record of last page,
            store the cursor position, and put back in queue. */
            page_t* last_page = buf_block_get_frame(last_block);
            rec_t* rec = page_rec_get_prev(
                page_get_supremum_rec(last_page));
            ut_a(page_rec_is_user_rec(rec));
            page_cur_position(rec, last_block,
                      btr_cur_get_page_cur(cursor));
            btr_pcur_store_position(pcur, &mtr);
            mtr_commit(&mtr);
            /* Update the last_processed time of this index. */
            item->last_processed = now;
        } else {
            mtr_commit(&mtr);
            /* Reaching the end of the index. */
            dict_stats_empty_defrag_stats(index);
            dict_stats_save_defrag_stats(index);    // 在这里死锁了
            dict_stats_save_defrag_summary(index);
            /* Enter reclaim mutex brfore remove defragment item,
            to avoid add defragment item repeatedly. */
            mutex_enter(&btr_reclaim_mutex);
            btr_defragment_remove_item(item);
            if (srv_reclaim) {
                // we add reclaim item when there is no defragment item in
                // btr_defragment_wq, which means that the table, these 
                // indexes belongs to, has been defragmented completely
                if (!btr_defragment_find_index_by_space(index->space)) {
                    sql_print_information("Reclaim: defragment table:[%s] is over, "
                                    "add reclaim item for it succeed.",
                            index->table_name);
                    btr_reclaim_item_t *r_item = new btr_reclaim_item_t(index);
                    btr_reclaim_add_item(r_item);
                }
            }
            mutex_exit(&btr_reclaim_mutex);
        }
    }
    btr_defragment_shutdown();
    os_thread_exit(NULL);
    OS_THREAD_DUMMY_RETURN;
}

/* Reclaim begin */
/******************************************************************//**
Calculate CPU idle. */
double cal_cpuidle(cpu_stat_t* one, cpu_stat_t* two) {
    double one_total = 0.0;
    double two_total = 0.0;
    double one_idle  = 0.0;
    double two_idle  = 0.0;
    double cpu_idle  = 0.0;

    one_total = (double) (one->user + one->nice + one->system + one->idle
                        + one->softirq + one->iowait + one->irq);
    two_total = (double) (two->user + two->nice + two->system + two->idle
                        + two->softirq + two->iowait + two->irq);

    one_idle = (double) (one->idle);
    two_idle = (double) (two->idle);

    if ((two_total - one_total) != 0) {
        cpu_idle = (two_idle - one_idle)/(two_total - one_total) * 100.00;
    } else {
        cpu_idle = 100.00;
    }
    return cpu_idle;
}

/******************************************************************//**
Get CPU occupy from /proc/stat. */
void get_cpu_stat(cpu_stat_t* cpu_stat) {
    FILE *fd = NULL;
    char buff[256];
    fd = fopen ("/proc/stat", "r");
    fgets(buff, sizeof(buff), fd);

    sscanf(buff, "%s %u %u %u %u %u %u %u",
            cpu_stat->name, &cpu_stat->user, &cpu_stat->nice,
            &cpu_stat->system, &cpu_stat->idle, &cpu_stat->iowait,
            &cpu_stat->irq, &cpu_stat->softirq);

    fclose(fd);
}

/******************************************************************//**
Constructor for btr_reclaim_item_t. */
btr_reclaim_item_t::btr_reclaim_item_t(
    dict_index_t *index) /*!< in: Last index of table in btr_defragment_wq */
{
    /* copy table name */
    const char *table_name = index->table_name;
    ut_ad(strlen(table_name) < FN_REFLEN);
    memcpy(this->table, table_name, strlen(table_name));
    this->table[strlen(table_name) + 1] = '\0';

    this->space = dict_index_get_space(index);
    this->removed = false;
    this->last_processed = 0;
    this->page_no = 0;
}

/******************************************************************//**
Destructor for btr_reclaim_item_t. */
btr_reclaim_item_t::~btr_reclaim_item_t() {
    // if (this->event) {
    //     os_event_set(this->event);
    // }
}

/******************************************************************//**
Find same reclaim item with table name. */
bool
btr_find_reclaim_item_with_name(
    const char* table_name) /*!< in: table name */
{
    list< btr_reclaim_item_t* >::iterator iter = btr_reclaim_wq.begin();
    for (; iter != btr_reclaim_wq.end(); iter++) {
        btr_reclaim_item_t* item = *iter;
        if (strcmp(table_name, item->table) == 0) {
            return true;
        }
    }
    return false;
}

/******************************************************************//**
Find same reclaim item with space id. */
bool
btr_find_reclaim_item_with_id(
    ulint space) /*!< in: space id */
{
    list< btr_reclaim_item_t* >::iterator iter = btr_reclaim_wq.begin();
    for (; iter != btr_reclaim_wq.end(); iter++) {
        btr_reclaim_item_t* item = *iter;
        if (space == item->space) {
            return true;
        }
    }
    return false;
}

/******************************************************************//**
Initialize online reclaim. */
void
btr_reclaim_init() {
    srv_reclaim_truncate_interval = ut_microseconds_to_timer(
        1000000.0 / srv_reclaim_frequency);
    mutex_create(btr_reclaim_mutex_key, &btr_reclaim_mutex,
             SYNC_ANY_LATCH);
    os_thread_create(btr_ibd_reclaim_thread, NULL, NULL);
}

/******************************************************************//**
Shutdown reclaim. Release all resources. */
void
btr_reclaim_shutdown()
{
    mutex_enter(&btr_reclaim_mutex);
    list< btr_reclaim_item_t* >::iterator iter = btr_reclaim_wq.begin();
    while (iter != btr_reclaim_wq.end()) {
        btr_reclaim_item_t* item = *iter;
        iter = btr_reclaim_wq.erase(iter);
        delete item;
    }
    mutex_exit(&btr_reclaim_mutex);
    mutex_free(&btr_reclaim_mutex);
}

/******************************************************************//**
Get header page of table by space id. */
fsp_header_t*
btr_get_fsp_header(ulint space, ulint zip_size, mtr_t *mtr) {
    buf_block_t* fst_block = buf_page_get(space, zip_size, 0, RW_SX_LATCH, mtr);
    buf_block_dbg_add_level(fst_block, SYNC_FSP_PAGE);
    fsp_header_t *header = buf_block_get_frame(fst_block) + FSP_HEADER_OFFSET;
    ut_ad(page_offset(header) == FSP_HEADER_OFFSET);
    return header;
}

/******************************************************************//**
Determine whether table need to be reclaimed.
Return true: need to be reclaimed.*/
bool
btr_table_need_to_be_reclaimed(
    const char*     table_name,
    dict_table_t*   table)
{
    ulint           space = 0;
    ulint           zip_size = 0;
    fsp_header_t*   header = NULL;
    ulint           table_size = 0;

    ulint           page_no = 0;
    buf_block_t*    block = NULL;
    page_t*         page = NULL;
    ulint           page_type = 0;
    xdes_t*         descr = NULL;
    ulint           free_page_num = 0;
    ulint           free_space  = 0;
    ulint           optimal_page_size = 0;
    double          total_free_size = 0.0;
    double          total_size = 0.0;

    mtr_t mtr;

    /* Determines whether need to reclaim by checking table size. */
    mtr_start(&mtr);
    space = table->space;
    zip_size = dict_table_zip_size(table);
    header = btr_get_fsp_header(space, zip_size, &mtr);
    table_size = mach_read_from_4(header + FSP_SIZE);
    page_no = table_size;

    ulint ibd_size = table_size / FSP_EXTENT_SIZE;
    if (ibd_size < srv_reclaim_size) {
        sql_print_information("Reclaim: table:[%s] ibd unzip size:[%lu]MiB "
                        "is too small to reclaim, reclaim size:[%u] MiB.",
                table_name, ibd_size, srv_reclaim_size);
        mtr_commit(&mtr);
        return false;
    }
    mtr_commit(&mtr);

    /* Determines whether need to reclaim by checking fragmentation rate. */
    while (page_no-- > 0) {
        mtr_start(&mtr);
        block = btr_block_get(space, zip_size, page_no,
                                RW_NO_LATCH, NULL, &mtr);
        if (block != NULL) {
            page = buf_block_get_frame(block);
            page_type = mach_read_from_2(page + FIL_PAGE_TYPE);
            if (page_type == FIL_PAGE_TYPE_ALLOCATED) {
                free_page_num++;
            } else if (page_type == FIL_PAGE_INDEX) {
                descr = xdes_get_descriptor(space, zip_size, page_no, &mtr);
                if (descr == NULL) {
                    free_page_num++;
                } else if (xdes_get_bit(descr, XDES_FREE_BIT, page_no % FSP_EXTENT_SIZE)) {
                    free_page_num++;
                } else {
                    free_space += page_header_get_field(page, PAGE_GARBAGE);
                }
            } else {
                /* Other type pages are management pages, no need to count them. */
            }
            if (optimal_page_size == 0) {
                optimal_page_size = page_get_free_space_of_empty(page_is_comp(page));
            }
        } else {
            free_page_num++;
        }
        /* Check fragmentation size. */
        if (srv_reclaim_frag_size > 0){
            total_free_size = double(free_page_num * optimal_page_size + free_space);
            if (total_free_size > srv_reclaim_frag_size * 1024 * 1024) {
                sql_print_information("Reclaim: current table[%s] total_free_size:[%lf], "
                                "srv_reclaim_frag_size:[%u]MiB [%u]Byte, start reclaiming.",
                        table_name, total_free_size, srv_reclaim_frag_size,
                        srv_reclaim_frag_size * 1024 * 1024);
                mtr_commit(&mtr);
                return true;
            }
        }
        mtr_commit(&mtr);
    }
    total_free_size = double(free_page_num * optimal_page_size + free_space);
    total_size = double(table_size * optimal_page_size);
    if (total_free_size / total_size * 100 < double(srv_reclaim_frag_rate)) {
        sql_print_information("Reclaim: table:[%s] fragmentation rate:[%.2lf] is too "
                        "small to reclaim, reclaim fragmentation rate:[%u].",
                table_name, total_free_size / total_size * 100, srv_reclaim_frag_rate);
        return false;
    }

    sql_print_information("Reclaim: table:[%s] fragmentation rate:[%.2lf] is enough "
                    "to be reclaim rate:[%u].",
            table_name, total_free_size / total_size * 100, srv_reclaim_frag_rate);
    return true;
}

/******************************************************************//**
Open table indexes and add index pointer into map.
Return table cluster index pointer.*/
bool
btr_gen_defragment_item_for_table(
    const char* table_name) /*!< in: table norm name */
{
    dict_table_t *table = NULL;
    dberr_t err = DB_SUCCESS;
    /* Open table */
    table = dict_table_open_on_name(table_name, FALSE,
            FALSE, DICT_ERR_IGNORE_NONE);
    ut_ad(table != NULL);

    dict_index_t *index = dict_table_get_first_index(table);

    /* Find same defragmentation item from list with space. */
    if (btr_defragment_find_index_by_space(index->space)) {
#ifdef BAIDU_RECLAIM_DEBUG
        sql_print_information("Reclaim:[DEBUG] defragmentation item of table:[%s] already "
                        "exists in the list, no need to add it repeatedly.",
                table_name);
#endif
        dict_table_close(table, FALSE, FALSE);
        return false;
    }

    /* Check table size and fragmentation rate of table. */
    if (srv_reclaim_check_frag && 
            !btr_table_need_to_be_reclaimed(table_name, table)) {
        dict_table_close(table, FALSE, FALSE);
        return false;
    }

    /* Traverse all indexes of table to construct defragmentation item. */
    for (; index; index = dict_table_get_next_index(index)) {

        btr_defragment_add_index(index, true, &err);

        if (err != DB_SUCCESS) {
            sql_print_information("Reclaim: add defragmentation item for table:[%s], index:[%lu] "
                            "failed, error number:[%d], continue to add next index of table.",
                    table_name, index->id, err);
        }
    }

    dict_table_close(table, FALSE, FALSE);
    return true;
}

/******************************************************************//**
Generate reclaim item for each table of db. */
void
btr_gen_defragment_item_for_db(
    const char* name) /*!< in: database name */
{
    dict_table_t*   sys_tables = NULL;
    btr_pcur_t      pcur;
    dict_index_t*   sys_index = NULL;
    dtuple_t*       tuple = NULL;
    mem_heap_t*     heap = NULL;
    dfield_t*       dfield = NULL;
    const rec_t*    rec = NULL;
    const byte*     field = NULL;
    ulint           len = 0;
    mtr_t           mtr;

    heap = mem_heap_create(1000);
    mtr_start(&mtr);
 
    /* Open SYS_TABLES to look up all tables for db. */
    sys_tables = dict_table_get_low("SYS_TABLES");
    sys_index = UT_LIST_GET_FIRST(sys_tables->indexes);

    tuple = dtuple_create(heap, 1);
    dfield = dtuple_get_nth_field(tuple, 0);

    dfield_set_data(dfield, name, ut_strlen(name));
    dict_index_copy_types(tuple, sys_index, 1);

    btr_pcur_open_on_user_rec(sys_index, tuple, PAGE_CUR_GE,
                  BTR_SEARCH_LEAF, &pcur, &mtr);

    /* Traverse all record to get all tables' name. */
    rec = btr_pcur_get_rec(&pcur);
    while (btr_pcur_is_on_user_rec(&pcur)) {

        field = rec_get_nth_field_old(
                rec, DICT_FLD__SYS_TABLES__NAME, &len);

        if (len < strlen(name) || ut_memcmp(name, field, strlen(name)) != 0) {
            break;
        }

        if (!rec_get_deleted_flag(rec, 0)) {
            char*    table_name = mem_strdupl((char*) field, len);

            /* Check whether the same reclaim item in the list already. */
            mutex_enter(&btr_reclaim_mutex);
            if (btr_find_reclaim_item_with_name(table_name)) {
#ifdef BAIDU_RECLAIM_DEBUG
                sql_print_information("Reclaim:[DEBUG] there is the same reclaim item "
                                "for table:[%s], dont reclaim it repeatedly.",
                        table_name);
#endif
            } else {
                /* Use table name to construct defragment task. When defragment task
                over, defragment thread will construct reclaim task automatically. */
                if (btr_gen_defragment_item_for_table(table_name)) {
                    sql_print_information("Reclaim: generate defragment item for "
                                    "table:[%s] succeed, defragment item list size:[%u].",
                            table_name, uint(btr_defragment_wq.size()));
                }
            }
            mutex_exit(&btr_reclaim_mutex);
            mem_free(table_name); // must free mem_strdupl result
        }

        btr_pcur_move_to_next_user_rec(&pcur, &mtr);
        rec = btr_pcur_get_rec(&pcur);
    }
    btr_pcur_close(&pcur);
    mtr_commit(&mtr);
    mem_heap_free(heap);
}

/******************************************************************//**
Initialize the defragmention task based on srv_reclaim_db. */
void
btr_reclaim_add_defragment_item(
    bool* check_interval,
    ulonglong* last_reclaim_time) /*!< in: last reclaim time*/
{
    char    db_name[FN_REFLEN];
    uint    i = 0;
    char*   pos = NULL;

#ifndef BAIDU_RECLAIM_DEBUG
    /* Control interval between two reclaimations. */
    ulonglong now = ut_timer_now();
    ulonglong elapsed = now - *last_reclaim_time;
    ulonglong interval = ut_microseconds_to_timer(
                            srv_reclaim_day_interval
                            * 24 * 60 * 60 * 1000000.0);

    if (*check_interval && elapsed < interval) {
        sql_print_information("Reclaim: twice reclaim interval:[%llu], "
                        "current elapsed:[%llu], do not create new reclaim item.",
                interval, elapsed);
        return;
    } else {
        *check_interval = true;
    }
#else
    *check_interval = true;
#endif

    /* Construct defragment itme with database. */
    if (srv_reclaim_db != NULL && strlen(srv_reclaim_db) > 0) {
        pos = srv_reclaim_db;
        while (*pos != '\0') {
            if (*pos == ';') {
                db_name[i] = '\0';
                btr_gen_defragment_item_for_db(db_name);
                i = 0;
                pos++;
                continue;
            }
            db_name[i++] = *pos++;
        }
        if (i != 0) {
            db_name[i] = '\0';
            btr_gen_defragment_item_for_db(db_name);
        }
    }

    *last_reclaim_time = ut_timer_now();
}

/******************************************************************//**
Push reclaim item into queue. */
void
btr_reclaim_add_item(
    btr_reclaim_item_t *item) /*!< in: Item to be added. */
{
    for (list<btr_reclaim_item_t *>::iterator iter = btr_reclaim_wq.begin();
            iter != btr_reclaim_wq.end();
            iter++) {
        if (item->space == (*iter)->space) {
            return;
        }
    }
    item->create_time = ut_timer_now();
    btr_reclaim_wq.push_back(item);
}

/******************************************************************//**
Functions used by online reclaim thread: btr_reclaim_xxx_item.
Online reclaim thread operates on the work *item*. It gets/removes
item from the work queue. */
/******************************************************************//**
Reclaim thread uses this to remove an item from btr_reclaim_wq.
When an item is removed from the work queue, all resources associated with it
are free as well. */
void
btr_reclaim_remove_item(
    btr_reclaim_item_t* item) /*!< in: Item to be removed. */
{
    for (list< btr_reclaim_item_t* >::iterator iter = btr_reclaim_wq.begin();
         iter != btr_reclaim_wq.end();
         ++iter) {
        if (item == *iter) {
            btr_reclaim_wq.erase(iter);
            delete item;
            break;
        }
    }
}
/******************************************************************//**
Online reclaim thread uses this to get an item from btr_reclaim_wq to work on.
The item is not removed from the work queue so query threads can still access
this item. We keep it this way so query threads can find and kill a
reclaim even if that index is being worked on. Be aware that while you
work on this item you have no lock protection on it whatsoever. This is OK as
long as the query threads and reclaim thread won't modify the same fields
without lock protection.
*/
btr_reclaim_item_t*
btr_reclaim_get_item() {
    if (btr_reclaim_wq.empty()) {
        return NULL;
    }

    ulonglong reclaim_interval = ut_microseconds_to_timer(
                        srv_reclaim_day_interval
                        * 24 * 60 * 60 * 1000000.0);

    mutex_enter(&btr_reclaim_mutex);

    ulonglong now = ut_timer_now();
    ulonglong elapsed = 0;

    btr_reclaim_item_t* item = NULL;
    list< btr_reclaim_item_t* >::iterator iter = btr_reclaim_wq.begin();

    for (; iter != btr_reclaim_wq.end();) {
        item = *iter;
        if (item->removed) {
            elapsed = now - item->create_time;
            if (elapsed > reclaim_interval) {
                iter = btr_reclaim_wq.erase(iter);
                delete item;
                continue;
            } else {
                /* If elapsed is less than reclaim_interval,
                we do not remove this tiem from queue, because
                we use this item to forbid same item be*/
                iter++;
                continue;
            }
        } else {
            /* We should process current item. */
            elapsed = now - item->last_processed;
            if (elapsed < srv_reclaim_truncate_interval) {
                /* If we see an reclaim item again before the interval
                determined by the configured frequency is reached,
                we just sleep until the interval pass. */
                os_thread_sleep(((ulint)ut_timer_to_microseconds(
                        srv_reclaim_truncate_interval - elapsed)));
            }
            mutex_exit(&btr_reclaim_mutex);
            return item;
        }
    }
    mutex_exit(&btr_reclaim_mutex);
    return NULL;
}
/******************************************************************//**
When table is dropped, this function is called to mark a table as removed in
btr_reclaim_wq. The difference between this function and the remove_index
function is this will not NULL the event. */
void
btr_reclaim_remove_table(
    dict_table_t*    table) /*!< in: Table to be removed. */
{
    mutex_enter(&btr_reclaim_mutex);
    for (list< btr_reclaim_item_t* >::iterator iter = btr_reclaim_wq.begin();
            iter != btr_reclaim_wq.end();
            ++iter) {
        btr_reclaim_item_t* r_item = *iter;
        if (r_item->space == table->space) {
            r_item->removed = true;
            break;
        }
    }
    mutex_exit(&btr_reclaim_mutex);
}
/******************************************************************//**
Query thread uses this function to mark an index as removed, then we 
remove table item, that index belongs to, from btr_reclaim_wq. */
void
btr_reclaim_remove_index(
    dict_index_t*    index)    /*!< in: Index to be removed. */
{
    mutex_enter(&btr_reclaim_mutex);
    for (list< btr_reclaim_item_t* >::iterator iter = btr_reclaim_wq.begin();
            iter != btr_reclaim_wq.end();
            ++iter) {
        btr_reclaim_item_t *r_item = *iter;
        btr_index_map::iterator idx_iter = r_item->index_map.find(index->id);
        // TODO: we whether need to remove item directly
        if (idx_iter != r_item->index_map.end()) {
            r_item->removed = true;
            break;
        }
    }
    mutex_exit(&btr_reclaim_mutex);
}
/******************************************************************//**
Return page_no, that should be processed. */
ulint
btr_get_reclaim_page_no(btr_reclaim_item_t *item, fsp_header_t *header) {
    // if (item->page_no > 0) {
    //     return item->page_no;
    // }

    // item->page_no = mach_read_from_4(header + FSP_FREE_LIMIT) - 1;
    item->page_no = mach_read_from_4(header + FSP_SIZE) - 1;
    return item->page_no;
}

/******************************************************************//**
Open table indexes and add index pointer into map.
Return table cluster index pointer.*/
dict_index_t *
btr_open_table_index(
    btr_index_map &index_map,   /*!< in/out: Index map of table. */
    const char *table_name)     /*!< in: Table norm name. */
{
    dict_index_t *clust_index = NULL;
    dict_table_t *table = NULL;
    /* Open table */
    table = dict_table_open_on_name(table_name, FALSE,
            FALSE, DICT_ERR_IGNORE_NONE);
    ut_ad(table != NULL);
    for (dict_index_t *idx = dict_table_get_first_index(table); idx;
            idx = dict_table_get_next_index(idx)) {
        index_map[idx->id] = idx;
        if (dict_index_is_clust(idx)) {
            clust_index = idx;
        }
    }
    dict_table_close(table, FALSE, FALSE);
    ut_ad(clust_index != NULL);
    return clust_index;
}

/******************************************************************//**
Lock all index of r_item.
Return number of pages loaded actually.*/
void btr_get_all_index_sx_latch(
    btr_reclaim_item_t* r_item, /*!< in: reclaim item. */
    mtr_t* mtr)             /*!< in: Mini transaction. */
{
    btr_index_map::iterator iter = r_item->index_map.begin();
    while (iter != r_item->index_map.end()) {
        dict_index_t* index = iter->second;
        if (index != NULL) {
            btr_root_get(index, mtr); // we get all index root page RW_SX_LATCH
#ifdef BAIDU_RECLAIM_DEBUG
            sql_print_information("Reclaim:[DEBUG] get space:[%lu] table:[%s] "
                    "index:[%lu] sx latch.",
                    r_item->space, r_item->table, iter->first);
#endif
        }
        iter++;
    }
}

/******************************************************************//**
Load n page info blocks.
Return number of pages loaded actually.*/
uint btr_load_n_pages(
    ulint space,            /*!< in: Space id of ibd. */
    ulint zip_size,         /*!< in: Zip size of ibd. */
    buf_block_t** blocks,   /*!< in/out: Blocks are loaded. */
    uint load_n_pages,      /*!< in: Load n pages. */
    ulint* cur_page_no,     /*!< in/out: Load blocks from current page no. */
    mtr_t* mtr)             /*!< in: Mini transaction. */
{
    uint n_pages = 0;
    buf_block_t *blk = NULL;
    for (uint i = 0; i < load_n_pages; i++) {
        while (*cur_page_no > 0) {
            blk = btr_block_get(space, zip_size, *cur_page_no,
                                RW_X_LATCH, NULL, mtr);
            if (blk == NULL) {                
                --*cur_page_no;
                continue;
            }
            blocks[i] = blk;
            n_pages++;
            --*cur_page_no;
            break;
        }
        /* First three pages of ibd are file managenment page, dont reclaim. */
        if (*cur_page_no <= 3) {
            break;
        }
    }
    return n_pages;
}

/******************************************************************//**
Get segment header by index root page.
Return fseg_header_t*.*/
fseg_header_t*
btr_get_fseg_header(
    dict_index_t*   index,  /*!< in: index */
    ulint           level,  /*!< in: reclaim page level */
    mtr_t*          mtr)    /*!< in: mtr */
{
    ut_ad(index != NULL);

    page_t *root = NULL;
    fseg_header_t* header = NULL;

    root = btr_root_get(index, mtr);
    if (level == 0) {
        header = root + PAGE_HEADER + PAGE_BTR_SEG_LEAF;
    } else {
        header = root + PAGE_HEADER + PAGE_BTR_SEG_TOP;
    }
    return header;
}

/******************************************************************//**
Get first free page number of index in space.
This function is used to find suitable hint page number for btr_page_alloc.
So we dont need x-latch of space. X-latch is used really in btr_page_alloc.
Return page no.*/
ulint
btr_get_first_free_page_no(
    ulint           space,      /*!< in: space id */
    dict_index_t*   index,      /*!< in: index */
    ulint           zip_size,   /*!< in: space zip size */
    ulint           level)      /*!< in: reclaim page level */
    // mtr_t           *mtr)       /*!< in: mtr */
{
    mtr_t   mtr;
    ulint   flags;
    ulint   page_no = 0;
    fseg_header_t* seg_header = NULL;

    mtr_start(&mtr);
    mtr_x_lock(fil_space_get_latch(space, &flags), &mtr);

    seg_header = btr_get_fseg_header(index, level, &mtr);

    page_no = fseg_smallest_free_page_no(seg_header, space, zip_size, &mtr);

    mtr_commit(&mtr);

    return page_no;
}

/******************************************************************//**
Determine whether free pages of index can be used to reclaim.
Return page no.*/
bool
btr_index_can_be_reclaimed(
    btr_reclaim_item_t* r_item, /*!< in: reclaim item */
    ulint           space,      /*!< in: table space */
    ulint           zip_size,   /*!< in: tablespace zip size */
    buf_block_t**   blocks,     /*!< in: block */
    uint            n_pages,    /*!< in: blocks size */
    mtr_t*          mtr)        /*!< in: mtr */
{
    ut_ad(blocks);

    buf_block_t* block = NULL;
    page_t* page = NULL;
    ulint page_type = 0;
    ulint page_no = 0;
    ulint page_level = 0;

    ulint index_id = 0;
    dict_index_t*   index = NULL;
    fseg_header_t*  seg_header = NULL;
    std::set<ulint> index_reclaim;
    std::set<ulint>::iterator iter = index_reclaim.end();
    uint i = 0;
    for (; i < n_pages; i++) {
        block = blocks[i];
        page = buf_block_get_frame(block);
        page_type = mach_read_from_2(page + FIL_PAGE_TYPE);
        page_no = buf_block_get_page_no(block);

        /* Allocated page can be reclaim directly. */
        if (page_type == FIL_PAGE_TYPE_ALLOCATED ||
                page_type == FIL_PAGE_IBUF_BITMAP ||
                page_type == FIL_PAGE_TYPE_XDES) {
#ifdef BAIDU_RECLAIM_DEBUG
            sql_print_information("Reclaim:[DEBUG] current page:[%lu] type is[%s], "
                            "we need to reclaim it.",
                    page_no,
                    page_type == FIL_PAGE_TYPE_ALLOCATED ? 
                        "FIL_PAGE_TYPE_ALLOCATED" :
                        page_type == FIL_PAGE_IBUF_BITMAP ?
                            "FIL_PAGE_IBUF_BITMAP" :
                            "FIL_PAGE_TYPE_XDES");
#endif
            continue;
        }
        
        /* The index, current page belongs to, has been checked. */
        index_id = btr_page_get_index_id(page);
        iter = index_reclaim.find(index_id);
        if (iter != index_reclaim.end()) {
            continue;
        }

        /* Determines whether segment of index has enough free space. */
        page_level = btr_page_get_level(page, mtr);
        btr_index_map::iterator iter = r_item->index_map.find(index_id);
        index = iter == r_item->index_map.end() ? NULL : iter->second;

        if (index != NULL) {
            seg_header = btr_get_fseg_header(index, page_level, mtr);
        }

        if (!fseg_has_enough_free_space(seg_header, space, zip_size, page_no, mtr)) {
            sql_print_information("Reclaim: space:[%lu], index:[%lu][%s], [%s]segment has no "
                            "enough free space to move. Try to alloc extent from ibd failed.",
                    space, index->id, index->name, page_level ? "no-leaf" : "leaf");
            return false;   
        }
        /* Insert index id, has been checked, into a set to accelerate check. */
        index_reclaim.insert(index_id);
    }
    return true;
}

/******************************************************************//**
Reclaim n pages space from ibd.
Return last process page no.*/
ulint
btr_reclaim_n_pages(
    btr_reclaim_item_t* r_item, /*!< in: reclaim item */
    ulint space,                /*!< in: space id of ibd */
    ulint zip_size,             /*!< in: zip size of ibd */
    buf_block_t** blocks,       /*!< in/out: blocks are loaded */
    uint n_pages,               /*!< in: process pages number */
    mtr_t* mtr)                 /*!< in: mtr_t */
{
    dict_index_t*   index = NULL;
    ulint index_id = 0;

    buf_block_t* block = NULL;  // from_block
    page_t      *page = NULL;   // from_page

    ulint page_no = 0;
    ulint page_type = 0;
    ulint page_level = 0;

    buf_block_t *new_block = NULL;  // from_block
    page_t      *new_page = NULL;   // from_page
    page_zip_des_t *new_page_zip = NULL;
    ulint new_page_no = 0;

    xdes_t  *descr = NULL;  // judge page/extent status

    ulint   last_page_no = 0;
    ulint   hint_page_no = 0;

    bool    get_fst_free = true;

    /* Process blocks */
    uint i = 0;
    for (; i < n_pages; i++) {
        block = blocks[i];
        page = buf_block_get_frame(block);
        page_no = buf_block_get_page_no(block);
        page_level = btr_page_get_level(page, mtr);
        // page_zip = buf_block_get_page_zip(block);
        index_id = btr_page_get_index_id(page);

        btr_index_map::iterator iter = r_item->index_map.find(index_id);
        index = iter == r_item->index_map.end() ? NULL : iter->second;

        /* Get descriptor to judge page wheather is freed */
        descr = xdes_get_descriptor(space, zip_size, page_no, mtr);

        /* Move all records to new page */
        page_type = fil_page_get_type(page);
        if (descr == NULL) {
#ifdef BAIDU_RECLAIM_DEBUG
            sql_print_information("Reclaim:[DEBUG] page_no:[%lu], page_type:[%lu] "
                    "descr is NULL, dont need to move this page.",
                    page_no, page_type);
#endif
        } else if (page_type == FIL_PAGE_INDEX) {
            if (xdes_get_bit(descr, XDES_FREE_BIT, page_no % FSP_EXTENT_SIZE)) {
#ifdef BAIDU_RECLAIM_DEBUG
                sql_print_information("Reclaim:[DEBUG] page_no:[%lu], page_type:[%lu] is freed.",
                        page_no, page_type);
#endif
            } else {
                /* 1 Allocate and create new page */
                int times = 0;
                while (times < 3) { // loop 3 times
                    /* Try to get the fisrt free page of a free extent. The hint_page_no
                    is the first free page_no. Then we can make hint_page_no++ to use other
                    free pages of this free extent. */
                    if (get_fst_free) {
                        hint_page_no =  btr_get_first_free_page_no(space, index, zip_size,
                                                                    page_level);
                    }

                    new_block = btr_page_alloc(index, hint_page_no++, FSP_UP, page_level, mtr, mtr);
                    new_page = buf_block_get_frame(new_block);
                    ut_ad(index_id == btr_page_get_index_id(new_page));

                    new_page_no = page_get_page_no(new_page);
                    if (new_page_no > page_no) {
                        sql_print_information("Reclaim: new_page_no:[%lu] > page_no:[%lu], "
                            "current page index id:[%lu], page type:[%lu], page level:[%lu].",
                            new_page_no, page_no, index_id, page_type, page_level);
                        /* We use btr_page_create to init page level of the new block, and then we
                        can free it using btr_page_free, otherwise, we will get a coredump.
                        Because the btr_page_free will check segment id of the new block by page
                        level, so we must initialize the page level of the new block. */
                        new_page_zip = buf_block_get_page_zip(new_block);
                        btr_page_create(new_block, new_page_zip, index, page_level, mtr);
                        btr_page_free(index, new_block, mtr);
                        times++;
                        get_fst_free = true;
                    } else {
                        /* Gets first free page succeed, so we do not
                        need to get the first free page again. */
                        get_fst_free = false;
                        break;
                    }
                }

                if (new_page_no > page_no) {
                    sql_print_information("Reclaim: new_page_no:[%lu] > page_no:[%lu], "
                            "we need to stop reclaiming, and free new_page.",
                            new_page_no, page_no);
                    r_item->removed = true;
                    break;
                }

                new_page_zip = buf_block_get_page_zip(new_block);
                btr_page_create(new_block, new_page_zip, index, page_level, mtr);

                ulint prev_page_no = btr_page_get_prev(page, mtr);

                if (prev_page_no != FIL_NULL) {
                    page_t* prev_page = buf_block_get_frame(btr_block_get(space, zip_size,
                                                prev_page_no, RW_X_LATCH, block->index, mtr));
#ifdef BAIDU_RECLAIM_DEBUG
                    sql_print_information("Reclaim:[DEBUG] cur page:[%lu], prev_page_no:[%lu], "
                            "prev_page_next:[%lu] [%s] page_no:[%lu]",
                            page_no, prev_page_no,
                            btr_page_get_next(prev_page, mtr),
                            btr_page_get_next(prev_page, mtr) == page_no ? "=" : "!=",
                            page_no);
#endif
                }

                /* 2 Add new page into index, that is previous node of page */
                btr_attach_half_pages(
                        BTR_NO_LOCKING_FLAG | BTR_KEEP_SYS_FLAG | BTR_NO_UNDO_LOG_FLAG,
                        index, block, page_rec_get_next(page_get_infimum_rec(page)),
                        new_block, FSP_DOWN, mtr);

                /* 3 Copy all record from page to new page */
                if (!page_copy_rec_list_end(new_block, block,
                                            page_rec_get_next(page_get_infimum_rec(page)),
                                            index, mtr)) {
                    sql_print_error("Reclaim: page copy rec failed, stop reclaiming, "
                            "current page_no:[%lu].", page_no);
                    break;
                }

                btr_search_move_or_delete_hash_entries(new_block, block, index);

                // Set ibuf free bits if necessary.
                if (!dict_index_is_clust(index)
                    && page_is_leaf(new_page)) {
                    if (zip_size) {
                        ibuf_reset_free_bits(new_block);
                    } else {
                        ibuf_update_free_bits_if_full(
                            new_block,
                            UNIV_PAGE_SIZE,
                            ULINT_UNDEFINED);
                    }
                }

                /* 4 Free current page */
                lock_update_merge_left(new_block, page_get_infimum_rec(new_page), block);
                btr_search_drop_page_hash_index(block);
                btr_level_list_remove(space, zip_size, page, index, mtr);
                btr_node_ptr_delete(index, block, mtr);
                btr_blob_dbg_remove(page, index, "reclaim_table_space");
                btr_page_free(index, block, mtr);
                block = NULL;

                /* should be free */
                ut_ad(xdes_get_bit(descr, XDES_FREE_BIT, page_no % FSP_EXTENT_SIZE));
            }
        } else if (page_type == FIL_PAGE_TYPE_ALLOCATED) {
            if (!xdes_get_bit(descr, XDES_FREE_BIT, page_no % FSP_EXTENT_SIZE)) {
#ifdef BAIDU_RECLAIM_DEBUG
                ulint state = mtr_read_ulint(descr + XDES_STATE, MLOG_4BYTES, mtr);
                sql_print_information("Reclaim:[DEBUG] page:[%lu] is allocated page, "
                        "but it is not freed, XDES_STATE is:[%lu].", page_no, state);
#endif
            }
#ifdef BAIDU_RECLAIM_DEBUG
            sql_print_information("Reclaim:[DEBUG] page:[%lu] is allocated page.", page_no);
#endif
        } else {
#ifdef BAIDU_RECLAIM_DEBUG
            sql_print_information("Reclaim:[DEBUG] page:[%lu] page_type:[%lu] need to processe.",
                    page_no, page_type);
#endif
        }
        last_page_no = page_no;

#ifdef BAIDU_RECLAIM_DEBUG
        if (descr != NULL) {
            sql_print_information("Reclaim:[DEBUG] descr first page:[%lu], xdes [%s] freed, "
                    "descr segment id:[%lu].",
                xdes_get_extent_first_page(descr),
                xdes_is_free(descr, mtr) ? "is" : "is not",
                mach_read_from_8(descr + XDES_ID));
        } else {
            sql_print_information("Reclaim:[DEBUG] descr is NULL, we can not get info about it.");
        }
#endif

        if (descr != NULL && page_no == xdes_get_extent_first_page(descr)) {
            if (xdes_is_free(descr, mtr) ||
                (page_type == FIL_PAGE_TYPE_XDES &&
                    xdes_manage_is_freed(blocks, n_pages, descr))) {
#ifdef BAIDU_RECLAIM_DEBUG
                sql_print_information("Reclaim:[DEBUG] xdes is freed, extent no:[%lu], "
                        "page_no:[%lu], current page type:[%lu], we can try to truncate ibd.",
                        page_no / FSP_EXTENT_SIZE, page_no, page_type);
#endif
                break;
            }
        }
    } // end for n_pages
#ifdef BAIDU_RECLAIM_DEBUG
    sql_print_information("Reclaim:[DEBUG] btr_reclaim_n_pages over: last_page_no:[%lu], "
                    "move page number:[%u]",
            last_page_no, i == n_pages ? i : i + 1);
#endif
    return last_page_no;
}

/******************************************************************//**
Check all pages whether are freed from the last page to first page.
Return true: all pages are freed */
bool
btr_check_freed(
    ulint space,
    ulint zip_size,
    ulint last,
    ulint first,
    buf_block_t **blocks,
    ulint *block_num,
    mtr_t* mtr)
{
    ulint           page_no = last;
    buf_block_t*    block = NULL;
    page_t*         page = NULL;
    ulint           page_type = 0;
    xdes_t*         descr = NULL;
    ulint           free_page_num = 0;
    *block_num = 0;

    while (page_no >= first) {
        block = btr_block_get(space, zip_size, page_no,
                                RW_X_LATCH, NULL, mtr);
        if (block != NULL) {
            blocks[(*block_num)++] = block;
            ut_a(*block_num <= FSP_EXTENT_SIZE * srv_reclaim_n_extent);
            page = buf_block_get_frame(block);
            page_type = mach_read_from_2(page + FIL_PAGE_TYPE);
            if (page_type == FIL_PAGE_TYPE_ALLOCATED
                    || page_type == FIL_PAGE_TYPE_XDES
                    || page_type == FIL_PAGE_IBUF_BITMAP) {
                free_page_num++;
            } else if (page_type == FIL_PAGE_INDEX) {
                descr = xdes_get_descriptor(space, zip_size, page_no, mtr);
                if (descr == NULL) {
                    free_page_num++;
                } else if (xdes_get_bit(descr, XDES_FREE_BIT, page_no % FSP_EXTENT_SIZE)) {
                    free_page_num++;
                }
            }
        } else {
            free_page_num++;
        }
        page_no--;
    }
    if (free_page_num == (last - first + 1)) {
        return true;
    }
    return false;
}

/******************************************************************//**
Try to truncate ibd file. Free blocks lock and fetch x-lock of space.
Return last_page_no: truncate failed, use last_page_no to reclaim again
Retrun cur_page_no: truncate succeed
    [Reclaim] IBD 有三个类型的管理 page
    FIL_PAGE_TYPE_FSP_HDR: 第一个 page, 头页, 并管理 256 个 Extent
    FIL_PAGE_IBUF_BITMAP: 第二个 page, change buffer, 管理 256个 Extent
    FIL_PAGE_INODE: segment 管理 page, ibd 文件中只有 1个
    FIL_PAGE_TYPE_XDES: Extent 管理节点, 除了 Header 与 FIL_PAGE_TYPE_FSP_HDR 不同, 其余均相同, 管理 256M 的 Extent
    在计算时需要考虑到以上几种类型的 page*/
    /* page_no:   0    |      1      |   2   |  3 ~ 16383 | 16384 |    16385    | 16386 ~ 32767 | ...
    page_type: FSP_HDR | IBUF_BITMAP | INODE |    INDEX   |  XDES | IBUF_BITMAP |     INDEX     | ...
    IBD 文件是 extent 的整数倍, 管理节点属于第一个 256 个 extent 的第一个 extent
*/
ulint
btr_try_to_truncate_ibd(
    btr_reclaim_item_t* r_item,
    ulint space,
    ulint page_no, /*!<in: fisrt page_no of extents will be truncated */
    ulint zip_size,
    buf_block_t** blocks)
{
    ulint   flags;
    xdes_t*         descr = NULL;
    fsp_header_t*   header = NULL;
    fseg_header_t*  seg_header = NULL;
    ulint free_limit;
    ulint total_page;
    ulint trunc_size;

    buf_block_t*    block = NULL;
    page_t*         page = NULL;
    ulint           page_type;
    ulint           index_id = 0;
    ulint           page_level;
    btr_index_map::iterator iter;
    dict_index_t*   index = NULL;
    ulint           page_size = zip_size ? zip_size : UNIV_PAGE_SIZE;
    ulint           block_num;
    mtr_t mtr_w; /* The mtr_w will be committed after truncation, so it only hold header lock. */
    mtr_t mtr_r; /* The mtr_r will be committed before truncation, so it can hold pages lock. */

    mtr_start(&mtr_w);
    /* We get all index sx latch of the table to avoid worklaod disturb reclaim. */
    btr_get_all_index_sx_latch(r_item, &mtr_w);
    /* Get x_lock of space to remove extent and truncate space */
    rw_lock_t*	latch = fil_space_get_latch(space, &flags);
    mtr_x_lock(latch, &mtr_w);

    /* add RW_X_LATCH on root page */
    header = btr_get_fsp_header(space, zip_size, &mtr_w);
    total_page = mach_read_from_4(header + FSP_SIZE);
    descr = xdes_get_descriptor(space, zip_size, page_no, &mtr_w);

    /* Check the count of pages will be trucnate. */
    if (total_page - page_no != FSP_EXTENT_SIZE * srv_reclaim_n_extent) {
        sql_print_error("Reclaim failed: the count of pages will be truncate is not equal"
                "to the threshold, the count is:[%lu], the threshold is:[%lu], tablespace "
                "maybe change after reclaim, try to reclaim from ibd tail again.",
                total_page - page_no, FSP_EXTENT_SIZE * srv_reclaim_n_extent);
        mtr_commit(&mtr_w);
        return total_page - 1;
    }

    /* We truncate one extent each time, so page_no must be extent first page. */
    if (descr != NULL && page_no != xdes_get_extent_first_page(descr)) {
        sql_print_error("Reclaim failed: the page_no:[%lu] is not extent first page, "
                "the first page_no:[%lu], the tablespace last page_no is:[%lu], "
                "try to reclaim from ibd tail again.",
                page_no, xdes_get_extent_first_page(descr), total_page - 1);
        mtr_commit(&mtr_w);
        return total_page - 1;
    }

    mtr_start(&mtr_r);
    block = btr_block_get(space, zip_size, page_no, RW_X_LATCH, NULL, &mtr_r);
    page = buf_block_get_frame(block);
    page_type = mach_read_from_2(page + FIL_PAGE_TYPE);

    if (!fil_set_being_extended(space)) {
        /* Set being_extended failed, return. */
        sql_print_error("Reclaim failed: set being_extended failed, current page_no:[%lu] "
                "the tablespace last page_no is:[%lu], try to reclaim from ibd tail again.",
                page_no, total_page - 1);
        mtr_commit(&mtr_w);
        mtr_commit(&mtr_r);
        return total_page - 1;
    }

    /* Check pages from total_page to page_no whether are freed */
    if (!btr_check_freed(space, zip_size, total_page - 1, page_no, blocks, &block_num, &mtr_r)) {
        sql_print_error("Reclaim failed: the extent is not freed, current page_no:[%lu] "
                "the tablespace last page_no is:[%lu], try to reclaim from ibd tail again.",
                page_no, total_page - 1);
        /* Reset being_extended before return. */    
        fil_reset_being_extended(space);
        mtr_commit(&mtr_w);
        mtr_commit(&mtr_r);
        return total_page - 1;
    }

    /* Extent is freed, we truncate it and remove extent from free list of segment */
#ifdef BAIDU_RECLAIM_DEBUG        
    if (page_type == FIL_PAGE_INDEX && descr != NULL) {
        sql_print_information("Reclaim:[DEBUG] normal extent: all pages are freed.");
    }
    if (page_type == FIL_PAGE_TYPE_XDES && descr != NULL) {
        sql_print_information("Reclaim:[DEBUG] manage extent: all pages are freed.");
    }
    if (page_type == FIL_PAGE_TYPE_ALLOCATED && descr == NULL) {
        sql_print_information("Reclaim:[DEBUG] allocated extent: truncate directly.");
    }
#endif
    /* Begin to truncate. */
    {
        trunc_size = page_no * page_size;
        sql_print_information("Reclaim: table:[%s] total pages:[%lu], total size:[%lu], "
                "remaining pages:[%lu], truncate to:[%lu], truncate [%lu] extent.",
                r_item->table, total_page, total_page * page_size,
                page_no, trunc_size, (total_page - page_no) / FSP_EXTENT_SIZE);

        page_level = btr_page_get_level(page, &mtr_r);
        index_id = btr_page_get_index_id(page);

        if (descr) {
            iter = r_item->index_map.find(index_id);
            if (iter != r_item->index_map.end()) {
                index = iter->second;
                seg_header = btr_get_fseg_header(index, page_level, &mtr_w);
            }
            if (!fseg_remove_freed_extent(header, seg_header, space, descr,
                                        page_no, zip_size, page_type, &mtr_w)) {
                sql_print_error("Reclaim: remove extent from table:[%s] "
                        "list failed, but we had truncated the tablespace, "
                        "current total page:[%lu], exit.",
                        r_item->table, page_no);
                ut_error;
            }
        }

        free_limit = mach_read_from_4(header + FSP_FREE_LIMIT);
        if (page_no < free_limit) {
            sql_print_information("Reclaim: set table:[%s] "
                    "FSP_FREE_LIMIT from:[%lu] to:[%lu].",
                    r_item->table, free_limit, page_no);
            mlog_write_ulint(header + FSP_FREE_LIMIT, page_no, MLOG_4BYTES, &mtr_w);
        }

        sql_print_information("Reclaim: set table:[%s] FSP_SIZE from:[%lu] to:[%lu].",
                r_item->table, total_page, page_no);

        mlog_write_ulint(header + FSP_SIZE, page_no, MLOG_4BYTES, &mtr_w);
        mtr_commit(&mtr_r);
        mtr_commit(&mtr_w);

        buf_flush_blocks(blocks, block_num);
        fil_flush(space);

        if (fil_truncate_wrapper(space, trunc_size, total_page, page_no,
                blocks, block_num, zip_size)) {
            sql_print_information("Reclaim: truncate table:[%s] succeed, "
                    "current total pages:[%lu], total size:[%lu].",
                    r_item->table, page_no, trunc_size);
            return page_no;
        } else {
            /* Truncate failed, restore metadata of space. */
            sql_print_warning("Reclaim: try to truncate table:[%s] failed, "
                    "current page_no:[%lu] belongs to index:[%lu], extent no:[%lu], "
                    "page offset of extent:[%lu], this extent is not freed, try again.",
                    r_item->table, page_no, index_id, page_no / FSP_EXTENT_SIZE,
                    page_no % FSP_EXTENT_SIZE);
            return total_page - 1;
        }
    }// end truncate
    return total_page - 1;
}

/******************************************************************//**
Thread that move record from tail to head of ibd, then truncate freed
space and reclaim it. */
extern "C" UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(btr_ibd_reclaim_thread)(
/*==========================================*/
    void*    arg)    /*!< in: work queue */
{
    dict_index_t*   clust_index = NULL;
    mtr_t mtr;
    fsp_header_t *header = NULL;
    ulint zip_size = 0;
    ulint page_limit = 0;
    ulint cur_page_no = 0;
    ulint space = 0;
    bool        check_interval = false;
    ulonglong   last_reclaim_time = 0;
    cpu_stat_t  cpu_stat_one;
    cpu_stat_t  cpu_stat_two;
    double cpu_idle;

    while (srv_shutdown_state == SRV_SHUTDOWN_NONE) {
        /* If online reclaim ibd or defragment is disabled, sleep before
        checking whether it's enabled. */
        if (!srv_reclaim) {
            check_interval = false;
            os_thread_sleep(BTR_RECLAIM_SLEEP_IN_USECS);
            continue;
        }
#if 0
        /* Create defragment item with db. */
        btr_reclaim_add_defragment_item(&check_interval, &last_reclaim_time);

        /* The following call won't remove the r_item from work queue.
        We only get a pointer to it to work on. This will make sure
        when user issue a kill command, all indices are in the work
        queue to be searched. This also means that the user thread
        cannot directly remove the r_item from queue (since we might be
        using it). So user thread only marks index as removed. */
        btr_reclaim_item_t* r_item = btr_reclaim_get_item();

        /* If work queue is empty, sleep and check later. */
        if (!r_item) {
            os_thread_sleep(BTR_RECLAIM_SLEEP_IN_USECS);
            continue;
        }

        /* Open all indexes of table, and add them into r_item->index_map */
        clust_index = btr_open_table_index(r_item->index_map, r_item->table);
        ut_ad(clust_index != NULL);

        mtr_start(&mtr);
        /* First, wo get all index sx latch */
        btr_get_all_index_sx_latch(r_item, &mtr);

        /* Initialize variables with cluster index */
        space = dict_index_get_space(clust_index);
        zip_size = dict_table_zip_size(clust_index->table);
        header = btr_get_fsp_header(space, zip_size, &mtr);
        page_limit = btr_get_reclaim_page_no(r_item, header);

        buf_block_t **blocks = new buf_block_t* [FSP_EXTENT_SIZE * srv_reclaim_n_extent];

        if (page_limit > 3) {
            cur_page_no = page_limit;
            
            /* Load FSP_EXTENT_SIZE pages from cur_page_no. */
            uint n_pages = 0; // load pages number actually
            
            n_pages = btr_load_n_pages(space, zip_size, blocks,
                                    FSP_EXTENT_SIZE * srv_reclaim_n_extent,
                                    &cur_page_no, &mtr);

            if (n_pages == 0 || !btr_index_can_be_reclaimed(r_item, space, zip_size,
                                                            blocks, n_pages, &mtr)) {
                sql_print_information("Reclaim: reclaim table:[%s] over, "
                        "there is no free space to reclaim.",
                        r_item->table);
                mtr_commit(&mtr);
                r_item->removed = true;
                continue;
            }

            get_cpu_stat(&cpu_stat_one);
            /* Reclaim pages. */
            ulint last_page_no = btr_reclaim_n_pages(r_item, space, zip_size,
                                                    blocks, n_pages, &mtr);

            /* Reclaim pages failed, do not truncate ibd, reclaim again. */
            if (last_page_no != cur_page_no + 1) {
                sql_print_error("Reclaim: relcaim [%u] pages from [%lu] to [%lu] failed, "
                        "reclaim last_page_no:[%lu] != target page_no:[%lu].",
                        n_pages, page_limit, cur_page_no + 1,
                        last_page_no, cur_page_no + 1);
                mtr_commit(&mtr);
                continue;
            }

            mtr_commit(&mtr);

            /* Reclaim succeed, we try to truncate ibd. Because reclaim dirty pages
            at flush list tail, so flush all dirty page firstly. */
            log_make_latest_checkpoint();

            /* Try to truncate space after last_page_no. */
            ulint truncate_page_no = btr_try_to_truncate_ibd(r_item, space,
                                                        last_page_no, zip_size, blocks);
            if (last_page_no == truncate_page_no) {
                sql_print_information("Reclaim: truncate table:[%s] succeed, "
                        "original last page_no:[%lu], now:[%lu].",
                        r_item->table, page_limit, truncate_page_no - 1);

                page_limit = cur_page_no;
            } else {
                sql_print_warning("Reclaim: truncate table:[%s] failed, "
                        "original last page_no:[%lu], now:[%lu].",
                        r_item->table, page_limit, truncate_page_no);

                page_limit = truncate_page_no;
            }
            get_cpu_stat(&cpu_stat_two);

            if (page_limit <= FSP_EXTENT_SIZE * srv_reclaim_size || r_item->removed == true) {
                // TODO: 补充统计信息
                /* Reaching the end of the index. */
                // dict_stats_empty_defrag_stats(index);
                // dict_stats_save_defrag_stats(index);
                // dict_stats_save_defrag_summary(index);
                r_item->removed = true;
                sql_print_information("Reclaim: reclaim table:[%s] over, "
                                "current table size:[%lu] Bytes",
                        r_item->table,
                        page_limit * zip_size ? zip_size : UNIV_PAGE_SIZE);
            } else {
                /* If we haven't reached the first page of the index,
                place the cursor on the last record of last page,
                store the cursor position, and put back in queue. */
                // page_t* last_page = buf_block_get_frame(last_block);
                // rec_t* rec = page_rec_get_prev(
                //     page_get_supremum_rec(last_page));
                // ut_a(page_rec_is_user_rec(rec));
                // page_cur_position(rec, last_block,
                //           btr_cur_get_page_cur(cursor));
                // btr_pcur_store_position(pcur, &mtr);
                /* Update the last_processed time of this index. */
                r_item->last_processed = ut_timer_now();
                r_item->page_no = page_limit;
            }
            sql_print_information("Reclaim: truncate is over, new page_limit:[%lu]",
                    page_limit);

            /* Check CPU idle. */
            while (srv_shutdown_state == SRV_SHUTDOWN_NONE && srv_reclaim) {
                cpu_idle = cal_cpuidle(&cpu_stat_one, &cpu_stat_two);
                if (cpu_idle < srv_reclaim_cpu_idle) {
                    sql_print_information("Reclaim: cpu_idle:[%lf] is less than "
                                    "srv_reclaim_cpu_idle:[%u], sleep 1 second.",
                            cpu_idle, srv_reclaim_cpu_idle);
                    get_cpu_stat(&cpu_stat_one);
                    os_thread_sleep(BTR_RECLAIM_SLEEP_IN_USECS);
                    get_cpu_stat(&cpu_stat_two);
                } else {
                    break;
                }
            }
        } else {
            mtr_commit(&mtr);
        }
        delete blocks;
#endif
    } // end while
    btr_reclaim_shutdown();
    os_thread_exit(NULL);
    OS_THREAD_DUMMY_RETURN;
}
#endif /* !UNIV_HOTBACKUP */
