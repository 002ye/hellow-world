#ifndef ut0new_h
#define ut0new_h

#include <algorithm>
#include "ut0counter.h"

#define UT_NEW(expr, key) ::new (std::nothrow) expr
#define UT_NEW_NOKEY(expr) ::new (std::nothrow) expr
#define UT_DELETE(ptr) ::delete ptr

#define UT_NEW_ARRAY(type, n_elements, key) \
::new (std::nothrow) type[n_elements]

#define UT_NEW_ARRAY_NOKEY(type, n_elements) \
::new (std::nothrow) type[n_elements]

#define UT_DELETE_ARRAY(ptr) ::delete[] ptr

#define ut_malloc_nokey(n_bytes) ::malloc(n_bytes)

#define ut_zalloc_nokey(n_bytes) ::calloc(1, n_bytes)

#define ut_zalloc_nokey_nofatal(n_bytes) ::calloc(1, n_bytes)

#define ut_free_new(ptr) ::free(ptr)

/** This is a forward declaration, which is because of the circular dependency
between ut0new.h and ut0byte.h (going through univ.i and sync0types.h).
I've managed to observe problem when building MEB and this helps then. */
UNIV_INLINE
void *ut_align(const void *ptr, ulint align_no);

/** Abstract class to manage an object that is aligned to specified number of
bytes.
@tparam	T_Type		type of the object that is going to be managed
@tparam T_Align_to	number of bytes to align to */
template <typename T_Type, size_t T_Align_to>
class aligned_memory {
	public:
	virtual ~aligned_memory() {
		if (!this->is_object_empty()) {
		this->free_memory();
		}
	}

	virtual void destroy() = 0;

	/** Allows casting to managed objects type to use it directly */
	operator T_Type *() const {
		ut_a(m_object != nullptr);
		return m_object;
	}

	/** Allows referencing the managed object as this was a normal
	pointer. */
	T_Type *operator->() const {
		ut_a(m_object != nullptr);
		return m_object;
	}

	protected:
	/** Checks if no object is currently being managed. */
	bool is_object_empty() const { return m_object == nullptr; }

	/** Allocates memory for a new object and prepares aligned address for
	the object.
	@param[in]	size	Number of bytes to be delivered for the aligned
	object. Number of bytes actually allocated will be higher. */
	T_Type *allocate(size_t size) {
		static_assert(T_Align_to > 0, "Incorrect alignment parameter");
		ut_a(m_memory == nullptr);
		ut_a(m_object == nullptr);

		m_memory = ut_zalloc_nokey(size + T_Align_to - 1);
		m_object = static_cast<T_Type *>(::ut_align(m_memory, T_Align_to));
		return m_object;
	}

	/** Releases memory used to store the object. */
	void free_memory() {
		ut_a(m_memory != nullptr);
		ut_a(m_object != nullptr);

		ut_free_new(m_memory);

		m_memory = nullptr;
		m_object = nullptr;
	}

	private:
	/** Stores pointer to aligned object memory. */
	T_Type *m_object = nullptr;

	/** Stores pointer to memory used to allocate the object. */
	void *m_memory = nullptr;
};

/** Manages an array of objects. The first element is aligned to specified
number of bytes.
@tparam	T_Type		type of the object that is going to be managed
@tparam T_Align_to	number of bytes to align to */
template <typename T_Type, size_t T_Align_to = CACHE_LINE_SIZE>
class aligned_array_pointer : public aligned_memory<T_Type, T_Align_to> {
	public:
	/** Allocates aligned memory for new objects. Objects must be trivially
	constructible and destructible.
	@param[in]	size	Number of elements to allocate. */
	void create(size_t size) {
#if !(defined __GNUC__ && __GNUC__ <= 4)
		static_assert(std::is_trivially_default_constructible<T_Type>::value,
					"Aligned array element type must be "
					"trivially default-constructible");
#endif
		m_size = size;
		this->allocate(sizeof(T_Type) * m_size);
	}

	/** Deallocates memory of array created earlier. */
	void destroy() {
		static_assert(std::is_trivially_destructible<T_Type>::value,
					"Aligned array element type must be "
					"trivially destructible");
		this->free_memory();
	}

	/** Accesses specified index in the allocated array.
	@param[in]	index	index of element in array to get reference to */
	T_Type &operator[](size_t index) const {
		ut_a(index < m_size);
		return ((T_Type *)*this)[index];
	}

	private:
	/** Size of the allocated array. */
	size_t m_size;
};

#endif /* ut0new_h */
