/*****************************************************************************

Copyright (c) 1995, 2013, Oracle and/or its affiliates. All rights reserved.
Copyright (c) 2009, Google Inc.

Portions of this file contain modifications contributed and copyrighted by
Google, Inc. Those modifications are gratefully acknowledged and are described
briefly in the InnoDB documentation. The contributions by Google are
incorporated with their permission, and subject to the conditions contained in
the file COPYING.Google.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Suite 500, Boston, MA 02110-1335 USA

*****************************************************************************/

/**************************************************//**
@file include/log0log.h
Database log

Created 12/9/1995 Heikki Tuuri
*******************************************************/

#ifndef log0log_h
#define log0log_h

#include "univ.i"
#include "ut0byte.h"
#include "ut0lst.h"
#include "ut0link_buf.h"
#ifndef UNIV_HOTBACKUP
#include "sync0sync.h"
#include "sync0rw.h"
#include "os0file.h"
#include "sync0sharded_rw.h"
#endif /* !UNIV_HOTBACKUP */

#include "log0test.h"
#include "log0types.h"

#ifdef UNIV_DEBUG
/** Flag: write to log file? */
extern	ibool	log_do_write;
/** Flag: enable debug output when writing to the log? */
extern	ibool	log_debug_writes;
#else /* UNIV_DEBUG */
/** Write to log */
# define log_do_write TRUE
#endif /* UNIV_DEBUG */

// Code for log group is removed.
// Though the format of the checkpoint still depends on this constant.
// So keep the macro here only for redo log compatibility.
/** Maximum number of log groups in log_group_t::checkpoint_buf */
#define LOG_MAX_N_GROUPS	32

extern log_t*	log_sys;

#ifndef UNIV_HOTBACKUP
/** Represents currently running test of redo log, nullptr otherwise. */
extern std::unique_ptr<Log_test> log_test;
#endif /* !UNIV_HOTBACKUP */

/* Values used as flags */
#define LOG_FLUSH	7652559
#define LOG_CHECKPOINT	78656949
#define LOG_RECOVER	98887331

/* The counting of lsn's starts from this value: this must be non-zero */
#define LOG_START_LSN		((lsn_t) (16 * OS_FILE_LOG_BLOCK_SIZE))

#define LOG_BUFFER_SIZE		(srv_log_buffer_size * UNIV_PAGE_SIZE)
#define LOG_ARCHIVE_BUF_SIZE	(srv_log_buffer_size * UNIV_PAGE_SIZE / 4)

/* Offsets of a log block header */
#define	LOG_BLOCK_HDR_NO	0	/* block number which must be > 0 and
	 is allowed to wrap around at 2G; the
	 highest bit is set to 1 if this is the
	 first log block in a log flush write
	 segment */
#define LOG_BLOCK_FLUSH_BIT_MASK 0x80000000UL
/* mask used to get the highest bit in
the preceding field */
#define	LOG_BLOCK_HDR_DATA_LEN	4	/* number of bytes of log written to
	 this block */
#define	LOG_BLOCK_FIRST_REC_GROUP 6	/* offset of the first start of an
	 mtr log record group in this log block,
	 0 if none; if the value is the same
	 as LOG_BLOCK_HDR_DATA_LEN, it means
	 that the first rec group has not yet
	 been catenated to this log block, but
	 if it will, it will start at this
	 offset; an archive recovery can
	 start parsing the log records starting
	 from this offset in this log block,
	 if value not 0 */
#define LOG_BLOCK_CHECKPOINT_NO	8	/* 4 lower bytes of the value of
	 log_sys->next_checkpoint_no when the
	 log block was last written to: if the
	 block has not yet been written full,
	 this value is only updated before a
	 log buffer flush */
#define LOG_BLOCK_HDR_SIZE	12	/* size of the log block header in
	 bytes */

/* Offsets of a log block trailer from the end of the block */
#define	LOG_BLOCK_CHECKSUM	4	/* 4 byte checksum of the log block
	 contents; in InnoDB versions
	 < 3.23.52 this did not contain the
	 checksum but the same value as
	 .._HDR_NO */
#define	LOG_BLOCK_TRL_SIZE	4	/* trailer size in bytes */

/* Offsets for a checkpoint field */
#define LOG_CHECKPOINT_NO		0
#define LOG_CHECKPOINT_LSN		8
#define LOG_CHECKPOINT_OFFSET_LOW32	16
#define LOG_CHECKPOINT_LOG_BUF_SIZE	20
#define	LOG_CHECKPOINT_ARCHIVED_LSN	24
#define	LOG_CHECKPOINT_GROUP_ARRAY	32

/* For each value smaller than LOG_MAX_N_GROUPS the following 8 bytes: */

#define LOG_CHECKPOINT_ARCHIVED_FILE_NO	0
#define LOG_CHECKPOINT_ARCHIVED_OFFSET	4

#define	LOG_CHECKPOINT_ARRAY_END	(LOG_CHECKPOINT_GROUP_ARRAY\
+ LOG_MAX_N_GROUPS * 8)
#define LOG_CHECKPOINT_CHECKSUM_1	LOG_CHECKPOINT_ARRAY_END
#define LOG_CHECKPOINT_CHECKSUM_2	(4 + LOG_CHECKPOINT_ARRAY_END)
#if 0
#define LOG_CHECKPOINT_FSP_FREE_LIMIT	(8 + LOG_CHECKPOINT_ARRAY_END)
/*!< Not used (0);
This used to contain the
current fsp free limit in
tablespace 0, in units of one
megabyte.

This information might have been used
since mysqlbackup version 0.35 but
before 1.41 to decide if unused ends of
non-auto-extending data files
in space 0 can be truncated.

This information was made obsolete
by mysqlbackup --compress. */
#define LOG_CHECKPOINT_FSP_MAGIC_N	(12 + LOG_CHECKPOINT_ARRAY_END)
/*!< Not used (0);
This magic number tells if the
checkpoint contains the above field:
the field was added to
InnoDB-3.23.50 and
removed from MySQL 5.6 */
#define LOG_CHECKPOINT_FSP_MAGIC_N_VAL	1441231243
/*!< if LOG_CHECKPOINT_FSP_MAGIC_N
contains this value, then
LOG_CHECKPOINT_FSP_FREE_LIMIT
is valid */
#endif
#define LOG_CHECKPOINT_OFFSET_HIGH32	(16 + LOG_CHECKPOINT_ARRAY_END)
#define LOG_CHECKPOINT_SIZE		(20 + LOG_CHECKPOINT_ARRAY_END)

// Code for log group is removed.
// Though the format of the checkpoint still depends on this constant.
// So keep the macro here only for redo log compatibility.
/* Offsets of a log file header */
#define LOG_GROUP_ID		0	/* log group number */
#define LOG_FILE_START_LSN	4	/* lsn of the start of data in this
	 log file */
#define LOG_FILE_NO		12	/* 4-byte archived log file number;
	 this field is only defined in an
	 archived log file */
#define LOG_FILE_WAS_CREATED_BY_HOT_BACKUP 16
/* a 32-byte field which contains
the string 'ibbackup' and the
creation time if the log file was
created by mysqlbackup --restore;
when mysqld is first time started
on the restored database, it can
print helpful info for the user */
#define	LOG_FILE_ARCH_COMPLETED	OS_FILE_LOG_BLOCK_SIZE
/* this 4-byte field is TRUE when
the writing of an archived log file
has been completed; this field is
only defined in an archived log file */
#define LOG_FILE_END_LSN	(OS_FILE_LOG_BLOCK_SIZE + 4)
/* lsn where the archived log file
at least extends: actually the
archived log file may extend to a
later lsn, as long as it is within the
same log block as this lsn; this field
is defined only when an archived log
file has been completely written */
#define LOG_CHECKPOINT_1	OS_FILE_LOG_BLOCK_SIZE
/* first checkpoint field in the log
header; we write alternately to the
checkpoint fields when we make new
checkpoints; this field is only defined
in the first log file */
#define LOG_CHECKPOINT_2	(3 * OS_FILE_LOG_BLOCK_SIZE)
/* second checkpoint field in the log
header */
#define LOG_FILE_HDR_SIZE	(4 * OS_FILE_LOG_BLOCK_SIZE)

#define LOG_OK		301
#define LOG_CORRUPTED	302

/** Default value of innodb_log_write_ahead_size (in bytes). */
constexpr ulong INNODB_LOG_WRITE_AHEAD_SIZE_DEFAULT = 8192;

/** Minimum allowed value of innodb_log_write_ahead_size. */
constexpr ulong INNODB_LOG_WRITE_AHEAD_SIZE_MIN = OS_FILE_LOG_BLOCK_SIZE;

/** Maximum allowed value of innodb_log_write_ahead_size. */
constexpr ulint INNODB_LOG_WRITE_AHEAD_SIZE_MAX =
	UNIV_PAGE_SIZE_DEF;  // 16kB...

/** Default value of innodb_log_write_max_size (in bytes). */
constexpr ulint INNODB_LOG_WRITE_MAX_SIZE_DEFAULT = 4096;

/** Default value of innodb_log_checkpointer_every (in milliseconds). */
constexpr ulong INNODB_LOG_CHECKPOINT_EVERY_DEFAULT = 1000;  // 1000ms = 1s

/** Default value of innodb_log_writer_spin_delay (in spin rounds). */
constexpr ulong INNODB_LOG_WRITER_SPIN_DELAY_DEFAULT = 25000;

/** Default value of innodb_log_writer_timeout (in microseconds). */
constexpr ulong INNODB_LOG_WRITER_TIMEOUT_DEFAULT = 10;

/** Default value of innodb_log_spin_cpu_abs_lwm.
Expressed in percent (80 stands for 80%) of a single CPU core. */
constexpr ulong INNODB_LOG_SPIN_CPU_ABS_LWM_DEFAULT = 80;

/** Default value of innodb_log_spin_cpu_pct_hwm.
Expressed in percent (50 stands for 50%) of all CPU cores. */
constexpr uint INNODB_LOG_SPIN_CPU_PCT_HWM_DEFAULT = 50;

/** Default value of innodb_log_wait_for_write_spin_delay (in spin rounds). */
constexpr ulong INNODB_LOG_WAIT_FOR_WRITE_SPIN_DELAY_DEFAULT = 25000;

/** Default value of innodb_log_wait_for_write_timeout (in microseconds). */
constexpr ulong INNODB_LOG_WAIT_FOR_WRITE_TIMEOUT_DEFAULT = 1000;

/** Default value of innodb_log_wait_for_flush_spin_delay (in spin rounds). */
constexpr ulong INNODB_LOG_WAIT_FOR_FLUSH_SPIN_DELAY_DEFAULT = 25000;

/** Default value of innodb_log_wait_for_flush_spin_hwm (in microseconds). */
constexpr ulong INNODB_LOG_WAIT_FOR_FLUSH_SPIN_HWM_DEFAULT = 400;

/** Default value of innodb_log_wait_for_flush_timeout (in microseconds). */
constexpr ulong INNODB_LOG_WAIT_FOR_FLUSH_TIMEOUT_DEFAULT = 1000;

/** Default value of innodb_log_flusher_spin_delay (in spin rounds). */
constexpr ulong INNODB_LOG_FLUSHER_SPIN_DELAY_DEFAULT = 25000;

/** Default value of innodb_log_flusher_timeout (in microseconds). */
constexpr ulong INNODB_LOG_FLUSHER_TIMEOUT_DEFAULT = 10;

/** Default value of innodb_log_write_notifier_spin_delay (in spin rounds). */
constexpr ulong INNODB_LOG_WRITE_NOTIFIER_SPIN_DELAY_DEFAULT = 0;

/** Default value of innodb_log_write_notifier_timeout (in microseconds). */
constexpr ulong INNODB_LOG_WRITE_NOTIFIER_TIMEOUT_DEFAULT = 10;

/** Default value of innodb_log_flush_notifier_spin_delay (in spin rounds). */
constexpr ulong INNODB_LOG_FLUSH_NOTIFIER_SPIN_DELAY_DEFAULT = 0;

/** Default value of innodb_log_flush_notifier_timeout (in microseconds). */
constexpr ulong INNODB_LOG_FLUSH_NOTIFIER_TIMEOUT_DEFAULT = 10;

/** Default value of innodb_log_closer_spin_delay (in spin rounds). */
constexpr ulong INNODB_LOG_CLOSER_SPIN_DELAY_DEFAULT = 0;

/** Default value of innodb_log_closer_timeout (in microseconds). */
constexpr ulong INNODB_LOG_CLOSER_TIMEOUT_DEFAULT = 1000;

/** Default value of innodb_log_buffer_size (in bytes). */
constexpr ulong INNODB_LOG_BUFFER_SIZE_DEFAULT = 16 * 1024 * 1024UL;

/** Minimum allowed value of innodb_log_buffer_size. */
constexpr ulong INNODB_LOG_BUFFER_SIZE_MIN = 256 * 1024UL;

/** Maximum allowed value of innodb_log_buffer_size. */
constexpr ulong INNODB_LOG_BUFFER_SIZE_MAX = LONG_MAX;

/** Default value of innodb_log_recent_written_size (in bytes). */
constexpr ulong INNODB_LOG_RECENT_WRITTEN_SIZE_DEFAULT = 1024 * 1024;

/** Minimum allowed value of innodb_log_recent_written_size. */
constexpr ulong INNODB_LOG_RECENT_WRITTEN_SIZE_MIN = OS_FILE_LOG_BLOCK_SIZE;

/** Maximum allowed value of innodb_log_recent_written_size. */
constexpr ulong INNODB_LOG_RECENT_WRITTEN_SIZE_MAX = 1024 * 1024 * 1024UL;

/** Default value of innodb_log_recent_closed_size (in bytes). */
constexpr ulong INNODB_LOG_RECENT_CLOSED_SIZE_DEFAULT = 2 * 1024 * 1024;

/** Minimum allowed value of innodb_log_recent_closed_size. */
constexpr ulong INNODB_LOG_RECENT_CLOSED_SIZE_MIN = OS_FILE_LOG_BLOCK_SIZE;

/** Maximum allowed value of innodb_log_recent_closed_size. */
constexpr ulong INNODB_LOG_RECENT_CLOSED_SIZE_MAX = 1024 * 1024 * 1024UL;

/** Default value of innodb_log_events (number of events). */
constexpr ulong INNODB_LOG_EVENTS_DEFAULT = 2048;

/** Minimum allowed value of innodb_log_events. */
constexpr ulong INNODB_LOG_EVENTS_MIN = 1;

/** Maximum allowed value of innodb_log_events. */
constexpr ulong INNODB_LOG_EVENTS_MAX = 1024 * 1024 * 1024UL;

/** Value to which MLOG_TEST records should sum up within a group. */
constexpr int64_t MLOG_TEST_VALUE = 10000;

/** Controls asynchronous preflushing of modified buffer pages.
Should be less than the LOG_POOL_PREFLUSH_RATIO_SYNC. */
constexpr uint32_t LOG_POOL_PREFLUSH_RATIO_ASYNC = 8;
/** Controls asynchronous making of a new checkpoint.
Should be bigger than LOG_POOL_PREFLUSH_RATIO_SYNC. */
constexpr uint32_t LOG_POOL_CHECKPOINT_RATIO_ASYNC = 32;
/** Controls synchronous preflushing of modified buffer pages. */
constexpr uint32_t LOG_POOL_PREFLUSH_RATIO_SYNC = 16;
/** Per thread margin for the free space in the log, before a new query step
which modifies the database, is started. It's multiplied by maximum number
of threads, that can concurrently enter mini transactions. Expressed in
number of pages. */
constexpr uint32_t LOG_CHECKPOINT_FREE_PER_THREAD = 4;

/** Absolute margin for the free space in the log, before a new query step
which modifies the database, is started. Expressed in number of pages. */
constexpr uint32_t LOG_CHECKPOINT_EXTRA_FREE = 8;

/** Size of log block's data fragment (where actual data is stored). */
constexpr uint32_t LOG_BLOCK_DATA_SIZE =
	OS_FILE_LOG_BLOCK_SIZE - LOG_BLOCK_HDR_SIZE - LOG_BLOCK_TRL_SIZE;

/** Calculates lsn value for given sn value. Sequence of sn values
enumerate all data bytes in the redo log. Sequence of lsn values
enumerate all data bytes and bytes used for headers and footers
of all log blocks in the redo log. For every LOG_BLOCK_DATA_SIZE
bytes of data we have OS_FILE_LOG_BLOCK_SIZE bytes in the redo log.
NOTE that LOG_BLOCK_DATA_SIZE + LOG_BLOCK_HDR_SIZE + LOG_BLOCK_TRL_SIZE
== OS_FILE_LOG_BLOCK_SIZE. The calculated lsn value will always point
to some data byte (will be % OS_FILE_LOG_BLOCK_SIZE >= LOG_BLOCK_HDR_SIZE,
and < OS_FILE_LOG_BLOCK_SIZE - LOG_BLOCK_TRL_SIZE).

@param[in]	sn	sn value
@return lsn value for the provided sn value */
constexpr inline lsn_t log_translate_sn_to_lsn(lsn_t sn);

/** Maximum size of single MLOG_TEST record (in bytes). */
constexpr uint32_t MLOG_TEST_MAX_REC_LEN = 100;

/** Maximum number of MLOG_TEST records in single group of log records. */
constexpr uint32_t MLOG_TEST_GROUP_MAX_REC_N = 100;

#ifndef UNIV_HOTBACKUP
/***********************************************************************//**
Any database operation should call this when it has modified more than
about 4 pages. NOTE that this function may only be called when the thread
owns no synchronization objects except the dictionary mutex.

Checks if current log.sn exceeds log.sn_limit_for_start, in which case waits.
This is supposed to guarantee that we would not run out of space in the log
files when holding latches of some dirty pages (which could end up in
a deadlock, because flush of the latched dirty pages could be required
to reclaim the space and it is impossible to flush latched pages). */
UNIV_INLINE
void
log_free_check(void);
/****************************************************************
When the oldest dirty page age exceeds this value, we start
an asynchronous preflush of dirty pages. This function does not
have side-effects, it only reads and returns the limit value.
@return age of dirty page at which async. preflush is started */
inline lsn_t log_get_max_modified_age_async();
/******************************************************************
Initializes the log system. Note that the log system is not ready
for user writes after this call is finished. It should be followed by
a call to log_start. Also, log background threads need to be started
manually using log_start_background_threads afterwards.
Hence the proper order of calls looks like this:
        - log_sys_init(),
        - log_start(),
        - log_start_background_threads().
*/
UNIV_INTERN
void
log_sys_init(
/*===========*/
	ulint	n_files,		/*!< in: number of log files */
	lsn_t	file_size,		/*!< in: log file size in bytes */
	ulint	space_id);		/*!< in: space id of the file space
					which contains the log files*/
/****************************************************************//**
write to the log file up to the last log entry.
@param[in]	sync	whether we want the written log
also to be flushed to disk. */
UNIV_INTERN
void
log_buffer_flush_to_disk(
	bool sync = true);
/****************************************************************//**
Makes a checkpoint at the latest lsn and writes it to first page of each
data file in the database, so that we know that the file spaces contain
all modifications up to that lsn. This can only be called at database
shutdown. This function also writes all log in log files to the log archive. */
UNIV_INTERN
void
logs_empty_and_mark_files_at_shutdown(void);
/*=======================================*/
/******************************************************//**
Reads a checkpoint info from a log header to log_sys->checkpoint_buf. */
UNIV_INTERN
void
log_read_checkpoint_info(
/*===========================*/
	ulint		field);	/*!< in: LOG_CHECKPOINT_1 or LOG_CHECKPOINT_2 */

/********************************************************************//**
Reads a specified log segment to a buffer. */
UNIV_INTERN
void
recv_read_log_seg(
/*===================*/
	ulint		type,		/*!< in: LOG_ARCHIVE or LOG_RECOVER */
	byte*		buf,		/*!< in: buffer where to read */
	lsn_t		start_lsn,	/*!< in: read area start */
	lsn_t		end_lsn);	/*!< in: read area end */
#endif /* !UNIV_HOTBACKUP */
/************************************************************//**
Gets a log block flush bit.
@return	TRUE if this block was the first to be written in a log flush */
UNIV_INLINE
ibool
log_block_get_flush_bit(
/*====================*/
	const byte*	log_block);	/*!< in: log block */
/************************************************************//**
Gets a log block number stored in the header.
@return	log block number stored in the block header */
UNIV_INLINE
ulint
log_block_get_hdr_no(
/*=================*/
	const byte*	log_block);	/*!< in: log block */
/************************************************************//**
Gets a log block data length.
@return	log block data length measured as a byte offset from the block start */
UNIV_INLINE
ulint
log_block_get_data_len(
/*===================*/
	const byte*	log_block);	/*!< in: log block */
/************************************************************//**
Sets the log block data length. */
UNIV_INLINE
void
log_block_set_data_len(
/*===================*/
	byte*	log_block,	/*!< in/out: log block */
	ulint	len);		/*!< in: data length */
/************************************************************//**
Calculates the checksum for a log block.
@return	checksum */
UNIV_INLINE
ulint
log_block_calc_checksum(
/*====================*/
	const byte*	block);	/*!< in: log block */
/************************************************************//**
Gets a log block checksum field value.
@return	checksum */
UNIV_INLINE
ulint
log_block_get_checksum(
/*===================*/
	const byte*	log_block);	/*!< in: log block */
/************************************************************//**
Sets a log block checksum field value. */
UNIV_INLINE
void
log_block_set_checksum(
/*===================*/
	byte*	log_block,	/*!< in/out: log block */
	ulint	checksum);	/*!< in: checksum */
/************************************************************//**
Gets a log block first mtr log record group offset.
@return first mtr log record group byte offset from the block start, 0
if none */
UNIV_INLINE
ulint
log_block_get_first_rec_group(
/*==========================*/
	const byte*	log_block);	/*!< in: log block */
/************************************************************//**
Sets the log block first mtr log record group offset. */
UNIV_INLINE
void
log_block_set_first_rec_group(
/*==========================*/
	byte*	log_block,	/*!< in/out: log block */
	ulint	offset);	/*!< in: offset, 0 if none */
/************************************************************//**
Gets a log block checkpoint number field (4 lowest bytes).
@return	checkpoint no (4 lowest bytes) */
UNIV_INLINE
ulint
log_block_get_checkpoint_no(
/*========================*/
	const byte*	log_block);	/*!< in: log block */
/************************************************************//**
Initializes a log block in the log buffer. */
UNIV_INLINE
void
log_block_init(
/*===========*/
	byte*	log_block,	/*!< in: pointer to the log buffer */
	lsn_t	lsn);		/*!< in: lsn within the log block */
/************************************************************//**
Initializes a log block in the log buffer in the old, < 3.23.52 format, where
there was no checksum yet. */
UNIV_INLINE
void
log_block_init_in_old_format(
/*=========================*/
	byte*	log_block,	/*!< in: pointer to the log buffer */
	lsn_t	lsn);		/*!< in: lsn within the log block */
/************************************************************//**
Converts a lsn to a log block number.
@return	log block number, it is > 0 and <= 1G */
UNIV_INLINE
ulint
log_block_convert_lsn_to_no(
/*========================*/
	lsn_t	lsn);	/*!< in: lsn of a byte within the block */
/******************************************************//**
Prints info of the log. */
UNIV_INTERN
void
log_print(
/*======*/
	FILE*	file);	/*!< in: file where to print */
/******************************************************//**
Peeks the current lsn.
@return	TRUE if success, FALSE if could not get the log system mutex */
UNIV_INTERN
ibool
log_peek_lsn(
/*=========*/
	lsn_t*	lsn);	/*!< out: if returns TRUE, current lsn is here */
/**********************************************************************//**
Refreshes the statistics used to print per-second averages. */
UNIV_INTERN
void
log_refresh_stats(void);
/*===================*/
/********************************************************//**
Shutdown the log system but do not release all the memory. */
UNIV_INTERN
void
log_sys_close(void);
/*==============*/
/********************************************************//**
Free the log system data structures. */
UNIV_INTERN
void
log_mem_free(void);
/*==============*/
/********************************************************//**/

/** Writes a log file header to the log file space.
@param[in]	nth_file	header for the nth file in the log files
@param[in]	start_lsn	log file data starts at this lsn */
void log_files_header_flush(ulint nth_file, lsn_t start_lsn);

/** Calculates sn value for given lsn value.
@see log_translate_sn_to_lsn
@param[in]	lsn	lsn value
@return sn value for the provided lsn value */
inline lsn_t log_translate_lsn_to_sn(lsn_t lsn);

/** Gets the current lsn value. This value points to the first non
reserved data byte in the redo log. When next user thread reserves
space in the redo log, it starts at this lsn.

If the last reservation finished exactly before footer of log block,
this value points to the first byte after header of the next block.

NOTE that it is possible that the current lsn value does not fit
free space in the log files or in the log buffer. In such case,
user threads need to wait until the space becomes available.

@return current lsn */
inline lsn_t log_get_lsn(const log_t &log);

/** Stores a 4-byte checksum to the trailer checksum field of a log block.
This is used before writing the log block to disk. The checksum in a log
block is used in recovery to check the consistency of the log block.
@param[in]	log_block	 log block (completely filled in!) */
inline void log_block_store_checksum(byte *log_block);

#define log_writer_mutex_enter(log) mutex_enter(&((log).writer_mutex))

#define log_writer_mutex_enter_nowait(log) \
mutex_enter_nowait(&((log).writer_mutex))

#define log_writer_mutex_exit(log) mutex_exit(&((log).writer_mutex))

#define log_writer_mutex_own(log) \
(mutex_own(&((log).writer_mutex)) || !(log).writer_thread_alive.load())

#define log_checkpointer_mutex_enter(log) \
mutex_enter(&((log).checkpointer_mutex))

#define log_checkpointer_mutex_exit(log) mutex_exit(&((log).checkpointer_mutex))

#define log_checkpointer_mutex_own(log)      \
(mutex_own(&((log).checkpointer_mutex)) || \
 !(log).checkpointer_thread_alive.load())

#define log_flusher_mutex_enter(log) mutex_enter(&((log).flusher_mutex))

#define log_flusher_mutex_enter_nowait(log) \
mutex_enter_nowait(&((log).flusher_mutex))

#define log_flusher_mutex_exit(log) mutex_exit(&((log).flusher_mutex))

#define log_flusher_mutex_own(log) \
(mutex_own(&((log).flusher_mutex)) || !(log).flusher_thread_alive.load())

#define log_flush_notifier_mutex_enter(log) \
mutex_enter(&((log).flush_notifier_mutex))

#define log_flush_notifier_mutex_exit(log) \
mutex_exit(&((log).flush_notifier_mutex))

#define log_flush_notifier_mutex_own(log)      \
(mutex_own(&((log).flush_notifier_mutex)) || \
 !(log).flush_notifier_thread_alive.load())

#define log_write_notifier_mutex_enter(log) \
mutex_enter(&((log).write_notifier_mutex))

#define log_write_notifier_mutex_exit(log) \
mutex_exit(&((log).write_notifier_mutex))

#define log_write_notifier_mutex_own(log)      \
(mutex_own(&((log).write_notifier_mutex)) || \
 !(log).write_notifier_thread_alive.load())

#define log_closer_mutex_enter(log) mutex_enter(&((log).closer_mutex))

#define log_closer_mutex_exit(log) mutex_exit(&((log).closer_mutex))

#define log_closer_mutex_own(log) \
(mutex_own(&((log).closer_mutex)) || !(log).closer_thread_alive.load())

#define LOG_SYNC_POINT(a)					\
	do {									\
	DEBUG_SYNC_C(a);						\
	DBUG_EXECUTE_IF(a, DBUG_SUICIDE(););	\
		if (log_test != nullptr) {			\
		log_test->sync_point(a);			\
	}										\
} while (0)

/** Waits until there is free space in the log buffer. The free space has to be
available for range of sn values ending at the provided sn.
@see @ref sect_redo_log_waiting_for_writer
@param[in]     log     redo log
@param[in]     end_sn  end of the range of sn values */
void log_wait_for_space_in_log_buf(log_t &log, sn_t end_sn);

/** Waits until there is free space for range of sn values ending
at the provided sn, in both the log buffer and in the log files.
@param[in]	log       redo log
@param[in]	end_sn    end of the range of sn values */
void log_wait_for_space(log_t &log, sn_t end_sn);

/** Calculates margin which has to be used in log_free_check() call,
when checking if user thread should wait for more space in redo log.
@return size of the margin to use */
sn_t log_free_check_margin(const log_t &log);

/** Waits until there is free space in log files which includes
concurrency margin required for all threads. You should rather
use log_free_check().
@see @ref sect_redo_log_reclaim_space
@param[in]     log   redo log
@param[in]     sn    sn for which there should be concurrency margin */
void log_free_check_wait(log_t &log, sn_t sn);

/** Updates sn limit values up to which user threads may consider the
reserved space as available both in the log buffer and in the log files.
Both limits - for the start and for the end of reservation, are updated.
Limit for the end is the only one, which truly guarantees that there is
space for the whole reservation. Limit for the start is used to check
free space when being outside mtr (without latches), in which case it
is unknown how much we will need to reserve and write, so current sn
is then compared to the limit. This is called whenever these limits
may change - when write_lsn or last_checkpoint_lsn are advanced,
when the log buffer is resized or margins are changed (e.g. because
of changed concurrency limit).
@param[in,out]	log	redo log */
void log_update_limits(log_t &log);

/** Waits until the redo log is written up to a provided lsn.
@param[in]	log		redo log
@param[in]	lsn		lsn to wait for
@param[in]	flush_to_disk	true: wait until it is flushed
@return statistics about waiting inside */
Wait_stats log_write_up_to(log_t &log, lsn_t end_lsn, bool flush_to_disk);

/** Changes size of the log buffer. This is a non-thread-safe version
which might be invoked only when there are no concurrent possible writes
to the log buffer. It is used in log_buffer_reserve() when a requested
size to reserve is larger than size of the log buffer.
@param[in,out]	log		redo log
@param[in]	new_size	requested new size
@param[in]	end_lsn		maximum lsn written to log buffer
@return true iff succeeded in resize */
bool log_buffer_resize_low(log_t &log, size_t new_size, lsn_t end_lsn);

/** Validates that the log writer, flusher threads are active.
Used only to assert, that the state is correct.
@param[in]	log	redo log */
void log_background_write_threads_active_validate(const log_t &log);

/** Validates that all the log background threads are active.
Used only to assert, that the state is correct.
@param[in]	log	redo log */
void log_background_threads_active_validate(const log_t &log);

/** Advances log.buf_ready_for_write_lsn using links in the recent written
buffer. It's used by the log writer thread only.
@param[in]	log	redo log
@return true if and only if the lsn has been advanced */
bool log_advance_ready_for_write_lsn(log_t &log);

/** Advances log.buf_dirty_pages_added_up_to_lsn using links in the recent
closed buffer. It's used by the log closer thread only.
@param[in]	log	redo log
@return true if and only if the lsn has been advanced */
bool log_advance_dirty_pages_added_up_to_lsn(log_t &log);

/** Requests a sharp checkpoint write for provided or greater lsn.
@param[in,out]	log	redo log
@param[in]	sync	true -> wait until it is finished
@param[in]  lsn   lsn for which we need checkpoint (or greater chkp) */
void log_request_checkpoint(log_t &log, bool sync, lsn_t lsn);

/** Requests a new checkpoint write for lsn which is currently available
for checkpointing (the lsn is updated in log checkpointer thread).
@param[in,out]	log	redo log
@param[in]	sync	true -> wait until the write is finished */
void log_request_checkpoint(log_t &log, bool sync);

/** Make a checkpoint at the current lsn. Reads current lsn and waits
until all dirty pages have been flushed up to that lsn. Afterwards
requests a checkpoint write and waits until it is finished.
@param[in,out]	log	redo log
@return true iff current lsn was greater than last checkpoint lsn */
bool log_make_latest_checkpoint(log_t &log);

/** Make a checkpoint at the current lsn. Reads current lsn and waits
until all dirty pages have been flushed up to that lsn. Afterwards
requests a checkpoint write and waits until it is finished.
@return true iff current lsn was greater than last checkpoint lsn */
bool log_make_latest_checkpoint();

/** Make a checkpoint at or after a specified LSN.
@param[in,out]	log	redo log
@return true iff current lsn was greater than last checkpoint lsn */
bool log_make_checkpoint_at(log_t &log, lsn_t lsn);

/** Make a checkpoint at or after a specified LSN.
@return true iff current lsn was greater than specified lsn */
bool log_make_checkpoint_at(lsn_t lsn);

extern "C" {
/** The log checkpointer thread co-routine.
@see @ref sect_redo_log_checkpointer
@param[in,out]	log_ptr		pointer to redo log */
UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(log_checkpointer)(void* arg);

/** The log writer thread co-routine.
@see @ref sect_redo_log_writer
@param[in,out]	log_ptr		pointer to redo log */
UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(log_writer)(void* arg);

/** The log flusher thread co-routine.
@see @ref sect_redo_log_flusher
@param[in,out]	log_ptr		pointer to redo log */
UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(log_flusher)(void* arg);

/** The log flush notifier thread co-routine.
@see @ref sect_redo_log_flush_notifier
@param[in,out]	log_ptr		pointer to redo log */
UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(log_flush_notifier)(void* arg);

/** The log write notifier thread co-routine.
@see @ref sect_redo_log_write_notifier
@param[in,out]	log_ptr		pointer to redo log */
UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(log_write_notifier)(void* arg);

/** The log closer thread co-routine.
@see @ref sect_redo_log_closer
@param[in,out]	log_ptr		pointer to redo log */
UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(log_closer)(void* arg);

}
/** Requests a new checkpoint write for lsn which is currently available
for checkpointing (the lsn is updated in log checkpointer thread).
@param[in,out]	log	redo log
@param[in]	sync	true -> wait until the write is finished */
void log_request_checkpoint(log_t &log, bool sync);

/** Acquires the log buffer s-lock.
@param[in,out]	log	redo log
@return lock no, must be passed to s_lock_exit() */
size_t log_buffer_s_lock_enter(log_t &log);

/** Releases the log buffer s-lock.
@param[in,out]	log	redo log
@param[in]	lock_no	lock no received from s_lock_enter() */
void log_buffer_s_lock_exit(log_t &log, size_t lock_no);

/** Acquires the log buffer x-lock.
@param[in,out]	log	redo log */
void log_buffer_x_lock_enter(log_t &log);

/** Releases the log buffer x-lock.
@param[in,out]	log	redo log */
void log_buffer_x_lock_exit(log_t &log);

/** Writes data to the log buffer. The space in the redo log has to be
reserved before calling to this function and lsn pointing to inside the
reserved range of lsn values has to be provided.

The write does not have to cover the whole reserved space, but may not
overflow it. If it does not cover, then returned value should be used
to start the next write operation. Note that finally we must use exactly
all the reserved space.

@see @ref sect_redo_log_buf_write
@param[in,out]	log		redo log
@param[in]	handle		handle for the reservation of space
@param[in]	str		memory to write data from
@param[in]	str_len		number of bytes to write
@param[in]	start_lsn	lsn to start writing at (the reserved space)

@return end_lsn after writing the data (in the reserved space), could be
used to start the next write operation if there is still free space in
the reserved space */
lsn_t log_buffer_write(log_t &log, const Log_handle &handle, const byte *str,
						size_t str_len, lsn_t start_lsn);

/** Modifies header of log block in the log buffer, which contains
a given lsn value, and sets offset to the first group of log records
within the block.

This is used by mtr after writing a log record group which ends at
lsn belonging to different log block than lsn at which the group was
started. When write was finished at the last data byte of log block,
it is considered ended in the next log block, because the next data
byte belongs to that block.

During recovery, when recovery is started in the middle of some group
of log records, it first looks for the beginning of the next group.

@param[in,out]	log			redo log
@param[in]	handle			handle for the reservation of space
@param[in]	rec_group_end_lsn	lsn at which the first log record
group starts within the block containing this lsn value */
void log_buffer_set_first_record_group(log_t &log, const Log_handle &handle,
										lsn_t rec_group_end_lsn);

/** Adds a link start_lsn -> end_lsn to the log recent written buffer.

This function must be called after the data has been written to the
fragment of log buffer represented by range [start_lsn, end_lsn).
After the link is added, the log writer may write the data to disk.

NOTE that still dirty pages for the [start_lsn, end_lsn) are not added
to flush lists when this function is called.

@see @ref sect_redo_log_buf_add_links_to_recent_written
@param[in,out]	log		redo log
@param[in]	handle		handle for the reservation of space
@param[in]	start_lsn	start_lsn of the link to add
@param[in]	end_lsn		end_lsn of the link to add */
void log_buffer_write_completed(log_t &log, const Log_handle &handle,
									lsn_t start_lsn, lsn_t end_lsn);

/** Calculates age of current checkpoint as number of bytes since
last checkpoint. This includes bytes for headers and footers of
all log blocks. The calculation is based on the latest written
checkpoint lsn, and the current lsn, which points to the first
non reserved data byte. Note that the current lsn could not fit
the free space in the log files. This means that the checkpoint
age could potentially be larger than capacity of the log files.
However we do the best effort to avoid such situations, and if
they happen, user threads wait until the space is reclaimed.
@param[in]	log	redo log
@return checkpoint age as number of bytes */
inline lsn_t log_get_checkpoint_age(const log_t &log);

/** Reserves space in the redo log for following write operations.
Space is reserved for a given number of data bytes. Additionally
bytes for required headers and footers of log blocks are reserved.

After the space is reserved, range of lsn values from a start_lsn
to an end_lsn is assigned. The log writer thread cannot proceed
further than to the start_lsn, until a link start_lsn -> end_lsn
has been added to the log recent written buffer.

NOTE that the link is added after data is written to the reserved
space in the log buffer. It is very critical to do all these steps
as fast as possible, because very likely the log writer thread is
waiting for the link.

@see @ref sect_redo_log_buf_reserve
@param[in,out]	log	redo log
@param[in]	len	number of data bytes to reserve for write
@return handle that represents the reservation */
Log_handle log_buffer_reserve(log_t &log, size_t len);

/** Waits until there is free space in the log recent closed buffer
for a given link start_lsn -> end_lsn. It does not add the link.

This is called just before dirty pages for [start_lsn, end_lsn)
are added to flush lists. That's because we need to guarantee,
that the delay until dirty page is added to flush list is limited.
For detailed explanation - @see log0write.cc.

@see @ref sect_redo_log_add_dirty_pages
@param[in,out]	log		redo log
@param[in]	handle		handle for the reservation of space */
void log_buffer_write_completed_before_dirty_pages_added(
		log_t &log, const Log_handle &handle);

/** Adds a link start_lsn -> end_lsn to the log recent closed buffer.

This is called after all dirty pages related to [start_lsn, end_lsn)
have been added to corresponding flush lists.
For detailed explanation - @see log0write.cc.

@see @ref sect_redo_log_add_link_to_recent_closed
@param[in,out]	log		redo log
@param[in]	handle		handle for the reservation of space */
void log_buffer_write_completed_and_dirty_pages_added(log_t &log,
														const Log_handle &handle);

/** Writes the next checkpoint info to header of the first log file.
Note that two pages of the header are used alternately for consecutive
checkpoints. If we crashed during the write, we would still have the
previous checkpoint info and recovery would work.
@param[in,out]	log			redo log
@param[in]	next_checkpoint_lsn	writes checkpoint at this lsn */
void log_files_write_checkpoint(log_t &log, lsn_t next_checkpoint_lsn);

/** Starts all the log background threads. This can be called only,
when the threads are inactive. This should never be called concurrently.
This may not be called during read-only mode.
@param[in,out]	log	redo log */
void log_start_background_threads(log_t &log);

/** Stops all the log background threads. This can be called only,
when the threads are active. This should never be called concurrently.
This may not be called in read-only mode. Note that is is impossible
to start log background threads in such case.
@param[in,out]	log	redo log */
void log_stop_background_threads(log_t &log);

/** @return true iff log threads are started */
bool log_threads_active(const log_t &log);

/** Validates that all the log background threads are inactive.
Used only to assert, that the state is correct.
@param[in]	log	redo log */
void log_background_threads_inactive_validate(const log_t &log);

/** Starts the initialized redo log system using a provided
checkpoint_lsn and current lsn.
@param[in,out]	log		redo log
@param[in]	checkpoint_no	checkpoint no (sequential number)
@param[in]	checkpoint_lsn	checkpoint lsn
@param[in]	start_lsn	current lsn to start at */
void log_start(log_t &log, checkpoint_no_t checkpoint_no, lsn_t checkpoint_lsn,
				lsn_t start_lsn);

/** Validates that the log writer thread is active.
Used only to assert, that the state is correct.
@param[in]	log	redo log */
void log_writer_thread_active_validate(const log_t &log);

/** Validates that the log closer thread is active.
Used only to assert, that the state is correct.
@param[in]	log	redo log */
void log_closer_thread_active_validate(const log_t &log);

/** Updates current_file_lsn and current_file_real_offset to correspond
to a given lsn. For this function to work, the values must already be
initialized to correspond to some lsn, for instance, a checkpoint lsn.
@param[in,out]	log	redo log
@param[in]	lsn	log sequence number to set files_start_lsn at */
void log_files_update_offsets(log_t &log, lsn_t lsn);

/** Calculates limits for maximum age of checkpoint and maximum age of
the oldest page. Uses current value of srv_thread_concurrency.
@param[in,out]	log	redo log
@retval true if success
@retval false if the redo log is too small to accommodate the number of
OS threads in the database server */
bool log_calc_max_ages(log_t &log);

/** Calculates offset within log files, including headers of log files,
for the provided lsn value.
@param[in]	log	redo log
@param[in]	lsn	log sequence number
@return real offset within the log files */
uint64_t log_files_real_offset_for_lsn(const log_t &log, lsn_t lsn);

/** Changes size of the log buffer. This is a thread-safe version.
It is used by SET GLOBAL innodb_log_buffer_size = X.
@param[in,out]	log		redo log
@param[in]	new_size	requested new size
@return true iff succeeded in resize */
bool log_buffer_resize(log_t &log, size_t new_size);

/** Increase concurrency_margin used inside log_free_check() calls. */
void log_increase_concurrency_margin(log_t &log);

/** Resizes the write ahead buffer in the redo log.
@param[in,out]	log		redo log
@param[in]	new_size	new size (in bytes) */
void log_write_ahead_resize(log_t &log, size_t new_size);
#ifndef UNIV_NONINL
#include "log0log.ic"
#endif

#endif
