/*****************************************************************************

Copyright (C) 2013, 2014 Facebook, Inc. All Rights Reserved.
Copyright (C) 2014, 2015, MariaDB Corporation.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Suite 500, Boston, MA 02110-1335 USA

*****************************************************************************/

#ifndef btr0defragment_h
#define btr0defragment_h

#include "univ.i"

#ifndef UNIV_HOTBACKUP

#include "btr0pcur.h"

/* Max number of pages to consider at once during defragmentation. */
#define BTR_DEFRAGMENT_MAX_N_PAGES	640
#define BTR_RECLAIM_MAX_N_PAGES 256

/** stats in btr_defragment */
extern ulint btr_defragment_compression_failures;
extern ulint btr_defragment_failures;
extern ulint btr_defragment_count;
typedef std::map<ulint, dict_index_t *> btr_index_map;

/** Item in the work queue for btr_degrament_thread. */
struct btr_defragment_item_t
{
    btr_pcur_t*	pcur;		/* persistent cursor where
                    btr_defragment_n_pages should start */
    os_event_t	event;		/* if not null, signal after work
                    is done */
    bool		removed;	/* Mark an item as removed */
    ulonglong	last_processed;	/* timestamp of last time this index
                    is processed by defragment thread */
    bool        reclaimed;  /* Continue reclaim after defragmention*/
    dict_index_t *index;
    ulint       space;      /* Space id of table that index belongs to */

    btr_defragment_item_t(btr_pcur_t* pcur, os_event_t event,
            dict_index_t* index, ulint space);
    ~btr_defragment_item_t();
};

/******************************************************************//**
Initialize defragmentation. */
void
btr_defragment_init(void);
/******************************************************************//**
Shutdown defragmentation. */
void
btr_defragment_shutdown();
/******************************************************************//**
Check whether the given index is in btr_defragment_wq. */
bool
btr_defragment_find_index(
    dict_index_t*	index);	/*!< Index to find. */
/******************************************************************//**
Add an index to btr_defragment_wq. Return a pointer to os_event if this
is a synchronized defragmentation. */
os_event_t
btr_defragment_add_index(
    dict_index_t*	index,	/*!< index to be added  */
    bool		async,	/*!< whether this is an async
                defragmentation */
    dberr_t*	err);	/*!< out: error code */
/******************************************************************//**
When table is dropped, this function is called to mark a table as removed in
btr_efragment_wq. The difference between this function and the remove_index
function is this will not NULL the event. */
void
btr_defragment_remove_table(
    dict_table_t*	table);	/*!< Index to be removed. */
/******************************************************************//**
Mark an index as removed from btr_defragment_wq. */
void
btr_defragment_remove_index(
    dict_index_t*	index);	/*!< Index to be removed. */
/*********************************************************************//**
Check whether we should save defragmentation statistics to persistent storage.*/
UNIV_INTERN
void
btr_defragment_save_defrag_stats_if_needed(
    dict_index_t*	index);	/*!< in: index */
/******************************************************************//**
Thread that merges consecutive b-tree pages into fewer pages to defragment
the index. */
extern "C" UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(btr_defragment_thread)(
/*==========================================*/
    void*   arg);       /*!< in: a dummy parameter required by
                os_thread_create */

/** Item in the work queue for btr_reclaim_thread. */
struct btr_reclaim_item_t
{
    char        table[FN_REFLEN]; /* Table name */
    btr_index_map index_map;
    // dict_index_t *index;
    // btr_pcur_t *pcur;       /* persistent cursor where
    //                 btr_reclaim_n_pages should start */
    bool        removed;    /* Mark an item as removed */
    ulonglong   create_time;    /* item create time */
    ulonglong   last_processed; /* timestamp of last time this index
                    is processed by defragment thread */
    ulint page_no;/* Move record from this page_no */
    ulint space;

    btr_reclaim_item_t(dict_index_t* index);

    ~btr_reclaim_item_t();
};
/** CPU state struct */
typedef struct cpu_packed {
    char name[20];
    unsigned int user;
    unsigned int nice;
    unsigned int system;
    unsigned int idle;
    unsigned int iowait;
    unsigned int irq;
    unsigned int softirq;
} cpu_stat_t;
/******************************************************************//**
Initialize defragmentation. */
void
btr_reclaim_init(void);
/******************************************************************//**
Construct reclaim item with defragmentation item. */
btr_reclaim_item_t *
gen_reclaim_item(btr_defragment_item_t *item);
/******************************************************************//**
Shutdown defragmentation. */
void
btr_defragment_shutdown();
/******************************************************************//**
Check whether the given index is in btr_defragment_wq. */
bool
btr_defragment_find_index(
    dict_index_t*	index);	/*!< Index to find. */
/******************************************************************//**
Add an index to btr_reclaim_wq. Return a pointer to os_event if this
is a synchronized reclaim command. */
os_event_t
btr_reclaim_add_index(
    dict_index_t*	index,	/*!< index to be added  */
    bool		async,	/*!< whether this is an async
                defragmentation */
    dberr_t*	err);	/*!< out: error code */
/******************************************************************//**
When table is dropped, this function is called to mark a table as removed in
btr_reclaim_wq. The difference between this function and the remove_index
function is this will not NULL the event. */
void
btr_reclaim_remove_table(
    dict_table_t*	table);	/*!< Index to be removed. */
/******************************************************************//**
Mark an index as removed from btr_reclaim_wq. */
void
btr_reclaim_remove_index(
    dict_index_t*	index);	/*!< Index to be removed. */
/******************************************************************//**
Push reclaim item into queue. */
void
btr_reclaim_add_item(
    btr_reclaim_item_t *r_item);
/*********************************************************************/ /**
Check whether we should save defragmentation statistics to persistent storage.*/
UNIV_INTERN
void
btr_defragment_save_defrag_stats_if_needed(
    dict_index_t*	index);	/*!< in: index */
/******************************************************************//**
Thread that move record from tail to head of ibd, then truncate freed
space and reclaim it. */
extern "C" UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(btr_ibd_reclaim_thread)(
/*==========================================*/
    void*	arg);		/*!< in: a dummy parameter required by
                os_thread_create */


#endif /* !UNIV_HOTBACKUP */
#endif
