/*****************************************************************************

Copyright (c) 1995, 2018, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2009, Google Inc.

Portions of this file contain modifications contributed and copyrighted by
Google, Inc. Those modifications are gratefully acknowledged and are described
briefly in the InnoDB documentation. The contributions by Google are
incorporated with their permission, and subject to the conditions contained in
the file COPYING.Google.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Suite 500, Boston, MA 02110-1335 USA

*****************************************************************************/

/**************************************************/ /**
 @file log/log0chkp.cc

 Redo log checkpoints, margins and log file headers.

 File consists of four groups:
   1. Coordination between log and buffer pool (oldest_lsn)
   2. Reading/writing log file headers
   3. Making checkpoints
   4. Margin calculations

 *******************************************************/


#ifndef UNIV_HOTBACKUP
#include <debug_sync.h>
#endif /* !UNIV_HOTBACKUP */

#include "buf0buf.h"
#include "buf0flu.h"
#include "dict0boot.h"
#include "dict0stats_bg.h"
#include "fil0fil.h"
#include "log0log.h"
#include "log0recv.h"
#include "mem0mem.h"
#include "srv0mon.h"
#include "srv0srv.h"
#include "srv0start.h"
#include "sync0sync.h"
#include "trx0roll.h"
#include "trx0sys.h"
#include "trx0trx.h"

#ifndef UNIV_HOTBACKUP

/** Checks if checkpoint should be written. Checks time elapsed since the last
checkpoint, age of the last checkpoint and if there was any extra request to
write the checkpoint (e.g. coming from log_make_latest_checkpoint()).
@return true if checkpoint should be written */
static bool log_should_checkpoint(log_t &log);

/** Considers writing next checkpoint. Checks if checkpoint should be written
(using log_should_checkpoint()) and writes the checkpoint if that's the case.
@return true if checkpoint has been written */
static bool log_consider_checkpoint(log_t &log);

/** Considers requesting page cleaners to execute sync flush.
@return true if request has been made */
static bool log_consider_sync_flush(log_t &log);

/** Makes a checkpoint. Note that this function does not flush dirty blocks
from the buffer pool. It only checks what is lsn of the oldest modification
in the buffer pool, and writes information about the lsn in log files.
@param[in,out]	log	redo log */
static void log_checkpoint(log_t &log);

/** Calculates time that elapsed since last checkpoint.
@return number of microseconds since the last checkpoint */
static uint64_t log_checkpoint_time_elapsed(const log_t &log);

/** Requests a checkpoint written for lsn greater or equal to provided one.
The log.checkpointer_mutex has to be acquired before it is called, and it
is not released within this function.
@param[in,out]	log		redo log
@param[in]	requested_lsn	provided lsn (checkpoint should be not older) */
static void log_request_checkpoint_low(log_t &log, lsn_t requested_lsn);

/** Waits for checkpoint advanced to at least that lsn.
@param[in]	log	redo log
@param[in]	lsn	lsn up to which we are waiting */
static void log_wait_for_checkpoint(const log_t &log, lsn_t lsn);

/** Requests to flush dirty pages, to advance oldest_lsn
in flush lists to provided value. Wakes up page cleaners
and waits until the flush is finished.
@param[in]	log		redo log
@param[in]	new_oldest	expected oldest_lsn */
static void log_preflush_pool_modified_pages(const log_t &log,
												lsn_t new_oldest);

/**************************************************/ /**

 @name Coordination with buffer pool and oldest_lsn

 *******************************************************/

/* @{ */

/** Calculates lsn at which we might write a next checkpoint. It does the
best effort, but possibly the maximum allowed lsn, could be even bigger.
That's because the order of dirty pages in flush lists has been relaxed,
and we don't want to spend time on traversing the whole flush lists here.

Note that some flush lists could be empty, and some additions of dirty pages
could be pending (threads have written data to the log buffer and became
scheduled out just before adding the dirty pages). That's why the calculated
value cannot be larger than the log.buf_dirty_pages_added_up_to_lsn (only up
to this lsn value we are sure, that all the dirty pages have been added).

It is guaranteed, that the returned value will not be smaller than
the log.last_checkpoint_lsn.

@return lsn for which we might write the checkpoint */
static lsn_t log_get_available_for_checkpoint_lsn(const log_t &log) {
	ut_ad(log_checkpointer_mutex_own(log));

	/* The log_buffer_dirty_pages_added_up_to_lsn() can only increase,
	and that happens only after all related dirty pages have been added
	to the flush lists.

	Hence, to avoid issues related to race conditions, we follow order:

			1. Note lsn up to which all dirty pages have already been
				added to flush lists.

			2. Check buffer pool to get LWM lsn for unflushed dirty pages
				added to flush lists.

			3. Flush lists were empty (no LWM) => use [1] as LWM.

			4. Checkpoint LSN could be min(LWM, flushed_to_disk_lsn). */

	LOG_SYNC_POINT("log_get_available_for_chkp_lsn_before_dpa");

	const lsn_t dpa_lsn = log_buffer_dirty_pages_added_up_to_lsn(log);

	ut_a(dpa_lsn >= log.last_checkpoint_lsn.load());

	LOG_SYNC_POINT("log_get_available_for_chkp_lsn_before_buf_pool");

	lsn_t lwm_lsn = buf_pool_get_oldest_modification_lwm();

	/* Empty flush list. */

	if (lwm_lsn == 0) {
		/* There are no dirty pages. We cannot return current lsn,
		because some mtr's commit could be in the middle, after
		its log records have been written to log buffer, but before
		its dirty pages have been added to flush lists. */

		lwm_lsn = dpa_lsn;

	} else {
		/* Cannot go beyound dpa_lsn.

		Note that log_closer might still not advance dpa enough,
		because it might be scheduled out. Yes, the returned lwm
		guarantees it is able to advance, but it needs to do it! */

		lwm_lsn = std::min(lwm_lsn, dpa_lsn);
	}

	/* Cannot go beyond flushed lsn.

	We cannot write checkpoint at higher lsn than lsn up to which
	redo is flushed to disk. We must not wait for log writer/flusher
	in log_checkpoint(). Therefore we need to limit lsn for checkpoint.
	That's because we would risk a deadlock otherwise - because writer
	waits for advanced checkpoint, when it detected that there is no
	free space in log files.

	However, note that the deadlock would happen only if we created
	log records without dirty pages (during page flush we anyway wait
	for redo flushed up to page's newest_modification). */

	const lsn_t flushed_lsn = log.flushed_to_disk_lsn.load();

	lsn_t lsn = std::min(lwm_lsn, flushed_lsn);

	//ib_logf(IB_LOG_LEVEL_DEBUG, "dpa_lsn:%lu, flushed_lsn:%lu", dpa_lsn, flushed_lsn);

	/* We expect in recovery that checkpoint_lsn is within data area
	of log block. In future we could get rid of this assumption, but
	we would need to ensure that recovery handles that properly.

	For that we would better refactor log0recv.cc and seperate two
	phases:
			1. Looking for the proper mtr boundary to start at (only parse).
			2. Actual parsing and applying changes. */

	if (lsn % OS_FILE_LOG_BLOCK_SIZE == 0) {
		/* Do not make checkpoints at block boundary.

		We hopefully will get rid of this exception and allow
		recovery to start at arbitrary checkpoint value. */
		lsn = lsn - OS_FILE_LOG_BLOCK_SIZE + LOG_BLOCK_HDR_SIZE;
	}

	ut_a(lsn % OS_FILE_LOG_BLOCK_SIZE >= LOG_BLOCK_HDR_SIZE);

	ut_a(lsn % OS_FILE_LOG_BLOCK_SIZE <
		OS_FILE_LOG_BLOCK_SIZE - LOG_BLOCK_TRL_SIZE);

	lsn = std::max(lsn, log.last_checkpoint_lsn.load());

	ut_a(lsn >= log.last_checkpoint_lsn.load());
	ut_a(lsn <= log.flushed_to_disk_lsn.load());

	return (lsn);
}

/** Calculates and updates lsn at which we might write a next checkpoint. */
static void log_update_available_for_checkpoint_lsn(log_t &log) {
	ut_ad(log_checkpointer_mutex_own(log));

	/* Update lsn available for checkpoint. */
	const lsn_t oldest_lsn = log_get_available_for_checkpoint_lsn(log);

	/* oldest_lsn can decrease in case previously buffer pool flush lists
	were empty and now a new dirty page appeared, which causes a maximum
	delay of log.recent_closed_size being suddenly subtracted. */

	if (oldest_lsn > log.available_for_checkpoint_lsn) {
		log.available_for_checkpoint_lsn = oldest_lsn;
	}
}

/* @} */

/**************************************************/ /**

 @name Log file headers

 *******************************************************/

/* @{ */

void log_files_header_flush(
	ulint		nth_file,	/*!< in: header to the nth file in the log file space */
	lsn_t		start_lsn)	/*!< in: log file data starts at this lsn */
{
	byte*	buf;
	lsn_t	dest_offset;

	ut_ad(!recv_no_log_write);
	ut_a(nth_file < log_sys->n_files);

	buf = *(log_sys->file_header_bufs + nth_file);

	// Code for log group is removed.
	// For redo log format compatibility, still fill in 0 as group id.
	mach_write_to_4(buf + LOG_GROUP_ID, 0);
	mach_write_to_8(buf + LOG_FILE_START_LSN, start_lsn);

	/* Wipe over possible label of mysqlbackup --restore */
	memcpy(buf + LOG_FILE_WAS_CREATED_BY_HOT_BACKUP, "    ", 4);

	dest_offset = nth_file * log_sys->file_size;

#ifdef UNIV_DEBUG
	if (log_debug_writes) {
		fprintf(stderr,
				"Writing log file header file %lu\n",
				(ulong) nth_file);
	}
#endif /* UNIV_DEBUG */
	if (log_do_write) {
		log_sys->n_log_ios++;

		MONITOR_INC(MONITOR_LOG_IO);

		srv_stats.os_log_pending_writes.inc();

		fil_io(OS_FILE_WRITE | OS_FILE_LOG, true, log_sys->space_id, 0,
				(ulint) (dest_offset / UNIV_PAGE_SIZE),
				(ulint) (dest_offset % UNIV_PAGE_SIZE),
				OS_FILE_LOG_BLOCK_SIZE,
				buf, FALSE);

		srv_stats.os_log_pending_writes.dec();
	}
}

/* @} */

/**************************************************/ /**

 @name Making checkpoints

 *******************************************************/

/* @{ */

static lsn_t log_determine_checkpoint_lsn(log_t &log) {
	const lsn_t oldest_lsn = log.available_for_checkpoint_lsn;

	return (oldest_lsn);
}

/*******************************************************************//**
// Fill the log group array in the checkpoint buf.
// Code for log group is removed.
// Keep the log group array here only for redo log compatibility.
Writes info to a checkpoint about a log group. */
static
void
log_checkpoint_set_nth_group_info(
/*==============================*/
	byte*	buf,	/*!< in: buffer for checkpoint info */
	ulint	n,	/*!< in: nth slot */
	ulint	file_no,/*!< in: archived file number */
	ulint	offset)	/*!< in: archived file offset */
{
	ut_ad(n < LOG_MAX_N_GROUPS);

	mach_write_to_4(buf + LOG_CHECKPOINT_GROUP_ARRAY
			+ 8 * n + LOG_CHECKPOINT_ARCHIVED_FILE_NO, file_no);
	mach_write_to_4(buf + LOG_CHECKPOINT_GROUP_ARRAY
			+ 8 * n + LOG_CHECKPOINT_ARCHIVED_OFFSET, offset);
}

void log_files_write_checkpoint(log_t &log, lsn_t next_checkpoint_lsn)
{
	lsn_t		lsn_offset;
	ulint		write_offset;
	ulint		fold;
	byte*		buf;
	ulint		i;

	ut_ad(!srv_read_only_mode);
#if LOG_CHECKPOINT_SIZE > OS_FILE_LOG_BLOCK_SIZE
# error "LOG_CHECKPOINT_SIZE > OS_FILE_LOG_BLOCK_SIZE"
#endif

	log_writer_mutex_enter(log);

	log.next_checkpoint_lsn = next_checkpoint_lsn;

	buf = log_sys->checkpoint_buf;

	mach_write_to_8(buf + LOG_CHECKPOINT_NO, log_sys->next_checkpoint_no);
	mach_write_to_8(buf + LOG_CHECKPOINT_LSN, log_sys->next_checkpoint_lsn);

	lsn_offset = log_files_real_offset_for_lsn(*log_sys, log_sys->next_checkpoint_lsn);
	mach_write_to_4(buf + LOG_CHECKPOINT_OFFSET_LOW32,
					lsn_offset & 0xFFFFFFFFUL);
	mach_write_to_4(buf + LOG_CHECKPOINT_OFFSET_HIGH32,
					lsn_offset >> 32);

	mach_write_to_4(buf + LOG_CHECKPOINT_LOG_BUF_SIZE, log_sys->buf_size);

	mach_write_to_8(buf + LOG_CHECKPOINT_ARCHIVED_LSN, LSN_MAX);

	for (i = 0; i < LOG_MAX_N_GROUPS; i++) {
		log_checkpoint_set_nth_group_info(buf, i, 0, 0);
	}

	fold = ut_fold_binary(buf, LOG_CHECKPOINT_CHECKSUM_1);
	mach_write_to_4(buf + LOG_CHECKPOINT_CHECKSUM_1, fold);

	fold = ut_fold_binary(buf + LOG_CHECKPOINT_LSN,
						  LOG_CHECKPOINT_CHECKSUM_2 - LOG_CHECKPOINT_LSN);
	mach_write_to_4(buf + LOG_CHECKPOINT_CHECKSUM_2, fold);

	/* We alternate the physical place of the checkpoint info in the first
	log file */

	if ((log_sys->next_checkpoint_no & 1) == 0) {
		write_offset = LOG_CHECKPOINT_1;
	} else {
		write_offset = LOG_CHECKPOINT_2;
	}

	if (log_do_write) {

		MONITOR_INC(MONITOR_PENDING_CHECKPOINT_WRITE);

		log_sys->n_log_ios++;

		MONITOR_INC(MONITOR_LOG_IO);

		/* We send as the last parameter the group machine address
		added with 1, as we want to distinguish between a normal log
		file write and a checkpoint field write */

		fil_io(OS_FILE_WRITE | OS_FILE_LOG, true, log_sys->space_id, 0,
			   write_offset / UNIV_PAGE_SIZE,
			   write_offset % UNIV_PAGE_SIZE,
			   OS_FILE_LOG_BLOCK_SIZE,
			   buf, ((byte*) TRUE));

		if (srv_unix_file_flush_method != SRV_UNIX_O_DSYNC
				&& srv_unix_file_flush_method != SRV_UNIX_NOSYNC) {

			fil_flush(log_sys->space_id);
		}
	}

	log.next_checkpoint_no.fetch_add(1);

	LOG_SYNC_POINT("log_before_checkpoint_lsn_update");

	log.last_checkpoint_lsn.store(next_checkpoint_lsn);

	LOG_SYNC_POINT("log_before_checkpoint_limits_update");

	log_update_limits(log);

	log_writer_mutex_exit(log);
}

static void log_checkpoint(log_t &log) {
	ut_ad(log_checkpointer_mutex_own(log));
	ut_a(!srv_read_only_mode);
	ut_ad(!srv_checkpoint_disabled);

	const lsn_t checkpoint_lsn = log_determine_checkpoint_lsn(log);

	LOG_SYNC_POINT("log_before_checkpoint_data_flush");

#ifdef _WIN32
	switch (srv_win_file_flush_method) {
		case SRV_WIN_IO_UNBUFFERED:
			break;
		case SRV_WIN_IO_NORMAL:
			fil_flush_file_spaces(to_int(FIL_TYPE_TABLESPACE));
			break;
	}
#else  /* !_WIN32 */
	switch (srv_unix_file_flush_method) {
		case SRV_UNIX_NOSYNC:
			break;
		case SRV_UNIX_O_DSYNC:
		/* O_SYNC is respected only for redo files and we need to
	flush data files here. For details look inside os0file.cc. */
		case SRV_UNIX_FSYNC:
		case SRV_UNIX_LITTLESYNC:
		case SRV_UNIX_O_DIRECT:
		case SRV_UNIX_O_DIRECT_NO_FSYNC:
			fil_flush_file_spaces(FIL_TABLESPACE);
	}
#endif /* _WIN32 */

	if (log_test != nullptr) {
		log_test->fsync_written_pages();
	}

	ut_a(checkpoint_lsn >= log.last_checkpoint_lsn.load());

	ut_a(checkpoint_lsn <= log_buffer_dirty_pages_added_up_to_lsn(log));

#ifdef UNIV_DEBUG
	if (checkpoint_lsn > log.flushed_to_disk_lsn.load()) {
		/* We need log_flusher, because we need redo flushed up
		to the oldest_lsn, and it's not been flushed yet. */

		log_background_threads_active_validate(log);
	}
#endif

	ut_a(log.flushed_to_disk_lsn.load() >= checkpoint_lsn);

	const auto current_time = std::chrono::high_resolution_clock::now();

	log.last_checkpoint_time = current_time;

	DBUG_PRINT("ib_log", ("Starting checkpoint at " LSN_PF, checkpoint_lsn));

	log_files_write_checkpoint(log, checkpoint_lsn);
	
	ib_logf(IB_LOG_LEVEL_DEBUG, "make checkpoint at lsn:%lu", checkpoint_lsn);

	DBUG_PRINT("ib_log",
			   ("checkpoint ended at " LSN_PF ", log flushed to " LSN_PF,
				log.last_checkpoint_lsn.load(), log.flushed_to_disk_lsn.load()));

	MONITOR_INC(MONITOR_LOG_CHECKPOINTS);

	DBUG_EXECUTE_IF("crash_after_checkpoint", DBUG_SUICIDE(););
}

static void log_request_checkpoint_low(log_t &log, lsn_t requested_lsn) {
	ut_a(requested_lsn < LSN_MAX);
	ut_ad(log_checkpointer_mutex_own(log));

#ifdef UNIV_DEBUG
	if (srv_checkpoint_disabled) {
		/* Checkpoints are disabled. Pretend it succeeded. */
		//ib::info(ER_IB_MSG_1233) << "Checkpoint explicitly disabled!";
        ib_logf(IB_LOG_LEVEL_INFO, "Checkpoint explicitly disabled!");
		return;
	}
#endif /* UNIV_DEBUG */

	ut_a(requested_lsn % OS_FILE_LOG_BLOCK_SIZE >= LOG_BLOCK_HDR_SIZE);

	ut_a(requested_lsn % OS_FILE_LOG_BLOCK_SIZE <
		 OS_FILE_LOG_BLOCK_SIZE - LOG_BLOCK_TRL_SIZE);

	requested_lsn = std::max(requested_lsn, log.last_checkpoint_lsn.load());

	/* Update log.requested_checkpoint_lsn only to greater value. */

	if (requested_lsn > log.requested_checkpoint_lsn) {
		log.requested_checkpoint_lsn = requested_lsn;

		os_event_set(log.checkpointer_event);
	}
}

static void log_wait_for_checkpoint(const log_t &log, lsn_t requested_lsn) {
	log_background_threads_active_validate(log);

	auto stop_condition = [&log, requested_lsn](bool) {

		/* We need to wake up page cleaners, as we could have
		dirty page that stops checkpoint from advancing. */

		log_preflush_pool_modified_pages(log, requested_lsn);

		return (log.last_checkpoint_lsn.load() >= requested_lsn);
	};

	ut_wait_for(0, 100, stop_condition);
}

void log_request_checkpoint(log_t &log, bool sync, lsn_t lsn) {
	log_preflush_pool_modified_pages(log, lsn);

	log_checkpointer_mutex_enter(log);

	log_request_checkpoint_low(log, lsn);

	log_checkpointer_mutex_exit(log);

	if (sync) {
		log_wait_for_checkpoint(log, lsn);
	}
}

void log_request_checkpoint(log_t &log, bool sync) {
	log_checkpointer_mutex_enter(log);

	log_update_available_for_checkpoint_lsn(log);

	const lsn_t lsn = log.available_for_checkpoint_lsn;

	log_request_checkpoint_low(log, lsn);

	log_checkpointer_mutex_exit(log);

	if (sync) {
		log_wait_for_checkpoint(log, lsn);
	}
}

bool log_make_latest_checkpoint(log_t &log) {
	const lsn_t lsn = log_get_lsn(log);

	log_preflush_pool_modified_pages(log, lsn);

	log_checkpointer_mutex_enter(log);

	if (lsn <= log.last_checkpoint_lsn.load()) {
		log_checkpointer_mutex_exit(log);
		return (false);
	}

	log_request_checkpoint_low(log, lsn);

	log_checkpointer_mutex_exit(log);

	log_wait_for_checkpoint(log, lsn);

	return (true);
}

bool log_make_latest_checkpoint() {
	return (log_make_latest_checkpoint(*log_sys));
}

bool log_make_checkpoint_at(log_t &log, lsn_t lsn) {
	const lsn_t current_lsn = log_get_lsn(log);
	if (current_lsn >= lsn) {
		return (true);
	}

	log_preflush_pool_modified_pages(log, lsn);

	log_checkpointer_mutex_enter(log);

	if (lsn <= log.last_checkpoint_lsn.load()) {
		log_checkpointer_mutex_exit(log);
		return (false);
	}

	log_request_checkpoint_low(log, lsn);

	log_checkpointer_mutex_exit(log);

	log_wait_for_checkpoint(log, lsn);

	return (true);
}

bool log_make_checkpoint_at(lsn_t lsn) {
	return (log_make_checkpoint_at(*log_sys, lsn));
}

static void log_preflush_pool_modified_pages(const log_t &log,
		lsn_t new_oldest) {
	/* A flush is urgent: we have to do a synchronous flush,
	because the oldest dirty page is too old.

	Note, that this could fire even if we did not run out
	of space in log files (users still may write to redo). */

	if (new_oldest == LSN_MAX
			/* Forced flush request is processed by page_cleaner, if
			it's not active, then we must do flush ourselves. */
			|| !buf_page_cleaner_is_active
			/* Reason unknown. */
			|| srv_is_being_started) {
		buf_flush_sync_all_buf_pools();

	} else {
		new_oldest += log_buffer_flush_order_lag(log);

		/* better to wait for being flushed by page cleaner */
		if (srv_flush_sync) {
			/* wake page cleaner for IO burst */
			buf_flush_request_force(new_oldest);
		}

		buf_flush_wait_flushed(new_oldest);
	}
}

static bool log_consider_sync_flush(log_t &log) {
	ut_ad(log_checkpointer_mutex_own(log));

	const lsn_t oldest_lsn = log.available_for_checkpoint_lsn;

	lsn_t current_lsn = log_get_lsn(log);

	lsn_t flush_up_to = oldest_lsn;

	ut_a(oldest_lsn <= current_lsn);

	if (current_lsn == oldest_lsn) {
		return (false);
	}

	const sn_t margin = log_free_check_margin(log);

	current_lsn =
		log_translate_sn_to_lsn(log_translate_lsn_to_sn(current_lsn) + margin);

	if (current_lsn - oldest_lsn > log.max_modified_age_sync) {
		ut_a(current_lsn > log.max_modified_age_sync);

		flush_up_to = current_lsn - log.max_modified_age_sync;
	}

	const lsn_t requested_checkpoint_lsn = log.requested_checkpoint_lsn;

	if (requested_checkpoint_lsn > flush_up_to) {
		flush_up_to = requested_checkpoint_lsn;
	}

	if (flush_up_to > oldest_lsn) {
		log_checkpointer_mutex_exit(log);

		ib_logf(IB_LOG_LEVEL_DEBUG, "flush_up_to:%lu, oldest_lsn:%lu, "
				"checkpointer thread has to preflush pages", flush_up_to, oldest_lsn);

		log_preflush_pool_modified_pages(log, flush_up_to);

		log_checkpointer_mutex_enter(log);

		/* It's very probable that forced flush will result in maximum
		lsn available for creating a new checkpoint, just try to update
		it to not wait for next checkpointer loop. */
		log_update_available_for_checkpoint_lsn(log);

		return (true);
	}

	return (false);
}

static uint64_t log_checkpoint_time_elapsed(const log_t &log) {
	ut_ad(log_checkpointer_mutex_own(log));

	const auto current_time = std::chrono::high_resolution_clock::now();

	const auto checkpoint_time = log.last_checkpoint_time;

	if (current_time < log.last_checkpoint_time) {
		return (0);
	}

	return (std::chrono::duration_cast<std::chrono::microseconds>(current_time -
																	checkpoint_time)
				.count());
}

static bool log_should_checkpoint(log_t &log) {
	lsn_t last_checkpoint_lsn;
	lsn_t oldest_lsn;
	lsn_t current_lsn;
	lsn_t requested_checkpoint_lsn;
	uint64_t checkpoint_age;
	uint64_t checkpoint_time_elapsed;

	ut_ad(log_checkpointer_mutex_own(log));

#ifdef UNIV_DEBUG
	if (srv_checkpoint_disabled) {
		return (false);
	}
#endif /* UNIV_DEBUG */

	last_checkpoint_lsn = log.last_checkpoint_lsn.load();

	oldest_lsn = log.available_for_checkpoint_lsn;

	if (oldest_lsn <= last_checkpoint_lsn) {
		return (false);
	}

	requested_checkpoint_lsn = log.requested_checkpoint_lsn;

	current_lsn = log_get_lsn(log);

	ut_a(last_checkpoint_lsn <= oldest_lsn);
	ut_a(oldest_lsn <= current_lsn);

	const sn_t margin = log_free_check_margin(log);

	current_lsn =
		log_translate_sn_to_lsn(log_translate_lsn_to_sn(current_lsn) + margin);

	checkpoint_age = current_lsn - last_checkpoint_lsn;

	checkpoint_time_elapsed = log_checkpoint_time_elapsed(log);

	/* Update checkpoint_lsn stored in header of log files if:
			a) more than 1s elapsed since last checkpoint
			b) checkpoint age is greater than max_checkpoint_age_async
			c) it was requested to have greater checkpoint_lsn,
			   and oldest_lsn allows to satisfy the request */

	bool periodical_checkpoint_disabled = false;

	DBUG_EXECUTE_IF("periodical_checkpoint_disabled",
					periodical_checkpoint_disabled = true;);

	if ((log.periodical_checkpoints_enabled && !periodical_checkpoint_disabled &&
			checkpoint_time_elapsed >= srv_log_checkpoint_every * 1000ULL) ||
			checkpoint_age >= log.max_checkpoint_age_async ||
			(requested_checkpoint_lsn > last_checkpoint_lsn &&
			 requested_checkpoint_lsn <= oldest_lsn)) {
		return (true);
	}

	return (false);
}

static bool log_consider_checkpoint(log_t &log) {
	ut_ad(log_checkpointer_mutex_own(log));

	if (!log_should_checkpoint(log)) {
		return (false);
	}

	log_checkpoint(log);
	return (true);
}

extern "C" UNIV_INTERN
os_thread_ret_t
DECLARE_THREAD(log_checkpointer)(
/*==============================*/
	void*	arg __attribute__((unused)))
{
	log_t* log_ptr = (log_t*)arg;
	ut_a(log_ptr != nullptr);
	ut_a(log_ptr->checkpointer_thread_alive.load());

	log_t &log = *log_ptr;

	log_checkpointer_mutex_enter(log);

	while (true) {
		auto do_some_work = [&log] {

			ut_ad(log_checkpointer_mutex_own(log));

			/* We will base our next decisions on maximum lsn
			available for creating a new checkpoint. It would
			be great to have it updated beforehand. Also, this
			is the only thread that relies on that value, so we
			don't need to update it in other threads. */
			log_update_available_for_checkpoint_lsn(log);

			/* Consider flushing some dirty pages. */
			const bool sync_flushed = log_consider_sync_flush(log);

			LOG_SYNC_POINT("log_checkpointer_before_consider_checkpoint");

			/* Consider writing checkpoint. */
			const bool checkpointed = log_consider_checkpoint(log);

			if (sync_flushed || checkpointed) {
				return (true);
			}

			return (false);
		};

		const auto sig_count = os_event_reset(log.checkpointer_event);

		if (!do_some_work()) {
			log_checkpointer_mutex_exit(log);

			os_event_wait_time_low(log.checkpointer_event, 10 * 1000, sig_count);

			log_checkpointer_mutex_enter(log);

		} else {
			log_checkpointer_mutex_exit(log);

			os_thread_sleep(0);

			log_checkpointer_mutex_enter(log);
		}

		/* Check if we should close the thread. */
		if (log.should_stop_threads.load() && !log.closer_thread_alive.load()) {
			break;
		}
	}

	log.checkpointer_thread_alive.store(false);

	log_checkpointer_mutex_exit(log);

	os_thread_exit(NULL);

	OS_THREAD_DUMMY_RETURN;
}

/* @} */

/**************************************************/ /**

 @name Margin calculations

 *******************************************************/

/* @{ */

static bool log_calc_concurrency_margin(log_t &log) {
	ut_ad(log_writer_mutex_own(log));

	uint64_t concurrency_margin;

	/* Single thread, which keeps latches of dirty pages, that block
	the checkpoint to advance, will have to finish writes to redo.
	It won't write more than LOG_CHECKPOINT_FREE_PER_THREAD, before
	it checks, if it should wait for the checkpoint (log_free_check()). */
	concurrency_margin = LOG_CHECKPOINT_FREE_PER_THREAD * UNIV_PAGE_SIZE;

	/* We will have at most that many threads, that need to release
	the latches. Note, that each thread will notice, that checkpoint
	is required and will wait until it's done in log_free_check(). */
	concurrency_margin *= 10 + srv_thread_concurrency;

	/* Add constant extra safety */
	concurrency_margin += LOG_CHECKPOINT_EXTRA_FREE * UNIV_PAGE_SIZE;

	/* Add extra safety calculated from redo-size. It is 5% of 90%
	of the real capacity (lsn_capacity is 90% of the real capacity). */
	concurrency_margin += ut_uint64_align_down(
		static_cast<uint64_t>(0.05 * log.lsn_capacity_for_writer),
		OS_FILE_LOG_BLOCK_SIZE);

	bool success = false;
	if (concurrency_margin > log.max_concurrency_margin) {
		concurrency_margin = log.max_concurrency_margin;
		success = false;
	} else {
		success = true;
	}

	MONITOR_SET(MONITOR_LOG_CONCURRENCY_MARGIN, concurrency_margin);
	log.concurrency_margin.store(concurrency_margin);
	return success;
}

void log_update_limits(log_t &log) {
	const sn_t sn_file_limit = log_translate_lsn_to_sn(
						log.last_checkpoint_lsn.load() + log.lsn_capacity_for_free_check);

	LOG_SYNC_POINT("log_update_limits_middle_1");

	const lsn_t write_lsn = log.write_lsn.load();

	LOG_SYNC_POINT("log_update_limits_middle_2");

	const sn_t limit_for_end = log_translate_lsn_to_sn(write_lsn) +
												log.buf_size_sn.load() -
												2 * OS_FILE_LOG_BLOCK_SIZE;

	log.sn_limit_for_end.store(limit_for_end);

	LOG_SYNC_POINT("log_update_limits_middle_3");

	sn_t limit_for_start = std::min(sn_file_limit, limit_for_end);

	const sn_t margins = log_free_check_margin(log);

	if (margins >= limit_for_start) {
		limit_for_start = 0;
	} else {
		limit_for_start -= margins;
	}

	log.sn_limit_for_start.store(limit_for_start);
}

bool log_calc_max_ages(log_t &log) {
	ut_ad(log_writer_mutex_own(log));

	log.lsn_real_capacity =
		log.files_real_capacity - LOG_FILE_HDR_SIZE * log.n_files;

	/* Add safety margin, disallowed to be used (never, ever). */
	const lsn_t safety_margin =
		std::min(static_cast<lsn_t>(0.1 * log.lsn_real_capacity),
			static_cast<lsn_t>(256 * LOG_CHECKPOINT_FREE_PER_THREAD *
			UNIV_PAGE_SIZE));

	ut_a(log.lsn_real_capacity > safety_margin + OS_FILE_LOG_BLOCK_SIZE * 8);

	log.lsn_capacity_for_writer = ut_uint64_align_down(
		log.lsn_real_capacity - safety_margin, OS_FILE_LOG_BLOCK_SIZE);

	/* Extra margin used for emergency increase of the concurrency_margin. */
	log.extra_margin = ut_uint64_align_down(
		static_cast<lsn_t>(log.lsn_capacity_for_writer * 0.05),
		OS_FILE_LOG_BLOCK_SIZE);

	/* Users stop in log-free-check call before they enter the extra_margin,
	the log_writer can still go forward through the extra_margin, triggering
	the emergency increase of concurrency_margin mean while. */
	log.lsn_capacity_for_free_check =
		log.lsn_capacity_for_writer - log.extra_margin;

	log.max_concurrency_margin = ut_uint64_align_up(
												log.lsn_capacity_for_writer / 2, OS_FILE_LOG_BLOCK_SIZE);

	const bool success = log_calc_concurrency_margin(log);

	log.concurrency_margin_ok = true;

	/* Set limits used in flushing and checkpointing mechanism. */

	const lsn_t limit = log.lsn_capacity_for_free_check;

	log.max_modified_age_sync = limit - limit / LOG_POOL_PREFLUSH_RATIO_SYNC;

	log.max_modified_age_async = limit - limit / LOG_POOL_PREFLUSH_RATIO_ASYNC;

	log.max_checkpoint_age_async =
		limit - limit / LOG_POOL_CHECKPOINT_RATIO_ASYNC;

	return (success);
}

void log_increase_concurrency_margin(log_t &log) {
	/* Increase margin by 20% but do not exceed maximum allowed size. */
	const auto new_size =
				std::min(log.max_concurrency_margin,
							ut_uint64_align_up(
							static_cast<lsn_t>(log.concurrency_margin.load() * 1.2),
							OS_FILE_LOG_BLOCK_SIZE));

	log.concurrency_margin.store(new_size);

	MONITOR_SET(MONITOR_LOG_CONCURRENCY_MARGIN, new_size);
}

  /* @} */

#endif /* !UNIV_HOTBACKUP */
