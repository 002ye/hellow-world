/*****************************************************************************

Copyright (c) 1995, 2014, Oracle and/or its affiliates. All Rights Reserved.
Copyright (c) 2009, Google Inc.

Portions of this file contain modifications contributed and copyrighted by
Google, Inc. Those modifications are gratefully acknowledged and are described
briefly in the InnoDB documentation. The contributions by Google are
incorporated with their permission, and subject to the conditions contained in
the file COPYING.Google.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Suite 500, Boston, MA 02110-1335 USA

*****************************************************************************/

/**************************************************//**
@file log/log0log.cc
Database log

Created 12/9/1995 Heikki Tuuri
*******************************************************/

#include <cstring>
#include "log0log.h"

#ifdef UNIV_NONINL
#include "log0log.ic"
#endif

#ifndef UNIV_HOTBACKUP
#include "mem0mem.h"
#include "buf0buf.h"
#include "buf0flu.h"
#include "srv0srv.h"
#include "log0recv.h"
#include "fil0fil.h"
#include "dict0boot.h"
#include "srv0srv.h"
#include "srv0start.h"
#include "trx0sys.h"
#include "trx0trx.h"
#include "trx0roll.h"
#include "srv0mon.h"

/*
General philosophy of InnoDB redo-logs:

1) Every change to a contents of a data page must be done
through mtr, which in mtr_commit() writes log records
to the InnoDB redo log.

2) Normally these changes are performed using a mlog_write_ulint()
or similar function.

3) In some page level operations only a code number of a
c-function and its parameters are written to the log to
reduce the size of the log.

  3a) You should not add parameters to these kind of functions
  (e.g. trx_undo_header_create(), trx_undo_insert_header_reuse())

  3b) You should not add such functionality which either change
  working when compared with the old or are dependent on data
  outside of the page. These kind of functions should implement
  self-contained page transformation and it should be unchanged
  if you don't have very essential reasons to change log
  semantics or format.

*/

/* Global log system variable */
UNIV_INTERN log_t*	log_sys	= NULL;

#ifdef UNIV_PFS_RWLOCK
UNIV_INTERN mysql_pfs_key_t	checkpoint_lock_key;
#endif /* UNIV_PFS_RWLOCK */

#ifdef UNIV_DEBUG
UNIV_INTERN ibool	log_do_write = TRUE;
#endif /* UNIV_DEBUG */

/* These control how often we print warnings if the last checkpoint is too
old */
UNIV_INTERN ibool	log_has_printed_chkp_warning = FALSE;
UNIV_INTERN time_t	log_last_warning_time;

/* A margin for free space in the log buffer before a log entry is catenated */
#define LOG_BUF_WRITE_MARGIN	(4 * OS_FILE_LOG_BLOCK_SIZE)

/* This parameter controls asynchronous making of a new checkpoint; the value
should be bigger than LOG_POOL_PREFLUSH_RATIO_SYNC */

#define LOG_POOL_CHECKPOINT_RATIO_ASYNC	32

/* This parameter controls synchronous preflushing of modified buffer pages */
#define LOG_POOL_PREFLUSH_RATIO_SYNC	16

/* The same ratio for asynchronous preflushing; this value should be less than
the previous */
#define LOG_POOL_PREFLUSH_RATIO_ASYNC	8

/* Extra margin, in addition to one log file, used in archiving */
#define LOG_ARCHIVE_EXTRA_MARGIN	(4 * UNIV_PAGE_SIZE)

/* This parameter controls asynchronous writing to the archive */
#define LOG_ARCHIVE_RATIO_ASYNC		16

/* Codes used in unlocking flush latches */
#define LOG_UNLOCK_NONE_FLUSHED_LOCK	1
#define LOG_UNLOCK_FLUSH_LOCK		2

/* States of an archiving operation */
#define	LOG_ARCHIVE_READ	1
#define	LOG_ARCHIVE_WRITE	2

/* @} */

/**************************************************/ /**

 @name	Allocation / deallocation of buffers

 *******************************************************/

/* @{ */

static void log_allocate_buffer(log_t &log) {
	ut_a(srv_log_buffer_size * UNIV_PAGE_SIZE >= INNODB_LOG_BUFFER_SIZE_MIN);
	ut_a(srv_log_buffer_size * UNIV_PAGE_SIZE <= INNODB_LOG_BUFFER_SIZE_MAX);
	ut_a(srv_log_buffer_size * UNIV_PAGE_SIZE >= 4 * UNIV_PAGE_SIZE);

	log.buf.create(srv_log_buffer_size * UNIV_PAGE_SIZE);
}

static void log_deallocate_buffer(log_t &log) { log.buf.destroy(); }

static void log_allocate_write_ahead_buffer(log_t &log) {
	ut_a(srv_log_write_ahead_size >= INNODB_LOG_WRITE_AHEAD_SIZE_MIN);
	ut_a(srv_log_write_ahead_size <= INNODB_LOG_WRITE_AHEAD_SIZE_MAX);

	log.write_ahead_buf_size = srv_log_write_ahead_size;
	log.write_ahead_buf.create(log.write_ahead_buf_size);
}

static void log_deallocate_write_ahead_buffer(log_t &log) {
	log.write_ahead_buf.destroy();
}

static void log_allocate_checkpoint_buffer(log_t &log) {
	log.checkpoint_buf.create(2 * UNIV_PAGE_SIZE);
}

static void log_deallocate_checkpoint_buffer(log_t &log) {
	log.checkpoint_buf.destroy();
}

static void log_allocate_recent_written(log_t &log) {
	log.recent_written = Link_buf<lsn_t>{srv_log_recent_written_size};
}
static void log_deallocate_recent_written(log_t &log) {
	log.recent_written.validate_no_links();
	log.recent_written = {};
}

static void log_allocate_recent_closed(log_t &log) {
	log.recent_closed = Link_buf<lsn_t>{srv_log_recent_closed_size};
}

static void log_deallocate_recent_closed(log_t &log) {
	log.recent_closed.validate_no_links();
	log.recent_closed = {};
}

static void log_allocate_flush_events(log_t &log) {
	const size_t n = srv_log_flush_events;

	ut_a(log.flush_events == nullptr);
	ut_a(n >= 1);
	ut_a((n & (n - 1)) == 0);

	log.flush_events_size = n;
	log.flush_events = UT_NEW_ARRAY_NOKEY(os_event_t, n);

	for (size_t i = 0; i < log.flush_events_size; ++i) {
		log.flush_events[i] = os_event_create();
	}
}

static void log_deallocate_flush_events(log_t &log) {
	ut_a(log.flush_events != nullptr);

	for (size_t i = 0; i < log.flush_events_size; ++i) {
		os_event_free(log.flush_events[i]);
	}

	UT_DELETE_ARRAY(log.flush_events);
	log.flush_events = nullptr;
}

static void log_allocate_write_events(log_t &log) {
	const size_t n = srv_log_write_events;

	ut_a(log.write_events == nullptr);
	ut_a(n >= 1);
	ut_a((n & (n - 1)) == 0);

	log.write_events_size = n;
	log.write_events = UT_NEW_ARRAY_NOKEY(os_event_t, n);

	for (size_t i = 0; i < log.write_events_size; ++i) {
		log.write_events[i] = os_event_create();
	}
}

static void log_deallocate_write_events(log_t &log) {
	ut_a(log.write_events != nullptr);

	for (size_t i = 0; i < log.write_events_size; ++i) {
		os_event_free(log.write_events[i]);
	}

	UT_DELETE_ARRAY(log.write_events);
	log.write_events = nullptr;
}

static void log_allocate_file_header_buffers(log_t &log) {
	const uint32_t n_files = log.n_files;

	using Buf_ptr = aligned_array_pointer<byte, OS_FILE_LOG_BLOCK_SIZE>;

	log.file_header_bufs = UT_NEW_ARRAY_NOKEY(Buf_ptr, n_files);

	for (uint32_t i = 0; i < n_files; i++) {
		log.file_header_bufs[i].create(LOG_FILE_HDR_SIZE);
	}
}

static void log_deallocate_file_header_buffers(log_t &log) {
	ut_a(log.n_files > 0);
	ut_a(log.file_header_bufs != nullptr);

	UT_DELETE_ARRAY(log.file_header_bufs);
	log.file_header_bufs = nullptr;
}

bool log_buffer_resize(log_t &log, size_t new_size) {
	log_buffer_x_lock_enter(log);

	const lsn_t end_lsn = log_get_lsn(log);

	log_checkpointer_mutex_enter(log);
	log_writer_mutex_enter(log);

	const bool ret = log_buffer_resize_low(log, new_size, end_lsn);

	log_writer_mutex_exit(log);
	log_checkpointer_mutex_exit(log);
	log_buffer_x_lock_exit(log);

	return (ret);
}

void log_write_ahead_resize(log_t &log, size_t new_size) {
	ut_a(new_size >= INNODB_LOG_WRITE_AHEAD_SIZE_MIN);
	ut_a(new_size <= INNODB_LOG_WRITE_AHEAD_SIZE_MAX);

	log_writer_mutex_enter(log);

	log_deallocate_write_ahead_buffer(log);
	srv_log_write_ahead_size = static_cast<ulong>(new_size);

	log.write_ahead_end_offset =
		ut_uint64_align_down(log.write_ahead_end_offset, new_size);

	log_allocate_write_ahead_buffer(log);

	log_writer_mutex_exit(log);
}

static void log_calc_buf_size(log_t &log) {
	ut_a(srv_log_buffer_size * UNIV_PAGE_SIZE >= INNODB_LOG_BUFFER_SIZE_MIN);
	ut_a(srv_log_buffer_size * UNIV_PAGE_SIZE <= INNODB_LOG_BUFFER_SIZE_MAX);

	log.buf_size = srv_log_buffer_size * UNIV_PAGE_SIZE;

	/* The following update has to be the last operation during resize
	procedure of log buffer. That's because since this moment, possibly
	new concurrent writes for higher sn will start (which were waiting
	for free space in the log buffer). */

	log.buf_size_sn = log_translate_lsn_to_sn(log.buf_size);

	log_update_limits(log);
}

#endif /* !UNIV_HOTBACKUP */

#ifdef UNIV_DEBUG
UNIV_INTERN ibool	log_debug_writes = FALSE;
#endif /* UNIV_DEBUG */

#ifndef UNIV_HOTBACKUP
/******************************************************//**
Initializes the log. */
UNIV_INTERN
void
log_sys_init(
/*===========*/
	ulint	n_files,		/*!< in: number of log files */
	lsn_t	file_size,		/*!< in: log file size in bytes */
	ulint	space_id)		/*!< in: space id of the file space
					which contains the log files */
{
	ut_a(log_sys == nullptr);

	log_sys = static_cast<log_t*>(mem_zalloc(sizeof(log_t)));

	ut_a(LOG_BUFFER_SIZE >= 16 * OS_FILE_LOG_BLOCK_SIZE);
	ut_a(LOG_BUFFER_SIZE >= 4 * UNIV_PAGE_SIZE);

	if (log_test != nullptr) {
		log_sys->periodical_checkpoints_enabled = false;
	} else {
		log_sys->periodical_checkpoints_enabled = true;
	}

	log_sys->current_file_lsn = LOG_START_LSN;
	log_sys->current_file_real_offset = LOG_FILE_HDR_SIZE;

	log_sys->checkpointer_event = os_event_create();
	log_sys->write_notifier_event = os_event_create();
	log_sys->flush_notifier_event = os_event_create();
	log_sys->writer_event = os_event_create();
	log_sys->flusher_event = os_event_create();

	mutex_create(PFS_NOT_INSTRUMENTED, &log_sys->checkpointer_mutex, SYNC_LOG_CHECKPOINTER);
	mutex_create(PFS_NOT_INSTRUMENTED, &log_sys->closer_mutex, SYNC_LOG_CLOSER);
	mutex_create(PFS_NOT_INSTRUMENTED, &log_sys->writer_mutex, SYNC_LOG_WRITER);
	mutex_create(PFS_NOT_INSTRUMENTED, &log_sys->flusher_mutex, SYNC_LOG_FLUSHER);
	mutex_create(PFS_NOT_INSTRUMENTED, &log_sys->write_notifier_mutex, SYNC_LOG_WRITE_NOTIFIER);
	mutex_create(PFS_NOT_INSTRUMENTED, &log_sys->flush_notifier_mutex, SYNC_LOG_FLUSH_NOTIFIER);

	log_sys->sn_lock.create(0, SYNC_LOG_SN, 64);

	/* Allocate buffers. */
	log_allocate_buffer(*log_sys);
	log_allocate_write_ahead_buffer(*log_sys);
	log_allocate_checkpoint_buffer(*log_sys);
	log_allocate_recent_written(*log_sys);
	log_allocate_recent_closed(*log_sys);
	log_allocate_flush_events(*log_sys);
	log_allocate_write_events(*log_sys);

	log_calc_buf_size(*log_sys);

	log_sys->n_log_ios = 0;

	log_sys->n_log_ios_old = log_sys->n_log_ios;
	log_sys->last_printout_time = time(NULL);

	log_sys->write_lsn.store(0);
	log_sys->flushed_to_disk_lsn.store(0);

	ut_a(file_size <= std::numeric_limits<uint64_t>::max() / n_files);
	log_sys->n_files = n_files;
	log_sys->file_size = file_size;
	log_sys->files_real_capacity = file_size * n_files;
	log_sys->space_id = space_id;
	log_sys->state = LOG_OK;

	log_files_update_offsets(*log_sys, log_sys->current_file_lsn);

	log_allocate_file_header_buffers(*log_sys);

	ut_a(log_calc_max_ages(*log_sys));

#ifdef UNIV_LOG_DEBUG
	recv_sys_create();
	recv_sys_init(buf_pool_get_curr_size());

	recv_sys->scanned_checkpoint_no = 0;
	recv_sys->limit_lsn = LSN_MAX;
#endif
}

/****************************************************************//**
write to the log file up to the last log entry.
@param[in]	sync	whether we want the written log
also to be flushed to disk. */
UNIV_INTERN
void
log_buffer_flush_to_disk(
	bool sync)
/*==========================*/
{
	ut_ad(!srv_read_only_mode);
	ut_a(!recv_recovery_is_on());

	const lsn_t lsn = log_get_lsn(*log_sys);

	log_write_up_to(*log_sys, lsn, sync);
}

#endif /* !UNIV_HOTBACKUP */

#ifdef UNIV_HOTBACKUP
/******************************************************//**
Writes info to a buffer when log files are created in
backup restoration. */
UNIV_INTERN
void
log_reset_first_header_and_checkpoint(
/*==================================*/
	byte*		hdr_buf,/*!< in: buffer which will be written to the
				start of the first log file */
	ib_uint64_t	start)	/*!< in: lsn of the start of the first log file;
				we pretend that there is a checkpoint at
				start + LOG_BLOCK_HDR_SIZE */
{
	ulint		fold;
	byte*		buf;
	ib_uint64_t	lsn;

	mach_write_to_4(hdr_buf + LOG_GROUP_ID, 0);
	mach_write_to_8(hdr_buf + LOG_FILE_START_LSN, start);

	lsn = start + LOG_BLOCK_HDR_SIZE;

	/* Write the label of mysqlbackup --restore */
	strcpy((char*) hdr_buf + LOG_FILE_WAS_CREATED_BY_HOT_BACKUP,
	       "ibbackup ");
	ut_sprintf_timestamp((char*) hdr_buf
			     + (LOG_FILE_WAS_CREATED_BY_HOT_BACKUP
				+ (sizeof "ibbackup ") - 1));
	buf = hdr_buf + LOG_CHECKPOINT_1;

	mach_write_to_8(buf + LOG_CHECKPOINT_NO, 0);
	mach_write_to_8(buf + LOG_CHECKPOINT_LSN, lsn);

	mach_write_to_4(buf + LOG_CHECKPOINT_OFFSET_LOW32,
			LOG_FILE_HDR_SIZE + LOG_BLOCK_HDR_SIZE);
	mach_write_to_4(buf + LOG_CHECKPOINT_OFFSET_HIGH32, 0);

	mach_write_to_4(buf + LOG_CHECKPOINT_LOG_BUF_SIZE, 2 * 1024 * 1024);

	mach_write_to_8(buf + LOG_CHECKPOINT_ARCHIVED_LSN, LSN_MAX);

	fold = ut_fold_binary(buf, LOG_CHECKPOINT_CHECKSUM_1);
	mach_write_to_4(buf + LOG_CHECKPOINT_CHECKSUM_1, fold);

	fold = ut_fold_binary(buf + LOG_CHECKPOINT_LSN,
			      LOG_CHECKPOINT_CHECKSUM_2 - LOG_CHECKPOINT_LSN);
	mach_write_to_4(buf + LOG_CHECKPOINT_CHECKSUM_2, fold);

	/* Starting from InnoDB-3.23.50, we should also write info on
	allocated size in the tablespace, but unfortunately we do not
	know it here */
}
#endif /* UNIV_HOTBACKUP */

#ifndef UNIV_HOTBACKUP
/******************************************************//**
Reads a checkpoint info from a log header to log_sys->checkpoint_buf. */
UNIV_INTERN
void
log_read_checkpoint_info(
/*===========================*/
	ulint		field)	/*!< in: LOG_CHECKPOINT_1 or LOG_CHECKPOINT_2 */
{
	log_sys->n_log_ios++;

	MONITOR_INC(MONITOR_LOG_IO);

	fil_io(OS_FILE_READ | OS_FILE_LOG, true, log_sys->space_id, 0,
			field / UNIV_PAGE_SIZE, field % UNIV_PAGE_SIZE,
			OS_FILE_LOG_BLOCK_SIZE, log_sys->checkpoint_buf, NULL);
}

/****************************************************************//**
Makes a checkpoint at the latest lsn and writes it to first page of each
data file in the database, so that we know that the file spaces contain
all modifications up to that lsn. This can only be called at database
shutdown. This function also writes all log in log files to the log archive. */
UNIV_INTERN
void
logs_empty_and_mark_files_at_shutdown(void)
/*=======================================*/
{
	lsn_t			lsn;
	ulint			count = 0;
	ulint			total_trx;
	ulint			pending_io;
	enum srv_thread_type	active_thd;
	const char*		thread_name;

	ib_logf(IB_LOG_LEVEL_INFO, "Starting shutdown...");

	while (srv_fast_shutdown == 0 && trx_rollback_or_clean_is_active) {
		/* we should wait until rollback after recovery end
		for slow shutdown */
		os_thread_sleep(100000);
	}

	/* Wait until the master thread and all other operations are idle: our
	algorithm only works if the server is idle at shutdown */

	srv_shutdown_state = SRV_SHUTDOWN_CLEANUP;
loop:
	os_thread_sleep(100000);

	count++;

	/* We need the monitor threads to stop before we proceed with
	a shutdown. */

	thread_name = srv_any_background_threads_are_active();

	if (thread_name != NULL) {
		/* Print a message every 60 seconds if we are waiting
		for the monitor thread to exit. Master and worker
		threads check will be done later. */

		if (srv_print_verbose_log && count > 600) {
			ib_logf(IB_LOG_LEVEL_INFO,
				"Waiting for %s to exit", thread_name);
			count = 0;
		}

		goto loop;
	}

	/* Check that there are no longer transactions, except for
	PREPARED ones. We need this wait even for the 'very fast'
	shutdown, because the InnoDB layer may have committed or
	prepared transactions and we don't want to lose them. */

	total_trx = trx_sys_any_active_transactions();

	if (total_trx > 0) {

		if (srv_print_verbose_log && count > 600) {
			ib_logf(IB_LOG_LEVEL_INFO,
				"Waiting for %lu active transactions to finish",
				(ulong) total_trx);

			count = 0;
		}

		goto loop;
	}

	/* Check that the background threads are suspended */

	active_thd = srv_get_active_thread_type();

	if (active_thd != SRV_NONE) {

		if (active_thd == SRV_PURGE) {
			srv_purge_wakeup();
		}

		/* The srv_lock_timeout_thread, srv_error_monitor_thread
		and srv_monitor_thread should already exit by now. The
		only threads to be suspended are the master threads
		and worker threads (purge threads). Print the thread
		type if any of such threads not in suspended mode */
		if (srv_print_verbose_log && count > 600) {
			const char*	thread_type = "<null>";

			switch (active_thd) {
			case SRV_NONE:
				/* This shouldn't happen because we've
				already checked for this case before
				entering the if(). We handle it here
				to avoid a compiler warning. */
				ut_error;
			case SRV_WORKER:
				thread_type = "worker threads";
				break;
			case SRV_MASTER:
				thread_type = "master thread";
				break;
			case SRV_PURGE:
				thread_type = "purge thread";
				break;
			}

			ib_logf(IB_LOG_LEVEL_INFO,
				"Waiting for %s to be suspended",
				thread_type);
			count = 0;
		}

		goto loop;
	}

	/* At this point only page_cleaner should be active. We wait
	here to let it complete the flushing of the buffer pools
	before proceeding further. */
	srv_shutdown_state = SRV_SHUTDOWN_FLUSH_PHASE;
	count = 0;
	while (buf_page_cleaner_is_active) {
		++count;
		os_thread_sleep(100000);
		if (srv_print_verbose_log && count > 600) {
			ib_logf(IB_LOG_LEVEL_INFO,
				"Waiting for page_cleaner to "
				"finish flushing of buffer pool");
			count = 0;
		}
	}

	pending_io = buf_pool_check_no_pending_io();

	if (pending_io) {
		if (srv_print_verbose_log && count > 600) {
			ib_logf(IB_LOG_LEVEL_INFO,
				"Waiting for %lu buffer page I/Os to complete",
				(ulong) pending_io);
			count = 0;
		}

		goto loop;
	}

	if (srv_fast_shutdown == 2) {
		if (!srv_read_only_mode) {
			ib_logf(IB_LOG_LEVEL_INFO,
				"MySQL has requested a very fast shutdown "
				"without flushing the InnoDB buffer pool to "
				"data files. At the next mysqld startup "
				"InnoDB will do a crash recovery!");

			/* In this fastest shutdown we do not flush the
			buffer pool:

			it is essentially a 'crash' of the InnoDB server.
			Make sure that the log is all flushed to disk, so
			that we can recover all committed transactions in
			a crash recovery. We must not write the lsn stamps
			to the data files, since at a startup InnoDB deduces
			from the stamps if the previous shutdown was clean. */

			log_buffer_flush_to_disk();

			/* Check that the background threads stay suspended */
			thread_name = srv_any_background_threads_are_active();

			if (thread_name != NULL) {
				ib_logf(IB_LOG_LEVEL_WARN,
					"Background thread %s woke up "
					"during shutdown", thread_name);
				goto loop;
			}
		}

		srv_shutdown_state = SRV_SHUTDOWN_LAST_PHASE;

		fil_close_all_files();

		thread_name = srv_any_background_threads_are_active();

		ut_a(!thread_name);

		return;
	}

	if (!srv_read_only_mode) {
		log_make_latest_checkpoint();
	}
	
	lsn = log_get_lsn(*log_sys);

	ut_ad(srv_force_recovery != SRV_FORCE_NO_LOG_REDO
	      || lsn == log_sys->last_checkpoint_lsn + LOG_BLOCK_HDR_SIZE);

	if ((srv_force_recovery != SRV_FORCE_NO_LOG_REDO
	     && lsn != log_sys->last_checkpoint_lsn)
	    ) {
		goto loop;
	}

	/* Check that the background threads stay suspended */
	thread_name = srv_any_background_threads_are_active();
	if (thread_name != NULL) {
		ib_logf(IB_LOG_LEVEL_WARN,
			"Background thread %s woke up during shutdown",
			thread_name);

		goto loop;
	}

	if (!srv_read_only_mode) {
		fil_flush_file_spaces(FIL_TABLESPACE);
		fil_flush_file_spaces(FIL_LOG);
	}

	/* The call fil_write_flushed_lsn_to_data_files() will pass the buffer
	pool: therefore it is essential that the buffer pool has been
	completely flushed to disk! (We do not call fil_write... if the
	'very fast' shutdown is enabled.) */

	if (!buf_all_freed()) {

		if (srv_print_verbose_log && count > 600) {
			ib_logf(IB_LOG_LEVEL_INFO,
				"Waiting for dirty buffer pages to be flushed");
			count = 0;
		}

		goto loop;
	}

	srv_shutdown_state = SRV_SHUTDOWN_LAST_PHASE;

	/* Make some checks that the server really is quiet */
	srv_thread_type	type = srv_get_active_thread_type();
	ut_a(type == SRV_NONE);

	bool	freed = buf_all_freed();
	ut_a(freed);

	ut_a(lsn == log_get_lsn(*log_sys));

	if (lsn < srv_start_lsn) {
		ib_logf(IB_LOG_LEVEL_ERROR,
			"Log sequence number at shutdown " LSN_PF " "
			"is lower than at startup " LSN_PF "!",
			lsn, srv_start_lsn);
	}

	srv_shutdown_lsn = lsn;

	if (!srv_read_only_mode) {
		fil_write_flushed_lsn_to_data_files(lsn, 0);

		fil_flush_file_spaces(FIL_TABLESPACE);
	}

	fil_close_all_files();

	/* Make some checks that the server really is quiet */
	type = srv_get_active_thread_type();
	ut_a(type == SRV_NONE);

	freed = buf_all_freed();
	ut_a(freed);

	ut_a(lsn == log_get_lsn(*log_sys));
}

#ifdef UNIV_LOG_DEBUG
/******************************************************//**
Checks by parsing that the catenated log segment for a single mtr is
consistent. */
UNIV_INTERN
ibool
log_check_log_recs(
/*===============*/
	const byte*	buf,		/*!< in: pointer to the start of
					the log segment in the
					log_sys->buf log buffer */
	ulint		len,		/*!< in: segment length in bytes */
	ib_uint64_t	buf_start_lsn)	/*!< in: buffer start lsn */
{
	ib_uint64_t	contiguous_lsn;
	ib_uint64_t	scanned_lsn;
	const byte*	start;
	const byte*	end;
	byte*		buf1;
	byte*		scan_buf;

	if (len == 0) {

		return(TRUE);
	}

	start = ut_align_down(buf, OS_FILE_LOG_BLOCK_SIZE);
	end = ut_align(buf + len, OS_FILE_LOG_BLOCK_SIZE);

	buf1 = mem_alloc((end - start) + OS_FILE_LOG_BLOCK_SIZE);
	scan_buf = ut_align(buf1, OS_FILE_LOG_BLOCK_SIZE);

	ut_memcpy(scan_buf, start, end - start);

	recv_scan_log_recs((buf_pool_get_n_pages()
			   - (recv_n_pool_free_frames * srv_buf_pool_instances))
			   * UNIV_PAGE_SIZE, FALSE, scan_buf, end - start,
			   ut_uint64_align_down(buf_start_lsn,
						OS_FILE_LOG_BLOCK_SIZE),
			   &contiguous_lsn, &scanned_lsn);

	ut_a(scanned_lsn == buf_start_lsn + len);
	ut_a(recv_sys->recovered_lsn == scanned_lsn);

	mem_free(buf1);

	return(TRUE);
}
#endif /* UNIV_LOG_DEBUG */

/******************************************************//**
Peeks the current lsn.
@return	TRUE if success */
UNIV_INTERN
ibool
log_peek_lsn(
/*=========*/
	lsn_t*	lsn)	/*!< out: if returns TRUE, current lsn is here */
{
	*lsn = log_get_lsn(*log_sys);

	return(TRUE);
}

/******************************************************//**
Prints info of the log. */
UNIV_INTERN
void
log_print(FILE *file) {
	lsn_t last_checkpoint_lsn;
	lsn_t dirty_pages_added_up_to_lsn;
	lsn_t ready_for_write_lsn;
	lsn_t write_lsn;
	lsn_t flush_lsn;
	lsn_t oldest_lsn;
	lsn_t max_assigned_lsn;
	lsn_t current_lsn;

	last_checkpoint_lsn = log_sys->last_checkpoint_lsn;
	dirty_pages_added_up_to_lsn = log_buffer_dirty_pages_added_up_to_lsn(*log_sys);
	ready_for_write_lsn = log_buffer_ready_for_write_lsn(*log_sys);
	write_lsn = log_sys->write_lsn;
	flush_lsn = log_sys->flushed_to_disk_lsn;
	oldest_lsn = log_sys->available_for_checkpoint_lsn;
	max_assigned_lsn = log_get_lsn(*log_sys);
	current_lsn = log_get_lsn(*log_sys);

	fprintf(file,
			"Log sequence number          " LSN_PF
			"\n"
			"Log buffer assigned up to    " LSN_PF
			"\n"
			"Log buffer completed up to   " LSN_PF
			"\n"
			"Log written up to            " LSN_PF
			"\n"
			"Log flushed up to            " LSN_PF
			"\n"
			"Added dirty pages up to      " LSN_PF
			"\n"
			"Pages flushed up to          " LSN_PF
			"\n"
			"Last checkpoint at           " LSN_PF "\n",
			current_lsn, max_assigned_lsn, ready_for_write_lsn, write_lsn,
			flush_lsn, dirty_pages_added_up_to_lsn, oldest_lsn,
			last_checkpoint_lsn);

	time_t current_time = time(nullptr);

	double time_elapsed = difftime(current_time, log_sys->last_printout_time);

	if (time_elapsed <= 0) {
		time_elapsed = 1;
	}

	fprintf(
		file, ULINTPF " log i/o's done, %.2f log i/o's/second\n",
		ulint(log_sys->n_log_ios),
		static_cast<double>(log_sys->n_log_ios - log_sys->n_log_ios_old) / time_elapsed);

	log_sys->n_log_ios_old = log_sys->n_log_ios;
	log_sys->last_printout_time = current_time;
}

/**********************************************************************//**
Refreshes the statistics used to print per-second averages. */
UNIV_INTERN
void
log_refresh_stats(void)
/*===================*/
{
	log_sys->n_log_ios_old = log_sys->n_log_ios;
	log_sys->last_printout_time = time(NULL);
}

/********************************************************//**
Shutdown the log system but do not release all the memory. */
UNIV_INTERN
void
log_sys_close(void)
/*==============*/
{
	ut_a(log_sys != nullptr);

	log_deallocate_file_header_buffers(*log_sys);
	log_deallocate_write_events(*log_sys);
	log_deallocate_flush_events(*log_sys);
	log_deallocate_recent_closed(*log_sys);
	log_deallocate_recent_written(*log_sys);
	log_deallocate_checkpoint_buffer(*log_sys);
	log_deallocate_write_ahead_buffer(*log_sys);
	log_deallocate_buffer(*log_sys);

	log_sys->sn_lock.free();

	mutex_free(&log_sys->write_notifier_mutex);
	mutex_free(&log_sys->flush_notifier_mutex);
	mutex_free(&log_sys->flusher_mutex);
	mutex_free(&log_sys->writer_mutex);
	mutex_free(&log_sys->closer_mutex);
	mutex_free(&log_sys->checkpointer_mutex);

	os_event_free(log_sys->write_notifier_event);
	os_event_free(log_sys->flush_notifier_event);
	os_event_free(log_sys->checkpointer_event);
	os_event_free(log_sys->writer_event);
	os_event_free(log_sys->flusher_event);

	log_mem_free();
}

/********************************************************//**
Free the log system data structures. */
UNIV_INTERN
void
log_mem_free(void)
/*==============*/
{
	if (log_sys != NULL) {
	  //recv_sys_mem_free();
		mem_free(log_sys);

		log_sys = NULL;
	}
}

bool log_buffer_resize_low(log_t &log, size_t new_size, lsn_t end_lsn) {
	ut_ad(log_checkpointer_mutex_own(log));
	ut_ad(log_writer_mutex_own(log));

	const lsn_t start_lsn =
		ut_uint64_align_down(log.write_lsn.load(), OS_FILE_LOG_BLOCK_SIZE);

	end_lsn = ut_uint64_align_up(end_lsn, OS_FILE_LOG_BLOCK_SIZE);

	if (end_lsn == start_lsn) {
		end_lsn += OS_FILE_LOG_BLOCK_SIZE;
	}

	ut_ad(end_lsn - start_lsn <= log.buf_size);

	if (end_lsn - start_lsn > new_size) {
		return (false);
	}

	/* Save the contents. */
	byte *tmp_buf = UT_NEW_ARRAY_NOKEY(byte, end_lsn - start_lsn);
	for (auto i = start_lsn; i < end_lsn; i += OS_FILE_LOG_BLOCK_SIZE) {
		std::memcpy(&tmp_buf[i - start_lsn], &log.buf[i % log.buf_size],
					OS_FILE_LOG_BLOCK_SIZE);
	}

	/* Re-allocate log buffer. */
	srv_log_buffer_size = static_cast<ulong>(new_size) /  UNIV_PAGE_SIZE;
	log_deallocate_buffer(log);
	log_allocate_buffer(log);

	/* Restore the contents. */
	for (auto i = start_lsn; i < end_lsn; i += OS_FILE_LOG_BLOCK_SIZE) {
		std::memcpy(&log.buf[i % new_size], &tmp_buf[i - start_lsn],
					OS_FILE_LOG_BLOCK_SIZE);
	}
	UT_DELETE_ARRAY(tmp_buf);

	log_calc_buf_size(log);

	ut_a(srv_log_buffer_size  * UNIV_PAGE_SIZE == log.buf_size);

	ib_logf(IB_LOG_LEVEL_INFO, "srv_log_buffer_size was extended to %lu", log.buf_size);

	return (true);
}

/* @} */

/**************************************************/ /**

 @name	Start / stop of background threads

 *******************************************************/

/* @{ */

void log_writer_thread_active_validate(const log_t &log) {
	ut_a(log.writer_thread_alive.load());
}

void log_closer_thread_active_validate(const log_t &log) {
	ut_a(log.closer_thread_alive.load());
}

void log_background_write_threads_active_validate(const log_t &log) {
	ut_a(log.writer_thread_alive.load());

	ut_a(log.flusher_thread_alive.load());
}

void log_background_threads_active_validate(const log_t &log) {
	log_background_write_threads_active_validate(log);

	ut_a(log.write_notifier_thread_alive.load());
	ut_a(log.flush_notifier_thread_alive.load());

	ut_a(log.closer_thread_alive.load());

	ut_a(log.checkpointer_thread_alive.load());
}

void log_background_threads_inactive_validate(const log_t &log) {
	ut_a(!log.checkpointer_thread_alive.load());
	ut_a(!log.closer_thread_alive.load());
	ut_a(!log.write_notifier_thread_alive.load());
	ut_a(!log.flush_notifier_thread_alive.load());
	ut_a(!log.writer_thread_alive.load());
	ut_a(!log.flusher_thread_alive.load());
}

void log_start_background_threads(log_t &log) {
	ib_logf(IB_LOG_LEVEL_INFO, "Log background threads are being started...");

	std::atomic_thread_fence(std::memory_order_seq_cst);

	log_background_threads_inactive_validate(log);

	ut_a(!srv_read_only_mode);
	ut_a(log.sn.load() > 0);

	log.closer_thread_alive = true;
	log.checkpointer_thread_alive = true;
	log.writer_thread_alive = true;
	log.flusher_thread_alive = true;
	log.write_notifier_thread_alive = true;
	log.flush_notifier_thread_alive = true;

	log.should_stop_threads = false;

	std::atomic_thread_fence(std::memory_order_seq_cst);

	os_thread_create(log_checkpointer, &log, NULL);

	os_thread_create(log_closer, &log, NULL);

	os_thread_create(log_writer, &log, NULL);

	os_thread_create(log_flusher, &log, NULL);

	os_thread_create(log_write_notifier, &log, NULL);

	os_thread_create(log_flush_notifier, &log, NULL);

	log_background_threads_active_validate(log);
}

void log_stop_background_threads(log_t &log) {
	/* We cannot stop threads when x-lock is acquired, because of scenario:
	* log_checkpointer starts log_checkpoint()
	* log_checkpoint() asks to persist dd dynamic metadata
	* dict_persist_dd_table_buffer() tries to write to redo
	* but cannot acquire shared lock on log.sn_lock
	* so log_checkpointer thread waits for this thread
	until the x-lock is released
	* but this thread waits until log background threads
	have been stopped - log_checkpointer is not stopped. */
	ut_ad(!log.sn_lock.x_own());

	ib_logf(IB_LOG_LEVEL_INFO, "Log background threads are being closed...");

	std::atomic_thread_fence(std::memory_order_seq_cst);

	log_background_threads_active_validate(log);

	ut_a(!srv_read_only_mode);

	log.should_stop_threads = true;

	/* Wait until threads are closed. */
	while (log.closer_thread_alive.load() ||
		log.checkpointer_thread_alive.load() ||
		log.writer_thread_alive.load() || log.flusher_thread_alive.load() ||
		log.write_notifier_thread_alive.load() ||
		log.flush_notifier_thread_alive.load()) {
			os_thread_sleep(100 * 1000);
	}

	std::atomic_thread_fence(std::memory_order_seq_cst);

	log_background_threads_inactive_validate(log);
}

bool log_threads_active(const log_t &log) {
	return (log.closer_thread_alive.load() ||
		log.checkpointer_thread_alive.load() ||
		log.writer_thread_alive.load() || log.flusher_thread_alive.load() ||
		log.write_notifier_thread_alive.load() ||
		log.flush_notifier_thread_alive.load());
}

void log_start(log_t &log, checkpoint_no_t checkpoint_no, lsn_t checkpoint_lsn,
				lsn_t start_lsn) {
	ut_a(log_sys != nullptr);
	ut_a(checkpoint_lsn >= OS_FILE_LOG_BLOCK_SIZE);
	ut_a(checkpoint_lsn >= LOG_START_LSN);
	ut_a(start_lsn >= checkpoint_lsn);

	log.last_checkpoint_lsn = checkpoint_lsn;
	log.next_checkpoint_no = checkpoint_no;
	log.available_for_checkpoint_lsn = checkpoint_lsn;

	log_update_limits(log);

	log.sn = log_translate_lsn_to_sn(start_lsn);

	if ((start_lsn + LOG_BLOCK_TRL_SIZE) % OS_FILE_LOG_BLOCK_SIZE == 0) {
		start_lsn += LOG_BLOCK_TRL_SIZE + LOG_BLOCK_HDR_SIZE;
	} else if (start_lsn % OS_FILE_LOG_BLOCK_SIZE == 0) {
		start_lsn += LOG_BLOCK_HDR_SIZE;
	}
	ut_a(start_lsn > LOG_START_LSN);

	log.recent_written.add_link(0, start_lsn);
	log.recent_written.advance_tail();
	ut_a(log_buffer_ready_for_write_lsn(log) == start_lsn);

	log.recent_closed.add_link(0, start_lsn);
	log.recent_closed.advance_tail();
	ut_a(log_buffer_dirty_pages_added_up_to_lsn(log) == start_lsn);

	log.write_lsn = start_lsn;
	log.flushed_to_disk_lsn = start_lsn;

	log_files_update_offsets(log, start_lsn);

	log.write_ahead_end_offset =
		ut_uint64_align_up(log.current_file_end_offset, srv_log_write_ahead_size);

	lsn_t block_lsn;
	byte *block = NULL;

	block_lsn = ut_uint64_align_down(start_lsn, OS_FILE_LOG_BLOCK_SIZE);

	ut_a(block_lsn % log.buf_size + OS_FILE_LOG_BLOCK_SIZE <= log.buf_size);

	block = static_cast<byte *>(log.buf) + block_lsn % log.buf_size;

	log_block_set_hdr_no(block, log_block_convert_lsn_to_no(block_lsn));

	log_block_set_flush_bit(block, true);

	log_block_set_data_len(block, start_lsn - block_lsn);

	log_block_set_first_rec_group(block, start_lsn % OS_FILE_LOG_BLOCK_SIZE);

	/* Do not reorder writes above, below this line. For x86 this
	protects only from unlikely compile-time reordering. */
	std::atomic_thread_fence(std::memory_order_release);
}

/* @} */

#endif /* !UNIV_HOTBACKUP */
